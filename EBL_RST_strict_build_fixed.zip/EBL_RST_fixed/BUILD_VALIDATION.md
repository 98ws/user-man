# 重现编译

使用 Python 3.12（Sphinx 9 需要 Python 3.11+）：

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-build.txt
.venv/bin/sphinx-build -E -a -b html -n -W --keep-going source build/html
.venv/bin/sphinx-build -E -a -b latex -n -W --keep-going source build/latex
```

无需运行 EBL 软件，autodoc 为 Sphinx 内置扩展。直接打开 build/html/index.html 阅读。原图 EMF 与生成的 PNG 均在 source/media/06；原始完整项目见 original_project.zip。reports/ 为输入压缩包附带的历史报告，含已过时的编译状态；本轮结果以根目录 validation_report.md 为准。
