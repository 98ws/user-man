.. _ch08:

8. 蒙特卡洛模拟工具（MC）
=================================

蒙特卡洛模拟工具（MC）是专为半导体电子束曝光工艺设计的仿真分析平台，集成电子散射蒙特卡洛模拟、能量沉积（PSF）拟合与分析、结果可视化及文件管理四大核心功能。MC支持材料模型搭建、电子束参数配置、数据采集设置、模型库和材料库管理，提供多种可视化方式展示模拟结果，并具备 PSF 拟合、分析及修正处理能力，同时支持 PSF 信息导入导出。

.. _sec-8-1:

8.1 界面布局
---------------------

.. list-table:: 项目操作
   :header-rows: 1
   :widths: 32 68

   * - 参数/选项
     - 原文说明
   * - 新建项目
     - 创建一个新项目。
   * - 打开项目
     - 打开一个已有项目。
   * - 关闭项目
     - 关闭当前项目。
   * - 保存项目
     - 保存当前项目。
   * - 另存为项目
     - 把当前项目保存为一个全新路径。
   * - 最近操作项目列表
     - 列出了最近操作过的项目，点击其中一个，即可打开相应的项目。

.. figure:: media/08/img_001.png
   :name: fig-ch08-img001
   :width: 11.8cm
   :align: center

   8.1 界面布局界面或操作示意 1


.. _sec-8-2:

8.2 MC模拟仿真
-------------------------

**运行蒙特卡洛模拟**


打开MC软件后，点击模拟按钮，打开蒙特卡罗模拟对话框。

.. figure:: media/08/img_002.png
   :name: fig-ch08-img002
   :width: 13.04cm
   :align: center

   打开MC软件后，点击模拟按钮，打开蒙特卡罗模拟对话框。


**设置材料栈参数**


.. figure:: media/08/img_003.png
   :name: fig-ch08-img003
   :width: 10.36cm
   :align: center

   设置材料栈参数


材料栈描述了每层的材料、类型以及厚度信息。材料层类型可以切换为抗蚀剂层或者普通层。

.. figure:: media/08/img_004.png
   :name: fig-ch08-img004
   :width: 10.6cm
   :align: center

   材料栈描述了每层的材料、类型以及厚度信息。材料层类型可以切换为抗蚀剂层或者普…


每层材料可以通过下拉列表从材料库中选择。

.. figure:: media/08/img_005.png
   :name: fig-ch08-img005
   :width: 6.83cm
   :align: center

   每层材料可以通过下拉列表从材料库中选择。


设置save参数保存能量沉积，“yes”保存，“No”不保存。对于新添加的层，抗蚀剂层默认“yes”，普通材料层默认为“No”。

**设置仿真参数**


.. figure:: media/08/img_006.png
   :name: fig-ch08-img006
   :width: 8.72cm
   :align: center

   设置仿真参数










.. list-table:: 仿真参数
   :header-rows: 1
   :widths: 32 68

   * - 参数/选项
     - 原文说明
   * - Accelerate Voltage
     - 电子加速电压
   * - Spot Size
     - 束斑尺寸
   * - Incident Angle
     - 入射电子与材料平面夹角
   * - Azimuth Angle
     - 入射电子在X-Y平面内与X轴夹角
   * - Electron Count
     - 仿真电子数量
   * - Cutoff Energy
     - 电子运动计算的截断能量
   * - Grid Size
     - Z向采样网格间距，用户不设置的情况下程序根据模型参数自动生成
   * - Save Trajectory
     - 是否保存电子运动轨迹用于可视化

以上参数可以通过点击“导入”或者“导出”按钮进行数据的导入和导出。



模拟结果可视化
---------------------------------

模拟完成后，新的模拟结果会添加到项目树下，在视图窗口可以查看模拟结果。


2D-PSF 视图
~~~~~~~~~~~~~~~~~~~~~~~


2D-PSF视图显示了不同深度位置的径向能量沉积分布情况，X轴为测量点与曝光中心的径向距离，Y轴为能量。

.. figure:: media/08/img_007.png
   :name: fig-ch08-img007
   :width: 12.02cm
   :align: center

   模拟结果可视化界面或操作示意 1


这里显示了不同层深度位置的2D-PSF曲线，默认只显示5层深度的2D-PSF曲线，用户可以手动添加其它深度层的2D-PSF曲线。径向距离和能量的刻度类型可以设置为对数或线性。能量类型可以切换为密度，总能量，或者累积能量。

.. figure:: media/08/img_008.png
   :name: fig-ch08-img008
   :width: 12.54cm
   :align: center

   模拟结果可视化界面或操作示意 2


选中模拟结果，右键点击“层列表”，添加指定深度2D-PSF曲线到列表。

.. figure:: media/08/img_009.png
   :name: fig-ch08-img009
   :width: 11.91cm
   :align: center

   模拟结果可视化界面或操作示意 3


水平方向指定区间，并拉伸到视图宽度。

.. figure:: media/08/img_010.png
   :name: fig-ch08-img010
   :width: 14.65cm
   :align: center

   模拟结果可视化界面或操作示意 4


垂直方向指定区间，并拉伸到视图高度。

.. figure:: media/08/img_011.png
   :name: fig-ch08-img011
   :width: 14.65cm
   :align: center

   模拟结果可视化界面或操作示意 5


框选指定区间，并拉伸到视图宽度高度。

.. figure:: media/08/img_012.png
   :name: fig-ch08-img012
   :width: 14.65cm
   :align: center

   模拟结果可视化界面或操作示意 6


弹出对话框，可以手工指定X,Y轴的起始截止位置，并拉伸到视图宽度高度。

.. figure:: media/08/img_013.png
   :name: fig-ch08-img013
   :width: 4.76cm
   :align: center

   模拟结果可视化界面或操作示意 7


.. figure:: media/08/img_014.png
   :name: fig-ch08-img014
   :width: 0.43cm
   :align: center

   模拟结果可视化界面或操作示意 8


恢复显示视图全部内容


3D-PSF 视图
~~~~~~~~~~~~~~~~~~~~~~~


3D-PSF视图以用热力图表示材料内部的沉积能量分布情况，X轴为测量点与曝光中心的距离，Y轴为能量沉积计算层Z方向的深度。

.. figure:: media/08/img_015.png
   :name: fig-ch08-img015
   :width: 11.86cm
   :align: center

   模拟结果可视化界面或操作示意 9


选中模拟结果，点击右键选择“PSF 3d视图”查看3D-PSF。径向距离和颜色值的刻度类型可以设置为对数或线性。能量类型可以切换为密度，总能量，或者累积能量。

.. figure:: media/08/img_016.png
   :name: fig-ch08-img016
   :width: 12.22cm
   :align: center

   模拟结果可视化界面或操作示意 10



2D-Z  视图
~~~~~~~~~~~~~~~~~~~~~


2D-Z视图展示了指定半径范围内沿Z方向的能量沉积分布，X轴表示不同深度位置，Y表示能量。

.. figure:: media/08/img_017.png
   :name: fig-ch08-img017
   :width: 11.82cm
   :align: center

   模拟结果可视化界面或操作示意 11


选中模拟结果，点击右键选择“2D-Z视图”查看2D-Z，用户可以指定需要显示的半径范围内的能量。深度位置和能量的刻度类型可以设置为对数或线性。能量类型可以切换为密度，总能量，或者累积能量。

.. figure:: media/08/img_018.png
   :name: fig-ch08-img018
   :width: 11.76cm
   :align: center

   模拟结果可视化界面或操作示意 12



轨迹 视图
~~~~~~~~~~~~~~~


如果要追踪电子的运动轨迹，必须在模拟参数中将保存轨迹的选项设为“yes”。

.. figure:: media/08/img_019.png
   :name: fig-ch08-img019
   :width: 5.27cm
   :align: center

   模拟结果可视化界面或操作示意 13


模拟完成后，点击“轨迹视图”查看电子运动轨迹。

.. figure:: media/08/img_020.png
   :name: fig-ch08-img020
   :width: 12.12cm
   :align: center

   模拟结果可视化界面或操作示意 14


用户可以选择显示的截面，支持切换XZ、YZ、XY截面视图，当前显示视图为YZ截面。

.. figure:: media/08/img_021.png
   :name: fig-ch08-img021
   :width: 11.86cm
   :align: center

   模拟结果可视化界面或操作示意 15


.. _sec-8-3:

8.3 PSF拟合
-----------------------

PSF拟合功能支持对加载的PSF数据进行检查，并用高斯模型表示。点击“拟合PSF”加载指定深度的能量沉积数据，进入PSF拟合参数设置界面。

.. figure:: media/08/img_022.png
   :name: fig-ch08-img022
   :width: 13.74cm
   :align: center

   PSF拟合功能支持对加载的PSF数据进行检查，并用高斯模型表示。点击“拟合P…


设置拟合参数后，点击“开始拟合”拟合高斯模型参数，拟合成功后更新模型参数和预测曲线。用户也可以手动修改模型参数，手动修改参数时会更新预测曲线。

.. figure:: media/08/img_023.png
   :name: fig-ch08-img023
   :width: 13.23cm
   :align: center

   设置拟合参数后，点击“开始拟合”拟合高斯模型参数，拟合成功后更新模型参数和预…













.. list-table:: PSF 拟合参数与显示选项
   :header-rows: 1
   :widths: 32 68

   * - 参数/选项
     - 原文说明
   * - Number of Gamma
     - 设置高斯模型Gamma数量，0表示双高斯模型，1表示三高斯模型，2表示四高斯模型。
   * - Data Convolution
     - 数据平滑处理的计算范围。
   * - Alpha，Beta，Eta，…
     - 待更新模型参数。
   * - Scale Factor
     - 输入数据跟归一化高斯模型之间的转换系数。
   * - Convolution
     - 显示平滑处理后PSF数据。
   * - Analytical
     - 显示拟合得到的多高斯PSF曲线。
   * - Show Energy Density
     - 显示径向能量密度。
   * - Show Energy In Radial Section
     - 显示半径范围内的总能量。
   * - Show Cumulative Radial Energy
     - 显示累积能量。


.. _sec-8-4:

8.4 PSF分析
-----------------------

打开文件菜单，点击“分析2D-PSF”按钮创建分析PSF。

.. figure:: media/08/img_024.png
   :name: fig-ch08-img024
   :width: 11.94cm
   :align: center

   打开文件菜单，点击“分析2D-PSF”按钮创建分析PSF。


选择PSF数学模型，设置高斯模型参数后点击确认。

.. figure:: media/08/img_025.png
   :name: fig-ch08-img025
   :width: 6.03cm
   :align: center

   选择PSF数学模型，设置高斯模型参数后点击确认。


显示分析PSF曲线。

.. figure:: media/08/img_026.png
   :name: fig-ch08-img026
   :width: 11.74cm
   :align: center

   显示分析PSF曲线。


.. _sec-8-5:

8.5 区域PSF
-----------------------

在3D-PSF上方右键选择“区域平均”，可以对指定深度区域内的2D-PSF进行平均操作。

.. figure:: media/08/img_027.png
   :name: fig-ch08-img027
   :width: 12.61cm
   :align: center

   在3D-PSF上方右键选择“区域平均”，可以对指定深度区域内的2D-PSF进…


设置检测区域范围。

.. figure:: media/08/img_028.png
   :name: fig-ch08-img028
   :width: 4.34cm
   :align: center

   设置检测区域范围。


视图窗口显示指定区域范围内的平均2D-PSF。

.. figure:: media/08/img_029.png
   :name: fig-ch08-img029
   :width: 12.09cm
   :align: center

   视图窗口显示指定区域范围内的平均2D-PSF。


.. _sec-8-6:

8.6 卷积 PSF
-------------------------

在2D-PSF上方右键选择“卷积”，可以对两个2D-PSF进行卷积。

.. figure:: media/08/img_030.png
   :name: fig-ch08-img030
   :width: 12.85cm
   :align: center

   在2D-PSF上方右键选择“卷积”，可以对两个2D-PSF进行卷积。


选择另一个2D-PSF做卷积。

.. figure:: media/08/img_031.png
   :name: fig-ch08-img031
   :width: 5.69cm
   :align: center

   选择另一个2D-PSF做卷积。


视图窗口显示卷积后的2D-PSF。

.. figure:: media/08/img_032.png
   :name: fig-ch08-img032
   :width: 11.77cm
   :align: center

   视图窗口显示卷积后的2D-PSF。


.. _sec-8-7:

8.7 平均 PSF
-------------------------

在2D-PSF上方右键选择“选择平均”，可以对勾选的一个或多个不同深度的2D-PSF进行取平均操作。

.. figure:: media/08/img_033.png
   :name: fig-ch08-img033
   :width: 12.09cm
   :align: center

   在2D-PSF上方右键选择“选择平均”，可以对勾选的一个或多个不同深度的2D…


视图窗口显示平均后的2D-PSF。

.. figure:: media/08/img_034.png
   :name: fig-ch08-img034
   :width: 12.04cm
   :align: center

   视图窗口显示平均后的2D-PSF。


.. _sec-8-8:

8.8 剂量因子
---------------------

在2D-PSF上方右键选择“剂量因子”，可以计算两个2D-PSF的剂量因子比。

.. figure:: media/08/img_035.png
   :name: fig-ch08-img035
   :width: 12.02cm
   :align: center

   在2D-PSF上方右键选择“剂量因子”，可以计算两个2D-PSF的剂量因子比…


列出所有选中的2D-PSF相对于参考2D-PSF的剂量比。

.. figure:: media/08/img_036.png
   :name: fig-ch08-img036
   :width: 8.15cm
   :align: center

   列出所有选中的2D-PSF相对于参考2D-PSF的剂量比。


.. _sec-8-9:

8.9 PSF修正
-----------------------

PSF修正用于确定共焦点处的基础剂量和工艺模糊，在主界面点击“编辑”菜单下的“E-Beam修正”进入PSF修正。

.. figure:: media/08/img_037.png
   :name: fig-ch08-img037
   :width: 12.23cm
   :align: center

   PSF修正用于确定共焦点处的基础剂量和工艺模糊，在主界面点击“编辑”菜单下的…


设置PSF修正项目名称。

.. figure:: media/08/img_038.png
   :name: fig-ch08-img038
   :width: 6.02cm
   :align: center

   设置PSF修正项目名称。


进入PSF修正界面，用户设置PSF模型参数和不同密度CD-dose测量值后点击“运行修正”进行PSF修正。

.. figure:: media/08/img_039.png
   :name: fig-ch08-img039
   :width: 13.85cm
   :align: center

   进入PSF修正界面，用户设置PSF模型参数和不同密度CD-dose测量值后点…


有两种方式设置PSF参数，可以从存档中选择PSF：

.. figure:: media/08/img_040.png
   :name: fig-ch08-img040
   :width: 13.86cm
   :align: center

   有两种方式设置PSF参数，可以从存档中选择PSF：


用户也可以直接手动输入PSF模型参数。

.. figure:: media/08/img_041.png
   :name: fig-ch08-img041
   :width: 13.1cm
   :align: center

   用户也可以直接手动输入PSF模型参数。


输入不同剂量和不同版图密度情况下的测量CD。

.. figure:: media/08/img_042.png
   :name: fig-ch08-img042
   :width: 13.24cm
   :align: center

   输入不同剂量和不同版图密度情况下的测量CD。


修正完成后显示拟合得到的Base Dose、Process Blur和Constant Bias参数，以及拟合误差。拟合前后的CD-Dose曲线显示在右侧窗口，曲线纵坐标可以设置是否包含偏置，横坐标可以切换为实际剂量或者归一化后的剂量。

.. figure:: media/08/img_043.png
   :name: fig-ch08-img043
   :width: 13.39cm
   :align: center

   修正完成后显示拟合得到的Base Dose、Process Blur和Con…


.. _sec-8-10:

8.10 存档
-------------------

2D-PSF、3D-PSF和材料模型都存放在存档下面。

.. figure:: media/08/img_044.png
   :name: fig-ch08-img044
   :width: 13.23cm
   :align: center

   2D-PSF、3D-PSF和材料模型都存放在存档下面。


2D-PSF存档
~~~~~~~~~~~~~~~~~~~~~

在2D-PSF上方右键点击“生成PSF 2D文件”可以将2D-PSF保存到存档。

.. figure:: media/08/img_045.png
   :name: fig-ch08-img045
   :width: 13.36cm
   :align: center

   在2D-PSF上方右键点击“生成PSF 2D文件”可以将2D-PSF保存到存…


点击2D-PSF存档中查看已经保存的2D-PSF。每一行数据组代表一种模型，并能够显示模型的主要信息，包括：模型搭建参数、模拟运行时长、创建时间。

.. figure:: media/08/img_046.png
   :name: fig-ch08-img046
   :width: 13.95cm
   :align: center

   点击2D-PSF存档中查看已经保存的2D-PSF。每一行数据组代表一种模型，…


点击“导入”按钮，选择一个psf2d文件，可以把该文件导入到2D PSF表格里。

高亮选中2D PSF表格里的一行，点击“导出”按钮，可以把该行数据导出为一个psf2d文件。

高亮选中2D PSF表格里的一行，点击“删除”按钮，可以删除该行数据。

选中若干行，点击“复制 ”按钮可以复制相应的psf2d数据。复制所产生的数据，显示在表格的最下方。

高亮选中2D PSF表格里的一行，点击“编辑”按钮，弹出编辑psf2d对话框，可以修改resists和layers。

.. figure:: media/08/img_047.png
   :name: fig-ch08-img047
   :width: 12.48cm
   :align: center

   高亮选中2D PSF表格里的一行，点击“编辑”按钮，弹出编辑psf2d对话框…


3D-PSF存档
~~~~~~~~~~~~~~~~~~~~~

在3D-PSF上方右键点击“生成PSF 3D文件”可以将3D-PSF保存到存档。

.. figure:: media/08/img_048.png
   :name: fig-ch08-img048
   :width: 13.46cm
   :align: center

   在3D-PSF上方右键点击“生成PSF 3D文件”可以将3D-PSF保存到存…


点击3D-PSF存档中查看已经保存的3D-PSF。每一行数据组代表一种模型，并能够显示模型的主要信息，包括：模型搭建参数、模拟运行时长、创建时间

.. figure:: media/08/img_049.png
   :name: fig-ch08-img049
   :width: 13.02cm
   :align: center

   点击3D-PSF存档中查看已经保存的3D-PSF。每一行数据组代表一种模型，…


点击“导入”按钮，选择一个psf3d文件，可以把该文件导入到3D PSF表格里。

高亮选中3D PSF表格里的一行，点击“导出”按钮，可以把该行数据导出为一个psf3d文件。

高亮选中3D PSF表格里的一行，点击“删除”按钮，可以删除该行数据。

选中若干行，点击“复制 ”按钮可以复制相应的psf3d数据。复制所产生的数据，显示在表格的最下方。

高亮选中3D PSF表格里的一行，点击“编辑”按钮，弹出编辑psf3d对话框，可以修改resists和layers。

.. figure:: media/08/img_050.png
   :name: fig-ch08-img050
   :width: 11.6cm
   :align: center

   高亮选中3D PSF表格里的一行，点击“编辑”按钮，弹出编辑psf3d对话框…


材料存档
~~~~~~~~~~~~~

点击材料存档中查看材料模型参数信息。每一行数据代表一种材料及其相关信息，可显示信息包括：材料名、质量密度、激发能量（eV）。

.. figure:: media/08/img_051.png
   :name: fig-ch08-img051
   :width: 13.08cm
   :align: center

   点击材料存档中查看材料模型参数信息。每一行数据代表一种材料及其相关信息，可显…


点击“新建 ”按钮可以新增材料参数。

点击“编辑 ”按钮可以设置材料参数。

.. figure:: media/08/img_052.png
   :name: fig-ch08-img052
   :width: 5.65cm
   :align: center

   点击“编辑 ”按钮可以设置材料参数。


选中若干行，点击“删除 ”按钮可以删除相应的材料。

选中若干行，点击“复制 ”按钮可以复制相应的材料。复制所产生的材料，显示在表格的最下方。

