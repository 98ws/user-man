.. _ch04:

用户界面
========

EBL 提供图形用户界面（GUI），用于管理流程文件、编排与运行流程，以及访问图形显示和仿真工具。

.. _sec-4-1:

界面布局
--------

EBL 主界面包含菜单栏、功能页标签、功能视图区和状态栏，见 :numref:`fig-ch04-img001`。

.. figure:: media/04/img_001.png
   :name: fig-ch04-img001
   :width: 14.63cm
   :align: center

   EBL 主界面布局

**菜单栏**

菜单栏提供常用功能及工具的访问入口，见 :numref:`fig-ch04-img002`。

.. figure:: media/04/img_002.png
   :name: fig-ch04-img002
   :width: 8.03cm
   :align: center

   菜单项

**功能页标签**

功能页区域包含主页、文档页标签，以及设置按钮和 Logo，见 :numref:`fig-ch04-img003`。

.. figure:: media/04/img_003.png
   :name: fig-ch04-img003
   :width: 14.64cm
   :align: center

   功能页标签

**功能视图区**

功能视图区主要包括主页视图和流程视图，分别用于管理流程文件以及编排、配置和运行流程。两个视图见 :numref:`fig-ch04-img005`。

.. image:: media/04/img_004.png
   :width: 6.89cm
   :align: center

.. figure:: media/04/img_005.png
   :name: fig-ch04-img005
   :width: 6.69cm
   :align: center

   主页视图与流程视图

主页视图支持流程文件（``*.gflow``）的搜索、新建、打开与删除，并显示常用流程文件信息。流程视图用于流程编排、参数配置及运行控制。

**状态栏**

状态栏显示操作过程中的辅助提示信息，见 :numref:`fig-ch04-img006`。

.. figure:: media/04/img_006.png
   :name: fig-ch04-img006
   :width: 9.87cm
   :align: center

   状态栏提示信息

.. _sec-4-2:

视图操作
--------

主页视图
~~~~~~~~

**打开并编辑流程文件**

#. 在主页视图中找到最近打开的流程文件（``*.gflow``）。可使用搜索功能过滤流程列表。
#. 双击流程文件，打开并编辑该流程。

在流程列表中右键单击，可打开快捷菜单并选择相应功能。该视图还提供两个功能按钮。

流程视图
~~~~~~~~

**添加模块节点**

#. 在左侧模块列表中单击所需模块。
#. 将鼠标移动到流程视图区，在目标位置单击以放置模块节点。可连续单击以放置多个相同模块。
#. 右键单击，取消当前模块选择并退出放置状态。

**配置模块参数**

#. 在流程视图区单击需要配置的模块节点。
#. 在右侧参数面板中配置相应参数。
#. 单击面板右下角的“应用”按钮，使修改生效。

**连接模块节点**

#. 将鼠标移动到起始模块下边沿的中点位置，显示连接点。
#. 单击连接点，移动鼠标以拖出连接线。
#. 将鼠标移动到目标模块上边沿的中点位置，单击完成连线。

模块之间的连线用于指定流程的执行顺序。

**使用节点快捷菜单**

在流程视图区选中模块节点后，右键单击打开快捷菜单，选择所需功能。

.. _sec-4-3:

功能入口
--------

流程编排
~~~~~~~~

流程编排界面见 :numref:`fig-ch04-img007`。左侧用于选择模块，中间视图区用于放置及连接节点，右侧节点参数面板用于配置模块参数；上方工具栏用于控制流程运行，下方日志区域用于记录运行信息，以辅助调试和分析。详细操作见 :ref:`ch05`。

.. figure:: media/04/img_007.png
   :name: fig-ch04-img007
   :width: 14.65cm
   :align: center

   流程编排界面

模块节点
~~~~~~~~

EBL 模块分为 Layout、Boolean、PEC、Verify 和 Control 五组，见 :numref:`fig-ch04-img008`。用户可通过放置和连接模块节点组合工作流程。各模块的详细介绍见 :ref:`ch06`。

.. figure:: media/04/img_008.png
   :name: fig-ch04-img008
   :width: 14.65cm
   :align: center

   EBL 模块节点总览

图形显示
~~~~~~~~

图形显示界面用于查看版图数据，可按照图层（Layer）、剂量（Dose）及单元（Cell）等维度查看，见 :numref:`fig-ch04-img009`。详细说明见 :ref:`ch07`。

.. figure:: media/04/img_009.png
   :name: fig-ch04-img009
   :width: 14.65cm
   :align: center

   图形显示界面

蒙特卡洛（MC）仿真
~~~~~~~~~~~~~~~~~~

MC 仿真工具提供蒙特卡洛模拟、点扩散函数（PSF）拟合与分析、结果可视化及文件管理。用户可根据模拟结果对 PSF 进行拟合、分析和修正，并将拟合参数用于 PEC 处理。界面见 :numref:`fig-ch04-img010`，详细说明见 :ref:`ch08`。

.. figure:: media/04/img_010.png
   :name: fig-ch04-img010
   :width: 14.65cm
   :align: center

   蒙特卡洛（MC）仿真界面
