project = 'EBL 软件用户手册'
master_doc = 'index'
extensions = ['sphinx.ext.autodoc']
numfig = True
numfig_format = {'figure':'图 %s','table':'表 %s','code-block':'代码 %s'}
language = 'zh_CN'
html_theme = 'alabaster'
exclude_patterns = []
