# EBL Sphinx RST 用户手册

本项目汇总完整 10 章及图片。

- 第 1–5 章：阶段四、五编辑稿。
- 第 6 章：PEC 分组整合版（上轮版本；仍有未经验证的 API 和技术问题）。
- 第 7 章：本轮按原始 DOCX 重组与中文润色，并保留原始 GUI 细节。
- 第 8–10 章：阶段二初步转换，尚未全面重组润色。

入口为 `source/index.rst`，配置为 `source/conf.py`。本包含图片，但可能存在初始转换保留的非网页友好格式；正式发布前需完成 Sphinx 严格编译以及源文完整性核查。

详细内容：`reports/chapter_07_review.md` 和 `reports/chapter_07_unresolved_issues.csv`。


## 本轮修订（第 8–9 章）

- 第 8 章已整理参数与可视化、PSF 功能及存档结构。
- 第 9 章已规范模块参数表及操作描述。
- 第 10 章保持初始转换内容，不进行重组。
- 待确认事项：`reports/chapter_08_09_technical_issues.csv`；验证报告：`reports/chapter_08_09_review.md`。


## 第六阶段状态（2026-11-02）

静态检查及确定性格式修复已完成，严格 Sphinx HTML 编译、图像 EMF 兼容验证和全部内容的双向语义验收尚未完成。详见 `reports/validation_report.md`。第 10 章保持初始转换内容。
