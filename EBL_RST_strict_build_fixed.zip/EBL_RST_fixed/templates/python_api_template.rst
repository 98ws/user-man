.. _api-import-cif-example:

import_cif（签名确认后使用）
==============================

.. py:function:: import_cif(layerSet, tolerance, keepOrder, precision, filename)

   导入 CIF 版图文件。（功能依据原文；此签名按原文参数顺序整理，仍须核实 Python 绑定。）

   :param layerSet: 加载的 layer 名称。
   :param tolerance: 圆形转换最大容差。
   :param keepOrder: 是否保留顺序。
   :param precision: 网格转换精度。
   :param filename: 文件路径。

   .. warning::

      原文使用 ``const char*``、``double``、``bool`` 等 C/C++ 类型。Python 实际类型、默认值、返回值、异常和绑定行为尚未核实，不得据此生成类型注解。

调用示例（原始内容，待运行验证）
----------------------------------

.. code-block:: python

   import_cif("L0D0",0.0, 0, 1000,"R: /test_01.CIF")

.. 注意：本文件是文档写作模板，不保证示例路径可用；严格禁止自动纠正示例字符串。
