# 项目静态验证

- 10 个章节 RST 文件均存在。
- 33 个第 7 章正式插图标签唯一、文件存在。
- 全部章节的相对图片引用经过路径检查；详细计数见 `project_validation_ch07.csv`。
- 全部 10 章经过 Pandoc RST 读取测试，结果见清单。
- 当前运行环境没有 `sphinx-build`，未执行 Sphinx `-n -W` 严格 HTML 编译；Pandoc 通过不代表 Sphinx 引用、指令均正确。
- 第 8–10 章仍是初步转换版；第 6 章保留此前 PEC 分组版本，仍需技术信息确认。
