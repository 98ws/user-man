# 第六阶段：全书验证报告

## 验收结果

**结果：阶段性静态检查通过，但最终发布验收未通过。** 不能以 Pandoc RST 解析成功替代 Sphinx 的严格编译或原文逐段语义核查。

- 工作基线：`EBL_RST_complete_ch08_ch09_revised.zip`。
- 范围：第 1–10 章；第 10 章保持阶段二初始转换版本，已进行字节级一致性确认。
- 所有 10 章均通过 Pandoc RST → JSON 解析测试。
- 图片引用 274 处；文件路径有效 274/274。项目 `source/media` 中共 287 个媒体文件（包含新增的 10 个 PNG 兼容副本，未清除原始附件）。
- RST `:ref:`、`:numref:` 引用 29 处；静态定位到对应标签 29/29。静态匹配并不保证 Sphinx 运行时有效性。
- 已修复第 8 章重复 `sec-8-4` 标签 1 处；10 个 PNG 数据的 `.tmp` 引用已转为 `.png` 副本。
- 仍有 8 处 EMF 图片引用，可能受 HTML 构建器或浏览器支持限制。
- 检查结果中未发现重复标签及图片路径缺失。

## 原始 Word 内容保护

原始 DOCX 有 2116 个 Word 段落、39 个 Word 表格及 257 个 inline shapes。这些数字与 RST 章节中的指令数量不能直接比较：复杂表格可能拆成多张表格，一张图片可能被复用；因此**不能宣称已经完成 1:1 无遗漏校验**。目录、标题、代码及 GUI 说明的全量人工双向审查仍待完成。

## Sphinx 严格编译

环境中没有安装 `sphinx-build`，本轮尝试通过 pip 安装 Sphinx 时，包索引域名解析失败。故 `sphinx-build -b html -n -W source build/html` **未执行**，HTML / PDF 排版、Python 域指令、`numfig` 编号的实际效果均未验证。

## 术语/技术问题

已将当前项目中与待确认事项相关的历史 CSV 汇总成 `stage6_consolidated_technical_issues.csv`，共 72 行，**这是历史条目汇编，不是 72 个去重后的技术错误**。包括仍需研发确认的接口参数、默认值、图形几何行为、GUI 路径和公式。

不能凭规范化策略替代实际软件行为；第 6 章的复杂参数和 API 文档需要人工研发核验。仍存在个别「原文列出」类提示，建议优先对第 5、6 章进行内容忠实度复核。

## 修复记录与限制

本轮仅自动修复有充分文件证据的格式问题，未修改原文技术事实、命令、默认值及数学公式。第 10 章未经重组润色。

## 本地继续验收

在安装了 Sphinx 的环境中执行：

```bash
python -m pip install sphinx
sphinx-build -b html -n -W source build/html
```

按编译警告修复指令缩进、跨文件引用、`py:function` 与媒体兼容性后，再根据原始 DOCX 和软件 UI/API 实际行为，逐模块确认参数/枚举/操作的完整性。

## 附表

- `stage6_chapter_inventory.csv`：章节 RST 元素清点。
- `stage6_media_inventory.csv`：图片引用和存在性。
- `stage6_safe_fixes.csv`：可确定的静态修复。
- `stage6_static_issues.csv`：静态剩余问题。
- `stage6_consolidated_technical_issues.csv`：历史待确认问题汇编。
