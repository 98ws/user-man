# EBL 中文用户手册统一技术写作规范（阶段三）

版本：1.0（待研发复核的术语尚未定稿）  
适用对象：本项目的 10 章 Sphinx RST 用户手册。  
边界：本文件只定义编辑规则，不表示原文技术准确性已经确认；本阶段不直接修改 10 章初始 RST。

## 1. 信息类型与内容组织

| 类型 | 读者问题 | 收录内容 | 不应混入 |
| --- | --- | --- | --- |
| Concept（功能说明） | 功能是什么、用途与前提是什么 | 用途、对象、输入输出、适用条件、必要原理 | 大量逐项 GUI 参数/接口表 |
| Procedure（任务指导） | 如何完成任务 | 前提、入口、操作步骤、结果、故障提示 | 完整 API 参考 |
| Reference（参考资料） | 参数有哪些、类型及含义是什么 | GUI 参数、Python 函数/参数/返回值/约束 | 长篇操作指导 |

按实际内容选择小节，禁止为模板凑段落。对 Import、Export 等多文件格式场景，可按 CIF/DXF/GDS 子功能分别组织。第 6 章模块按 Layout / Boolean / PEC / Verify / Control 分组，不预设任何模块都具有完整 GUI 与 Python API。

## 2. 写作原则与修改权限

- 简洁：删除不含必要信息的修饰；但保留先决条件、参数约束、异常、结果与警告。
- 客观：不用“丝滑”“显著提升”“轻松”等无法验证的评价。
- 准确：区分输入、处理、输出；不将尚待确认的算法效果或返回类型写成事实。
- 操作导向：优先“单击/选择/输入/拖动/保存/运行/查看”，每个步骤一个主要动作。
- 语言问题可改；结构问题可移动；技术定义、GUI 标签、API 签名/类型/默认值/单位必须核实；缺失项只写入 `missing_information.csv`，不编造。
- 不允许改变任何实际代码、文件名、路径、扩展名、标识符大小写、数值、调用顺序，或将 C++ 参数类型推断为 Python 类型。

## 3. 中文正文与术语规则

- 中文与英文、数字之间使用适当空格，如“使用 Python 接口”“导入 CIF 文件”；软件版本、代码、文件路径、GUI 原始标签不调整内部空格。
- 使用中文全角标点。英文引号及标点在原始代码、实际 GUI 标签和文件路径中原样保留。
- 概念首次出现可写“邻近效应校正（Proximity Effect Correction，PEC）”，但当前原文同时有“近邻/邻近”“校正/矫正/修正”，**须先由研发确认**，不得预先全局改写。
- 叙述中的蒙特卡洛/蒙卡建议候选写法“蒙特卡洛模拟”，但图题/界面名须对照实际软件。
- “模型节点”和“模块节点”需确认是否指同一对象；“图形展现/图形显示/图形可视化/布局查看器”也需区分。
- GUI 模块的英文名 Layout、Boolean、PEC、Verify、Control 等遵照实际 UI 拼写；`loop`、`LOOP`、`Python`、`PYTHON` 的差异不自动纠正。
- 每项术语决策以 `reports/terminology_glossary.csv` 为准：`推荐写法` 可作为编辑目标、`待技术确认` 暂保留、`技术标识符保留` 完全不改。

## 4. GUI 操作

- 同级任务使用动词导向标题，如“导入 CIF 版图”“连接模块节点”“查看执行结果”。
- 多步程序用 `#. `；不使用括号形式 `(1)` `(2)` 手动编号。
- 第一步给出已确认的操作入口；单个步骤只包含一个主要操作；必要时说明预期结果。
- 菜单路径写作“文件 > 新建流程”，**仅作为示例**，实际路径需对照截图或研发确认。
- 使用“单击”“双击”“右键单击”“选择”“输入”“拖动”，不笼统使用“点击一下/在这里处理”。
- 参数解释放在 GUI 参数表。步骤可引用关键参数，但不重复整张表。
- 将有操作价值的截图放在对应步骤附近；图题为内容说明而非“如下图”。
- 如果入口/按钮/结果在原文缺失，在待确认清单标记，不用猜测补全。

## 5. Python API 规范

- 使用 Sphinx Python 域 `.. py:function::` 记录 **经确认** 的 Python 可调用接口；函数名、参数顺序、默认值与调用方式必须有原文或研发证据。
- 原文 `import_cif(const char* layerSet, double tolerance, ...)` 是 C/C++ 风格声明；在 Python 文档中不能把 `const char*`、`double` 原样写进 `py:function` 签名，也不可直接推断映射为 `str`、`float` 等。可在文档中将经原文确认的参数名作为无注解的签名，同时把类型标记为待验证。
- 注意：`import_cif(layerSet, tolerance, keepOrder, precision, filename)` 是 **从原文参数顺序得到的候选展示签名**，必须通过绑定接口确认后方能作为已验证 API 发布。
- 参数按原始顺序逐项解释，单位、默认值、必选性、返回值不详则明确“待确认”。
- 保留已有 Python 调用示例原样；无法确认是有效 Python 代码的 C++ 形式示例放入 literal/text 区，不混淆为可执行脚本。
- GUI 产生的 Python 代码与官方可调用接口未必等同，不要假定所有模块签名一致。

## 6. RST 与结构

- 章节：独立 `chapter_XX.rst`；每章建立稳定的 :ref: 锚点；标题标记线须比标题长，并使用统一级别。
- 参考表格使用 `.. list-table::`，明确 `:header-rows:` 和 `:widths:`；合并单元格不适合无损转换时保持原信息并登记技术债，不压平丢失信息。
- 正式截图统一 `.. figure::`、唯一 `:name:`、图题无手动“图 N”，在正文使用 `:numref:`。表格内图标等非正式图片可用 `.. image::`。
- 图像宽度优先原 Word 显示宽度且原则上不超过 16 cm，无法确认时 10 cm；不改变纵横比。
- 所有显式引用使用稳定锚点和 `:ref:`/`:numref:`；绝不按数字全局替换图号。
- 命令/代码使用适合的 `.. code-block:: python`、`.. code-block:: tcl` 或 `.. code-block:: text`；不自动修改其缩进和符号。行内代码使用双反引号包裹实际路径及标识符。
- 请保留阶段二源位置映射。移动或合并段落后在 `structure_changes.csv` 记录旧/新位置；重大文字修改在 `writing_changes.csv` 记录原文与修订版。

## 7. QA 与验收边界

- 第四阶段逐模块审查 Concept/Procedure/Reference 是否按用户任务组织；不得仅统计移动段落次数。
- 第五阶段逐段比对原文语义，逐项保留参数/数值/警告/文件名，校对代码与真实 GUI 标签。
- 第六阶段检查 10 章、图片、表格、跨章引用，并运行 `sphinx-build -b html -n -W source build/html`；必要时检查 LaTeX/PDF 兼容性。
- 遗留：阶段二中的合并单元格、图号冲突、代码块识别与 Sphinx 未编译问题仍在报告中；本阶段不声明这些问题已修复。

## 8. 参考规范（借鉴原则，EBL 实际术语优先）

- Microsoft Writing Style Guide, Writing step-by-step instructions: https://learn.microsoft.com/style-guide/procedures-instructions/writing-step-by-step-instructions
- Google Developer Documentation Style Guide, Procedures: https://developers.google.com/style/procedures
- Red Hat modular docs guidance: https://redhat-documentation.github.io/modular-docs/
- Sphinx Python domain: https://www.sphinx-doc.org/en/master/usage/domains/python.html
- Sphinx figures and numbering: https://www.sphinx-doc.org/en/master/usage/restructuredtext/directives.html
- Python documentation style/reference: https://docs.python.org/3/documenting/
