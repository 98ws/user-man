from pathlib import Path
import re,json,csv,hashlib,difflib,struct
from bs4 import BeautifulSoup
from PIL import Image,ImageOps,ImageDraw
from urllib.parse import urlsplit,unquote
root=Path('/workspace/EBL_RST_fixed'); orig=Path('/workspace/ebl_original/EBL_RST'); out=root/'validation'
results={}; broken=[]; image_count=0; figure_count=0; tables=0; apis=0
pages={p.name:BeautifulSoup(p.read_text(),'html.parser') for p in (root/'build/html').glob('*.html')}
for name,soup in pages.items():
 p=root/'build/html'/name
 for a in soup.select('a[href]'):
  u=urlsplit(a['href'])
  if u.scheme or u.netloc:continue
  dest=p.parent/unquote(u.path) if u.path else p
  if not dest.exists():broken.append([name,a['href'],'missing file']);continue
  if u.fragment and dest.suffix=='.html':
   target=pages.get(dest.name)
   if target is None:target=BeautifulSoup(dest.read_text(),'html.parser')
   if not target.find(id=unquote(u.fragment)):broken.append([name,a['href'],'missing anchor'])
 for img in soup.select('img[src]'):
  image_count+=1;path=p.parent/unquote(img['src'])
  if not path.exists():broken.append([name,img['src'],'image missing'])
  else:
   with Image.open(path) as im:im.verify()
 figure_count+=len(soup.select('figcaption .caption-number'))
 tables+=len(soup.select('table'));apis+=len(soup.select('dl.py.function > dt'))
 assert not soup.select('.problematic, .system-message')
 assert '\ufffd' not in soup.get_text()
rows=[]
for n in range(1,11):
 name=f'chapter_{n:02d}.rst';a=(orig/'source'/name).read_text();b=(root/'source'/name).read_text()
 sig=lambda s:re.findall(r'^\.\. py:function::.*$',s,re.M)
 assert sig(a)==sig(b),name
 # Keep GUI table rows and technical values identical, allowing literal escape only.
 entries=lambda s:[l.replace('\\*','*') for l in s.splitlines() if re.match(r'^\s+(?:\* -|-) ',l)]
 assert entries(a)==entries(b),name
 rows.append({'chapter':n,'page_exists':f'chapter_{n:02d}.html' in pages,'tables':len(pages[f'chapter_{n:02d}.html'].select('table')),'api_signatures':len(sig(b)),'source_unchanged':a==b})
assert (orig/'source/chapter_10.rst').read_bytes()==(root/'source/chapter_10.rst').read_bytes()
results.update(chapters=rows,broken_local_links=broken,image_elements=image_count,numbered_figures=figure_count,tables=tables,api_functions=apis,replacement_character_count=0)
(out/'static_checks.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
# Record every changed source hunk, including exact before/after and original line numbers.
fixes=[]
for p in sorted((root/'source').rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(root);old=orig/rel
 if old.exists() and old.read_bytes()==p.read_bytes():continue
 if p.suffix=='.rst':
  a=old.read_text().splitlines(True);b=p.read_text().splitlines(True)
  for tag,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes():
   if tag=='equal':continue
   before=''.join(a[i:j]);after=''.join(b[k:l]);reason='修复标题下划线显示宽度或层级/消除标题与下划线间空行'
   if '.emf' in before:reason='保留 EMF 原图，引用等比例 PNG 以兼容 HTML 和 LaTeX'
   elif 'code-block' in before:reason='未经确认的示例原文不变，按纯文本展示；原始 Python 语法问题列入 remaining_issues.csv'
   elif '\\*' in after or '\\ ' in after:reason='修复行内 RST 标记边界或转义字面通配符，保持显示文本'
   fixes.append([str(rel),i+1,k+1,before,after,reason])
 else:fixes.append([str(rel),'','','（新增文件）',f'PNG {Image.open(p).size}', '由同名 EMF 页边界以 180 DPI 导出；未裁剪、未指定独立宽高，保留原图'])
with (root/'build_fixes.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['file','original_line','fixed_line','before','after','reason']);w.writerows(fixes)
# Conversion contact sheet
files=sorted((root/'source').rglob('*.emf'));canvas=Image.new('RGB',(1000,260*4),'white');draw=ImageDraw.Draw(canvas)
for i,p in enumerate(files):
 im=Image.open(p.with_suffix('.png')).convert('RGBA');bg=Image.new('RGBA',im.size,'white');bg.alpha_composite(im);bg.thumbnail((480,225));x=(i%2)*500;y=(i//2)*260;canvas.paste(bg.convert('RGB'),(x,y+25));draw.text((x+5,y+4),p.name,fill='black')
canvas.save(out/'emf_contact_sheet.png')
print(json.dumps(results,ensure_ascii=False));print('fix records',len(fixes))
