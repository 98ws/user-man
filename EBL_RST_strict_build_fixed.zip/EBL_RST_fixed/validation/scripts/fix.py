from pathlib import Path
import re,subprocess,os
root=Path('/workspace/EBL_RST_fixed'); p=root/'source/chapter_06.rst'
s=p.read_text()
# Bias direct subsections at level four, subordinate items at level five.
a=s.index('6.1.3 Bias 模块'); b=s.index('.. _sec-6-1-4:',a)
part=s[a:b]; part=re.sub(r'(?m)^([\^\"]+)\s*$',lambda m: ('^' if m[1][0]=='"' else '"')*len(m[1]),part); s=s[:a]+part+s[b:]
for title in ['Archive 模式','Gaussian Approximation 模式','Numerical PSF 模式']:
 s=re.sub(re.escape(title)+r'\n\n("+)\n',lambda m:title+'\n'+'+'*max(40,len(title))+'\n\n',s)
# Preserve unverified source examples verbatim; do not claim valid Python syntax.
lines=s.splitlines(True)
for target in ['export_cpg (','export_edw (','spec(dm_Import_1,']:
 for i,l in enumerate(lines):
  if l.lstrip().startswith(target):
   j=i
   while j>=0 and '.. code-block::' not in lines[j]:j-=1
   assert j>=0
   lines[j]=lines[j].replace('code-block:: python','code-block:: text')
s=''.join(lines)
# Escape literal wildcard markers only on diagnosed prose/table rows.
for old in ['选择要处理的区域。*代表所有区域，也可以输入单独的区域。','     - 列表中含独立的 *，因此选择全部图层','   * - *,1(0)','   * - 1(0),*,2(0)','     - 检查 Short Range Layer List 的通配符。只要列表中包含独立的 *，就表示所有图层。']:
 new=old.replace('*',r'\*') if not old.startswith('   * -') else old[:7]+old[7:].replace('*',r'\*')
 s=s.replace(old,new)
p.write_text(s)
for name,token in [('chapter_07.rst','``Apply``'),('chapter_09.rst','``mdc_layer$num``')]:
 p=root/'source'/name;s=p.read_text();s=s.replace(token+'（',token+'\\ （');p.write_text(s)
# Fix only title-underlining diagnostics from the actual first build.
log=(root/'sphinx_build.log').read_text()
from docutils.utils import column_width
for name in ['chapter_03.rst','chapter_06.rst','chapter_07.rst']:
 p=root/'source'/name; lines=p.read_text().splitlines(True)
 # All genuine adjacent title underlines in these files; no code content matches.
 for i in range(1,len(lines)):
  line=lines[i].strip()
  if line and len(set(line))==1 and line[0] in '=-~^"+' and lines[i-1].strip() and not lines[i].startswith(' '):
   w=column_width(lines[i-1].rstrip())
   if len(line)<w:lines[i]=line[0]*w+'\n'
 p.write_text(''.join(lines))
env=os.environ.copy();env.update(XDG_CONFIG_HOME='/tmp/ebl-inkscape/config',XDG_CACHE_HOME='/tmp/ebl-inkscape/cache')
with (root/'image_conversion.log').open('w') as log:
 for p in sorted((root/'source').rglob('*.emf')):
  out=p.with_suffix('.png');assert not out.exists()
  r=subprocess.run(['inkscape',str(p),'--export-type=png','--export-area-page','--export-dpi=180','--export-filename='+str(out)],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  log.write(str(p.relative_to(root))+'\n'+r.stdout+'\nexit='+str(r.returncode)+'\n');assert r.returncode==0 and out.exists()
  for rst in (root/'source').glob('*.rst'):
   text=rst.read_text();new=text.replace(str(p.relative_to(root/'source')),str(out.relative_to(root/'source')))
   if text!=new:rst.write_text(new)
print('Fixes and 8 conversions completed')
