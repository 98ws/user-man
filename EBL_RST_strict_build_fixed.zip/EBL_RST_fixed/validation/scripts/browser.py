from playwright.sync_api import sync_playwright
from pathlib import Path
import json
import threading,http.server,functools
server=http.server.ThreadingHTTPServer(("127.0.0.1",0),functools.partial(http.server.SimpleHTTPRequestHandler,directory="/workspace/EBL_RST_fixed/build/html"))
threading.Thread(target=server.serve_forever,daemon=True).start()
root=Path('/workspace/EBL_RST_fixed');results=[]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1440,'height':1100},device_scale_factor=1)
 for n in range(1,11):
  page.goto(f'http://127.0.0.1:{server.server_port}/chapter_{n:02d}.html');page.wait_for_load_state('networkidle')
  data=page.evaluate('''() => ({images: [...document.images].length, brokenImages: [...document.images].filter(i=>!i.complete||!i.naturalWidth).map(i=>i.src), tables: document.querySelectorAll('table').length, badRows: [...document.querySelectorAll('table tr')].filter(r=>r.querySelectorAll('td,th').length===0).length, figures: [...document.querySelectorAll('figcaption .caption-number')].map(i=>i.innerText), problematic: document.querySelectorAll('.problematic,.system-message').length, bodyScrollWidth:document.body.scrollWidth})''')
  data['chapter']=n;results.append(data)
  if n in [6,7,10]:page.screenshot(path=str(root/f'validation/chapter_{n:02d}_top.png'))
  if n==6:
   page.locator('dl.py.function').first.scroll_into_view_if_needed();page.screenshot(path=str(root/'validation/python_api.png'))
   page.locator('table').first.scroll_into_view_if_needed();page.screenshot(path=str(root/'validation/gui_table.png'))
 browser.close()
(root/'validation/browser_checks.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print(json.dumps(results,ensure_ascii=False));assert all(not x['brokenImages'] and not x['problematic'] and not x['badRows'] for x in results)
