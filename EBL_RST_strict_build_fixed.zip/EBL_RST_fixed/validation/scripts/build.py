from pathlib import Path
import subprocess,sys
root=Path('/workspace/EBL_RST_fixed')
for builder in sys.argv[1:]:
 cmd=['/workspace/ebl-venv/bin/sphinx-build','-E','-a','-b',builder,'-n','-W','--keep-going','source','build/'+builder]
 r=subprocess.run(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 with (root/'sphinx_build.log').open('a') as f:f.write('\n=== '+ ' '.join(cmd)+' ===\n'+r.stdout+'\nEXIT STATUS: '+str(r.returncode)+'\n')
 print(builder,'exit',r.returncode)
 print('\n'.join(l for l in r.stdout.splitlines() if any(t in l for t in ['WARNING:','ERROR:','succeeded','problems'])))
