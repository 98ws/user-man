.. _ch09:

9. 图形检查
=================

MDC（Mask Data Calculation） 工具支持对各类半导体工艺节点的版图进行操作、检查和分析。工具以 recipe 为功能实现载体，recipe 文件以“.rx”为后缀，遵循国微芯 RVRF 语法。

可通过图形化界面定义作业名称、输入源、运算规则、输出格式及运行环境，生成对应的脚本规则文件，并实现自动化数据比对、几何分析、规则验证与结果导出。

选择工具 -> MDC 工具，打开MDC Flow界面。

.. figure:: media/09/img_001.png
   :name: fig-ch09-img001
   :width: 6.4cm
   :align: center

   MDC FLOW启动入口

.. _sec-9-1:

9.1 界面布局
-------------------

界面分为左右两大区域。

左侧是参数配置区，按自上而下顺序包含五个功能模块：System（系统设置）、Input（输入数据库）、Operation（层操作命令）、Exclude SRAM Area（排除SRAM区域）和Output（输出层与格式）。

右侧为 Rule 模块，用于显示已添加的所有操作规则列表。该区域支持Clear（清除）、Edit（编辑）和Undo（撤销）操作，并在底部提供Save（保存）、Run（运行）和Close（关闭）三个控制按钮。

所有左侧配置需点击对应模块下方的“Add”按钮后，才会提交至右侧 Rule 区生效。

.. figure:: media/09/img_002.png
   :name: fig-ch09-img002
   :width: 12.69cm
   :align: center

   MDC FLOW界面布局

.. _sec-9-2:

9.2 模块介绍
-------------------

.. _sec-9-2-1:

9.2.1 System模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Job Name：输入文件名。

运行模式选择：有Local和LSF两种。Local在本地机器上运行，适合小规模测试。填写Thread（线程数，如32），控制并行度。LSF提交到集群调度系统，需填写Thread、Queue（指定提交作业的队列名=）和Core Num（核数），适用于大规模批处理。

.. figure:: media/09/img_003.png
   :name: fig-ch09-img003
   :width: 11.14cm
   :align: center

   System模块

.. _sec-9-2-2:

9.2.2 Input模块：
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Input模块定义要处理的原始数据库及其属性。

.. figure:: media/09/img_004.png
   :name: fig-ch09-img004
   :width: 12.01cm
   :align: center

   Input模块

下表介绍Input模块参数详情。

表9.1 Input 模块参数说明

.. list-table::
   :header-rows: 1
   :widths: 50 50

   * - 参数
     - 描述
   * - DB下拉按钮
     - 选择数据库编号（包含DB1和DB2两个选项）
   * - LibID下拉按钮
     - 选择输入版图（包含当前读入的所有版图ID）
   * - Precision
     - 指定操作精度（通常与输入版图dbu一致）
   * - Format
     - 自动读取对应版图的格式
   * - Mode
     - 包含FAB和MASK两个选项

参数设置完成后，点击 Add，根据上面选择的各项参数，在右侧 Rule 框内，生成输入模块的 rule，如下图所示。

.. figure:: media/09/img_005.png
   :name: fig-ch09-img005
   :width: 10.55cm
   :align: center

   Input模块的rule

.. _sec-9-2-3:

9.2.3 Operation模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Operation模块定义对版图层进行的操作。

.. figure:: media/09/img_006.png
   :name: fig-ch09-img006
   :width: 10.53cm
   :align: center

   Operation 操作 1

.. figure:: media/09/img_007.png
   :name: fig-ch09-img007
   :width: 10.5cm
   :align: center

   Operation 操作 2

下表介绍Operation模块参数详情。

表9.2 Operation模块参数说明

.. list-table::
   :header-rows: 1
   :widths: 50 50

   * - 参数
     - 描述
   * - Command下拉框
     - 选择操作类型，包含AND、OR、NOT、XOR、SIZING、AREA、SPACE、WIDTH和WITHWIDTH等选项（WITHWIDTH 的约束条件为：> 0.499 < 0.571）
   * - Layer1/ Layer2下拉框
     - 包含DB里面所有的layer，以layer name（layer number）形式显示
   * - Constraint
     - 约束条件，根据Command来确定，AND、OR、NOT、XOR命令不需要设置参数，SIZING、AREA、SPACE、WIDTH等命令需要设置参数

点击 Add，在右侧 Rule 框内生成输出模块的 rule，输出 layer name 统一为 mdc_layer$num（num 从 1 依次 +1）。

.. figure:: media/09/img_008.png
   :name: fig-ch09-img008
   :width: 9.7cm
   :align: center

   Operation 操作 1和操作2的rule

.. _sec-9-2-4:

9.2.4 Exclude SRAM Area模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

可选项，如需排除特定区域（如SRAM单元）进行计算，SRAM Layer选择要排除的图层，点击Add加入排除列表。

.. figure:: media/09/img_009.png
   :name: fig-ch09-img009
   :width: 10.52cm
   :align: center

   Exclude SRAM Area模块

.. _sec-9-2-5:

9.2.5 Output模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

定义最终输出，勾选复选框表示启用改输出项。

.. figure:: media/09/img_010.png
   :name: fig-ch09-img010
   :width: 10.19cm
   :align: center

   Output模块

下表介绍Output模块参数详情。

表9.3 Output模块参数说明

.. list-table::
   :header-rows: 1
   :widths: 50 50

   * - 参数
     - 描述
   * - Layer下拉框
     - 包含已填rule中所有的layer，包含DB中的layer，支持都选或任选其一
   * - Layer Num
     - 自定义输出层编号（如100.0）
   * - Format下拉框
     - 指定输出版图为OASIS或GDSII格式
   * - RESULTS下拉框
     - 包含已填 rule 中所有的 layer，包括 DB 中的 layer，支持都选或者任选其一
   * - ASCII Num
     - 自定义输出的结果个数上限，可以填写正整数或 MAX（输出所有结果）
   * - Path
     - 输入文件路径，不需要文件名，默认在Path路径下输出以Job Name命名的oas

.. _sec-9-2-6:

9.2.6 Rule模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~

左侧界面按顺序设置后，右侧Rule框会自动、实时生成对应的脚本命令。除了自动生成，还可以在此面板中对脚本进行手动清除、编辑或撤销操作，以实现更灵活或更复杂的操作。

.. figure:: media/09/img_011.png
   :name: fig-ch09-img011
   :width: 4.49cm
   :align: center

   Rule模块

下表介绍Rule模块参数详情

表9.4 Rule模块参数说明

.. list-table::
   :header-rows: 1
   :widths: 50 50

   * - 参数
     - 描述
   * - Rule框
     - 实时显示rule
   * - Clear
     - 清空框内数据
   * - Edit
     - 编辑框内内容
   * - Undo
     - 撤销Input/Operation/Output中最近一次添加的rule
   * - Save
     - 将当前Rule框中的脚本内容以.rx文件形式保存起来
   * - Run
     - 按照System模块参数来运行rule，这是启动整个图形检查流程的最终步骤
   * - Close
     - 关闭窗口

Rule框内显示rule的效果如下：

.. figure:: media/09/img_012.png
   :name: fig-ch09-img012
   :width: 11.77cm
   :align: center

   Rule框内显示rule

Rule框下方的提示框默认为空白，如果编辑之后有错误或警告，提示框会给出信息。比如将AND错改为AND1，下方会给出错误提示：

.. figure:: media/09/img_013.png
   :name: fig-ch09-img013
   :width: 9.63cm
   :align: center

   Rule模块内错误提示

点击Run之后的运行日志类似下图：

.. figure:: media/09/img_014.png
   :name: fig-ch09-img014
   :width: 10.85cm
   :align: center

   MDC FLOW运行日志

