.. _ch06:

6. 模块
=============

把功能内聚的特征以模块的方式提供出来，在流程编排中重复使用。EBL中模块分为5大类， 分别为Layout，Boolean，PEC，Verify，Control。下面分别做一下简介。

Layout分组：

版图相关的模块，包括版图导入导出（Import、Export），图形处理类（Bias、Extract、Fields、Filter、Fracture、Grid、Heal、Mapping、Merge、NOT、PXOR、Replace、Transform）。

如图10所示，通过左侧边，选择 Layout 打开Module面板，选择所需的版图相关的模块，进行流程编排。

.. image:: media/06/img_001.png
   :width: 12.53cm
   :align: center

.. figure:: media/06/img_002.png
   :name: fig-ch06-img002
   :width: 12.51cm
   :align: center

   Layout分组中的模块

Boolean分组：

图形布尔处理分组， 包含4个模块： AND、MINUS、OR、XOR，满足流程中对布尔运算的需求。

.. image:: media/06/img_003.png
   :width: 6.69cm
   :align: center

.. image:: media/06/img_004.png
   :width: 6.69cm
   :align: center

.. figure:: media/06/img_005.png
   :name: fig-ch06-img005
   :width: 6.52cm
   :align: center

   Boolean分组中的模块

PEC分组：

.. image:: media/06/img_006.png
   :width: 6.51cm
   :align: center

.. image:: media/06/img_007.png
   :width: 6.75cm
   :align: center

.. image:: media/06/img_008.png
   :width: 6.72cm
   :align: center

.. image:: media/06/img_009.png
   :width: 6.76cm
   :align: center

.. image:: media/06/img_010.png
   :width: 6.71cm
   :align: center

控制分组， 包含6个模块： EXIT、IF、LOOP、PYTHON、SELECT、SPLIT, 提供分支，循环，退出，python命令等功能，便于用户轻松搭建复杂工作流。

.. _sec-6-1:

6.1 Layout分组
---------------------------

.. _sec-6-1-1:

6.1.1 Import模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

CIF导入

工具支持将CIF版图文件导入到系统中，导入前需要设置如下的参数：

File: CIF版图文件的路径

Layer Set: 需要加载的版图中的layer，默认为“*”，表示加载版图中的所有layer，或者使用61（2），62（0），表示第61.2和62.0层

Tolerance：圆形转换最大容差

Keep Order：是否保留顺序

Precision：网格转换精度

.. image:: media/06/img_011.png
   :width: 14.66cm
   :align: center

.. image:: media/06/img_012.png
   :width: 14.66cm
   :align: center

CIF文件导入后的效果如下图所示：

.. image:: media/06/img_013.png
   :width: 14.62cm
   :align: center

Python接口参数说明：

import_cif(

const char* layerSet, # 加载的layer的名字

double tolerance,  # 圆形转换最大容差

bool keepOrder,    # 是否保留顺序

double precision,  # 网格转换精度

const char* filename  # 文件路径

)

示例：

import_cif("L0D0",0.0, 0, 1000,"R: /test_01.CIF")

DXF导入

工具支持将DXF版图文件导入到系统中，导入前需要设置如下的参数：

File: DXF图文件的路径

Layer Set:需要加载的版图中的layer，默认为“*”，表示加载版图中的所有layer，或者使用61（2），62（0），表示第61.2和62.0层

Tolerance：圆形转换最大容差

Keep Order：是否保留顺序

Precision：网格转换精度

.. image:: media/06/img_014.png
   :width: 14.66cm
   :align: center

.. image:: media/06/img_015.png
   :width: 14.66cm
   :align: center

DXF导入效果如下图所示：

.. image:: media/06/img_016.png
   :width: 14.66cm
   :align: center

Python接口参数说明：

import_dxf(

const char* layerSet, # 加载的layer的名字

double tolerance,  # 圆形转换最大容差

bool keepOrder,    # 是否保留顺序

double precision,  # 网格转换精度

const char* filename  # 文件路径

)

示例：

import_dxf("*",0.0, 0, 1000,"R:/ProjectData/test_02.DXF")

GDS导入

工具支持将GDS版图文件导入到系统中，导入前需要设置如下的参数：

File: GDS版图文件的路径

Layer Set:需要加载的版图中的layer，默认为“*”，表示加载版图中的所有layer，或者使用61（2），62（0），表示第61.2和62.0层

Import Zero Width Path: 是否导入宽度是0的path

Tolerance：最大容差

Keep Path Element：是否保留path

Import Boxes：是否导入box，选择false转成polygon

Keep Order Of Element：是否保留顺序, 选择True，图形按左下，右下，右上，左上的顺序加载版图

Flatten Layout: 是否需要展平

Overlap Gap Detect: 是否需要检测overlap gap，运行结果在可执行程序的路径下

Overlap Gap MinSize: overlap gap的最小尺寸

Load Text Ele: 是否加载text

Convert Text Size: 转换text的尺寸大小

Convert Text To Polys: 是否将text转成polygon

Circle: 是否校验圆

Ring: 是否校验环

ArcBow: 是否校验弧

Sector: 是否校验扇形

Ellipse: 是否校验椭圆

rotRect: 是否校验旋转矩形

Parallelogram: 是否校验平行四边形

Quadrangle: 是否校验四边形

curveDetection: 是否曲线校验

.. image:: media/06/img_017.tmp
   :width: 14.65cm
   :align: center

.. image:: media/06/img_018.tmp
   :width: 14.65cm
   :align: center

GDS文件导入后的效果如下图所示：

.. image:: media/06/img_019.tmp
   :width: 14.65cm
   :align: center

Python接口参数说明：

import_gds(

const char* layerSet, # 加载的layer的名字

bool importBoxes, # 是否导入box

bool importZeroWidthPath, # 是否导入线宽为0的path

double lineWidth, # 线宽

bool keepOrderOfElement,  # 是否保留顺序

bool flattenLayout, #是否需要展平

bool overlapGapDetect, #是否需要检测overlap gap

double overlapGapMinSize, #overlap gap的最小尺寸

bool loadTextEle, #是否加载text

double convertTextSize, #转换text的尺寸大小

bool convertTextToPolys, #是否将text转成polygon

bool keepPathElement, #是否保留path

bool circle, #是否校验圆

bool ring, #是否校验环

bool arcBow, #是否校验弧

bool sector, #是否校验扇形

bool ellipse, #是否校验椭圆

bool rotRect, #是否校验旋转矩形

bool parallelogram, #是否校验平行四边形

bool quadrangle, #是否校验四边形

double tolerance, # 圆形转换最大容差

bool curveDetection, #是否曲线校验

const char* filename  # 文件路径

);

示例：

import_gds("", 1, 1, 0, 0, 0, 0, 0, 1, 1.0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,"R: /test_01.GDS");

OASIS导入

工具支持将OASIS版图文件导入到系统中，导入前需要设置如下的参数：

File: OASIS版图文件的路径

Layer Set:需要加载的版图中的layer，默认为“*”，表示加载版图中的所有layer，或者使用61（2），62（0），表示第61.2和62.0层

Import Zero Width Path: 是否导入宽度为0的path

Tolerance：圆形转换最大容差

Keep Path Element：是否保留path

Apply Polygon Validation: 是否多边形验证

.. image:: media/06/img_020.tmp
   :width: 14.65cm
   :align: center

.. image:: media/06/img_021.tmp
   :width: 14.65cm
   :align: center

OASIS文件导入后的效果如下图所示：

.. image:: media/06/img_022.tmp
   :width: 14.65cm
   :align: center

Python接口参数说明：

import_oasis(

const char* layerSet, # 加载的layer的名字

bool importZeroWidthPath, # 是否导入线宽为0的path

double lineWidth, # 线宽

bool applyPolygonValidation, #是否多边形验证

double tolerance, # 圆形转换最大容差

bool keepPathElement, #是否保留path

const char* filename # 文件路径

)

示例：

import_oasis("", 1, 0, 0, 0, 1,"R: /test_01.oas");

CPG导入

工具支持将CPG版图文件导入到系统中，导入前需要设置如下的参数：

File: CPG版图文件的路径

.. image:: media/06/img_023.tmp
   :width: 14.65cm
   :align: center

CPG文件导入后的效果如下图所示：

.. image:: media/06/img_024.tmp
   :width: 14.65cm
   :align: center

Python接口参数说明：

import_cpg(

const char* fileName, #加载的layer的名字

);

示例：

import_cpg("R: /test_01.cpg");

EDW导入

工具支持将EDW版图文件导入到系统中，导入前需要设置如下的参数：

File: EDW版图文件的路径

.. image:: media/06/img_025.tmp
   :width: 14.65cm
   :align: center

EDW文件导入后的效果如下图所示：

.. image:: media/06/img_026.tmp
   :width: 14.65cm
   :align: center

Python接口参数说明：

import_edw(

const char* fileName, #加载的layer的名字

);

示例：

import_edw( "R: /test_01.edw");

.. _sec-6-1-2:

6.1.2 Export模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

介绍界面参数意义、功能原理、效果、python接口参数等；

CIF导出

工具支持将已经加载到系统中的版图导出为CIF格式的版图文件，导出前需要设置如下参数：

File：文件导出路径

.. image:: media/06/img_027.png
   :width: 14.66cm
   :align: center

Python接口参数说明：

export_cif (

dmLib* lib，          # 导出版图的lib指针

const char* filename  # 导出文件路径

)

示例：

export_cif(dm_Import_1,"R:/ProjectData/0.cif")

DXF导出

工具支持将当前已经加载到系统中的版图导出为DXF格式的版图文件，导出前需要设置如下参数：

File：导出路径

.. image:: media/06/img_028.png
   :width: 14.66cm
   :align: center

Python接口参数说明：

export_dxf (

dmLib* lib，          # 导出版图的lib指针

const char* filename  # 导出文件路径

)

示例：

export_dxf (dm_Import_1,"R:/ProjectData/0.dxf")

GDS导出

工具支持将已经加载到系统中的版图导出为GDS格式的版图文件，导出前需要设置如下参数：

File：文件导出路径

Layer Set: 需要导出的版图中的layer，“*”表示加载版图中的所有layer

Max Poly Vertices：多边形的顶点数最大值

Dose mapping：dose输出的类型: 0:property, 1:layer, 2:dataType, 3:none

Tolerance：圆形转换最大容差

Flatten Leaves：需要展平的层数

.. image:: media/06/img_029.tmp
   :width: 14.65cm
   :align: center

Python接口参数说明：

export_gds(

dmLib* lib, # 导出版图的lib指针

const char* fileName, # 导出文件路径

const char* layerSet, #需要导出的版图中的layer，“*”表示加载版图中的所有layer

unsigned flattenLeaves, #需要展平的层数

int maxPolyVertices, #多边形的顶点数最大值

int doseMapping, # dose输出的类型 0:property, 1:layer, 2:dataType, 3:none

double tolerance, #圆形转换最大容差

bool viewResult #是否显示版图结果

)

示例：

export_gds(dm_Import_1,"R:/ProjectData/0.cif","", 2, 100, 1, 0.0, false);

OASIS导出

工具支持将已经加载到系统中的版图导出为OASIS格式的版图文件，导出前需要设置如下参数：

File：文件导出路径

Dose mapping：dose输出的类型

Tolerance：圆形转换最大容差

Flatten Leaves：需要展平的层数

.. image:: media/06/img_030.tmp
   :width: 14.65cm
   :align: center

Python接口参数说明：

export_oasis (

dmLib* lib, # 导出版图的lib指针

const char* fileName, # 导出文件路径

unsigned flattenLeaves, #需要展平的层数

int doseMapping, # dose输出的类型 0:property, 1:layer, 2:dataType, 3:none

double tolerance, #圆形转换最大容差

bool viewResult #是否显示版图结果

)

示例：

export_oasis(dm_Import_1,"R:/ProjectData/0.oas", 2, 1, 0.0, false);

CPG导出

工具支持将已经加载到系统中的版图导出为CPG格式的版图文件，导出前需要设置如下参数：

File：文件导出路径

Mainfield Resolution：主场分辨率

Mainfield Size X：主场X方向尺寸

Mainfield Size Y：主场Y方向尺寸

Subfield Resolution：子场分辨率

Subfield Size X：子场X方向尺寸

Subfield Size Y：子场Y方向尺寸

Resolution：分辨率

Beam Step Size：电子束步长

.. image:: media/06/img_031.tmp
   :width: 14.65cm
   :align: center

Python接口参数说明：

export_cpg(

dmLib* in_lib, # 导出版图的lib指针

const char* outFile, # 导出文件路径

double mainRes, # 主场分辨率

double mainSizeX, # 主场X方向尺寸

double mainSizeY, #主场Y方向尺寸

int mainMSF, # 主场多重步进系数

double subRes, # 子场分辨率

double subSizeX, # 子场X方向尺寸

double subSizeY, # 子场Y方向尺寸

int subMSF, # 子场多重步进系数

double res=0.001, # 分辨率

double bss=0.008, #电子束步长

bool viewResult=false #是否显示版图结果

);

示例：

export_cpg (dm_Import_1,"R:/ProjectData/0.cpg", 0.001, 100, 100, 1，0.001, 10, 10, 1, 0.001, 0.008, false);

EDW导出

工具支持将已经加载到系统中的版图导出为EDW格式的版图文件，导出前需要设置如下参数：

File：文件导出路径

Mainfield Resolution：主场分辨率

Mainfield Size X：主场X方向尺寸

Mainfield Size Y：主场Y方向尺寸

Subfield Resolution：子场分辨率

Subfield Size X：子场X方向尺寸

Subfield Size Y：子场Y方向尺寸

Resolution：分辨率

Beam Step Size：电子束步长

.. image:: media/06/img_032.tmp
   :width: 14.65cm
   :align: center

Python接口参数说明：

export_edw(

dmLib* in_lib, # 导出版图的lib指针

const char* outFile, # 导出文件路径

double mainRes, # 主场分辨率

double mainSizeX, # 主场X方向尺寸

double mainSizeY, #主场Y方向尺寸

int mainMSF, # 主场多重步进系数

double subRes, # 子场分辨率

double subSizeX, # 子场X方向尺寸

double subSizeY, # 子场Y方向尺寸

int subMSF, # 子场多重步进系数

double res=0.001, # 分辨率

double bss=0.008, #电子束步长

bool viewResult=false #是否显示版图结果

);

示例：

export_edw (dm_Import_1,"R:/ProjectData/0.edw", 0.001, 100, 100, 1，0.001, 10, 10, 1, 0.001, 0.008, false);

.. _sec-6-1-3:

6.1.3 Bias模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~

Bias模块允许对布局中的多边形施加几何偏置，可为正偏置或负偏置。如果对两个或更多相邻形状施加正偏置，它们会一起愈合。

.. image:: media/06/img_033.png
   :width: 14.65cm
   :align: center

Bias参数会对所有多边形的各边加上或减去所输入的尺寸值。在下例中，深蓝色轮廓表示原始布局，宽度为1μm。在下面所示的示例中，对原始图案施加了0.2μm的正偏置以生成绿色轮廓，并对原始图案施加了-0.2μm的负偏置以生成红色轮廓。此处操作使用的是X-Y模式。

.. image:: media/06/img_034.emf
   :width: 14.65cm
   :align: center

如果需要对图案仅施加X或Y方向的偏置，可以分别选择X或Y模式。

接下来介绍Bias Tab的具体参数：

所有层

.. image:: media/06/img_035.png
   :width: 10.61cm
   :align: center

默认情况下，所有层会一起处理。结果是层信息会丢失，且生成的数据会被放置在单一目标层上。输入偏置值和模式：可选择X and Y、仅X、仅Y。

每层

.. image:: media/06/img_036.png
   :width: 10.82cm
   :align: center

如果文件已导入并执行（Run按钮），则可在Layer Selection（层选择）菜单中显示层列表，输入偏置值和模式：可选择X and Y、仅X、仅Y。

特定层

.. image:: media/06/img_037.png
   :width: 10.34cm
   :align: center

同样，如果文件已导入并执行（Run按钮），可选择所需的层，输入偏置值和模式：可选择X and Y、仅X、仅Y。

位置依赖

.. image:: media/06/img_038.png
   :width: 9.98cm
   :align: center

可以对基板上的不同位置施加不同值的偏置。此功能可用于补偿较大区域内非均匀的工艺效应。

下面介绍扩展参数：

.. image:: media/06/img_039.png
   :width: 10.9cm
   :align: center

out_layer

输出的层信息

corner Extension

Corner Extension（拐角延伸）参数控制这些延伸被截断的距离。默认的Corner Extension（CE）为1.0。我们使用偏置通过以下公式来定义拐角顶点的位移:

CE*sqrt(2)*Bias_value

此公式得出的是平分拐角角度的正交线的长度。此长度是使用偏置可放置拐角顶点的最大距离。

CE=1.0意味着截断长度等于偏置量的平方根，换言之，CE值对使用偏置后拐角顶点的新位移施加了限制。一个使用90度拐角的简单示例说明了CE的影响。我们希望偏置的形状以蓝色显示，而正偏置后的预期形状以黑色虚线轮廓显示。下面使用CE=1.0，正方形按预期施加正偏置，拐角值无变化。需要说明的是，公式并不规定当CE >> 1时顶点放置在何处；它只是允许顶点移动时比CE < 1时受到更少的限制。

.. image:: media/06/img_040.emf
   :width: 7.07cm
   :align: center

通过在施加正偏置时使用CE值为0.5，拐角被截断一半，有效地在版图中使拐角变圆。由于拐角位移的限值为一半，该限值对拐角施加了截断，如下所示。在这种情况下，公式规定拐角不能延伸超过正交平分拐角角度的线的计算长度。结果是拐角被截断。

.. image:: media/06/img_041.emf
   :width: 6.96cm
   :align: center

下面所示是一个以蓝色三角形为例，用CE=1将其正偏置10nm至灰色三角形的示例。由于原始拐角位置到偏置位置的距离被限制为14nm，拐角被截断，如左下所示。当使用CE=2时，距离限值增至28nm，允许拐角被放置在原始位置上方22nm处。

.. image:: media/06/img_042.emf
   :width: 10.98cm
   :align: center

soft Frame

Soft Frame（软框）操作使用内存中的虚拟分块来快速执行此操作。整个图案被划分为虚拟分块，每个分块被传递给可用的处理核心来执行。根据图案的大小和可用内存，会生成或多或少的分块，并在分块上并行执行所需的操作。一旦所有分块都被处理完毕，它们会被重新组装为一个图案。Soft Frame参数即为这些虚拟分块之间的重叠部分。本质上，任何等于或小于Soft Frame（重叠）大小的特征都不会在虚拟分块操作中被切分。由于小于0.300μm的特征大小在此操作中可能因产生非最佳断裂而敏感于被切分，因此如果不确定该使用何值，可保留默认的Soft Frame值0.300μm

hier Processing

是否是hier结构的处理，目前都是false，转成flatten处理。

Extent

.. image:: media/06/img_043.png
   :width: 10.24cm
   :align: center

According to bias: 负偏置收缩；正偏置增长，始终保持对称以维持中心不变。

Automatic (default): 负偏置保持原有范围；正偏置增长，始终保持对称，以维持中心不变。

Fixed: 无论负偏置还是正偏置，都保持原有的范围。如果几何图形增长超出原有范围，则会发出错误提示。

is Size

如果is Size设置为true，默认不对图形进行愈合操作，除此以外，其他跟Bias一致。

Python接口说明及示例：

eblBias(dm_Import_1, 	 #input dmlib pair

"{}",  			 #in_layers

"10(0)",  		 #out_layer

1,  		 #cornerExtension

0.3,  		 #softFrame

0,  		 #hierProcessing

1,   		 #extent

0,   		 #isSize

1,  		 #is_position_dependent

1,   		#min_segment_size

2,   		#matrix_to_layout_alignment

0,   		#outside_matrix_behaviour

1,  		#cell_A1_position

0.0,   		#x_start

0.0,   		#y_start

0.2,  		#x_grid

0.2,  		#y_grid

])  		#grid_bias

.. _sec-6-1-4:

6.1.4 Extract模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Extract模块是一个版图提取引擎，用于从原始布局中提取特定层、特定单元或者特定区域的数据，生成一个新的库。

提取首先在层级处理，然后是提取类型：Entire Layout（整个布局）、Cell Instances（单元实例）、Cell Definition（单元定义）或Region（区域）。默认情况下，使用通配符（*）提取所有层。如果在in layers字段中输入了特定层，则仅提取所选提取类型对应的那些层。本模块还支持使用单元名称进行提取，方法是在选择Cell Instances（单元实例）或Cell Definition（单元定义）提取类型时，从下拉菜单中选择单元名称。单元名称也可在下拉框中输入。

.. image:: media/06/img_044.png
   :width: 10.63cm
   :align: center

in_layers：提取层，可以使用*提取输入版图中的所有层，或者使用类似1(0),2(0)这种提取指定层。

extraction_type：目前可设置的提取模式有4种，Entire Layout模式会提取整个输入布局。Cell Instances模式会提取特定单元实例的数据。Cell Definition模式会提取特定单元定义的所有数据。Region模式会提取给定区域坐标下符合要求的数据。

dose_classification：剂量分类。可设置的模式有3种，Automatic模式自动调整剂量。Shrink模式在提取操作完成后，重新计算剂量分类。Maintain模式保持原始的剂量值不变。

cells_name：当提取模式选择按照单元实例或者单元定义提取时，使用该参数定义单元实例的名义，输入形式为cell_name1，cell_name2中间以逗号分割。

additional_option：该参数有三种模式可以选择，包括Region(s)/Instances only、Exclude Region(s)/Instances、Remove Sub-Cells。Region(s)/Instances only表示提取区域和实例，Exclude Region(s)/Instances表示从原始区域中排除指定区域，Remove Sub-Cells表示移除子单元模式。

region_layers：指定哪些层作为“区域层”处理，格式同in_layers。“*”表示所有层，1(0)，2(0)这种表示指定层

region_bos_mode：该参数可以指定区域的模式，有5种模式可以选择，Clip、Within、Touching、Touching & Disjoint、Interact。Clip是裁剪模式，排除超出区域边界的图形，保留区域内的部分。Within是包含模式仅提取完全位于选定区域的图形。Touching是接触模式，包含位于区域内和区域边界有恰好点接触或者边接触以及延伸超过区域边界的也包含在内。Touching & Disjoint是接触且不相交模式，提取仅与区域边界接触但不重叠的几何图形。Interact是交集模式，提取与区域边界重叠或者在边界上有接触的图形。5种模式中，Interact模式会拿出最多的图形。

keep_region_layer：是否保留区域层数据，true/false。

extent_ways：版图范围指的是一个从原始设计数据的左下角边界到右上角边界所构成的矩形框。换句话说，它是图案的最外边缘，被视为图案的可写入区域。默认情况下，使用Extract模块时，图案的原始范围始终保持不变。该参数提供了4种更改版图范围的模式，Maintain模式保持与原始版图相同的范围。Minimum模式采用可能的最小尺寸包围原始版图的所有多边形。Use Extract Extent模式使用为提取操作所定义的矩形范围。User Defined模式用户可以指定新的左下角和右上角坐标作为版图范围。

x1[μm]，y1[μm]，x2[μm]，y2[μm]：该参数是辅助extent_ways参数一起使用，当extent_ways设置成User Defined时，x1，y1，x2，y2分别对应新的左下角和右上角坐标。

roi_table：该参数可以手动定义感兴趣的区域，每个区域用左下角和右上角定义，每个区域有名字，以及提取模式，这里的提取模式和参数region_bos_mode中的5中提取模式一样。不同区域可以设置不同的区域提取模式。

Python接口说明：

eblExtract(dmLib* in_lib,  # 待提取版图

const char* in_layers,  # 提取层，输入“*”或者形如1(0)，2(0)

int extraction_type,  /* 0：Region(s)/Instances only，1：Exclude #Region(s)/Instances，2：Remove Sub-Cells */

int dose_classification, # 0：Automatic，1：Shrink，2：Maintain

const char* cells_name,

int additional_option, /* 0：Region(s)/Instances only，1：Exclude Region(s)/Instances，2：Remove Sub-Cells */

const RoiTable& roi_table, /* [x1, y1, x2, y2, region name, region box mode]*/

const char* region_layers,  # 区域层，输入“*”或者形如1(0)，2(0)

int region_box_mode,  /* 0：Clip，1：Within，2：Touching，3：Touching & Disjoint，4：Interact */

bool keep_region_layer, # 0: false, 1: true

int extent_ways,  /* 0：Maintain，1：Minimum，2：Use Extract Extent，3：User Defined */

double x1,

double y1,

double x2,

double y2)

示例：

eblExtract(in_lib1, "*", 0, 0, "TOP", 0, [], "", 0, False, 0, 0.0, 0.0, 0.0, 0.0)

eblExtract(in_lib1, "*", 3, 0, "", 0, [(0.0, 0.0, 500.0, 500.0, "R1", 0)], "", 4, False, 2, 0.0, 88.0, 1000.0, 1000.0)

.. _sec-6-1-5:

6.1.5 Fields模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

版图被切分为小于最大偏向束的场。写完一个场后，样品台必须移动。版图还可以进一步被拆分为"子场"，通常尺寸为数十微米。子场内的形状进一步被拆分为小梯形，可使用高速DAC填充（或"涂绘"）。大多数电子束写入机使用刚性子字段栅格。

Fileds/SubFileds

.. image:: media/06/img_045.png
   :width: 10.71cm
   :align: center

Field Size and Subfield Size [X and Y μm]：场和字长的X/Y方向的长度限制。

Traversal Direction：遍历方向影响字段的排序。Bottom Up选项以从左下角开始的蛇形顺序排列场阵列。Top Down选项以从左上角开始的蛇形排列场阵列。遍历方向影响字段的排序。

Region Definition

.. image:: media/06/img_046.png
   :width: 10.77cm
   :align: center

用户通过输入区域的坐标及命名定义一个区域。

Write Sequence

.. image:: media/06/img_047.png
   :width: 11.03cm
   :align: center

Selected Layer

选择要处理的层。格式：* 包含所有层，也可以列出单独的层。

Selected Region

选择要处理的区域。*代表所有区域，也可以输入单独的区域。

Field Traversal

有三种可选方式：Fixed（固定）、Floating（浮动）和Fields Follow Geometry（字段跟随几何）。

Fixed Fields：电子束场放置的默认策略是一种称为"Fixed"（固定）的连续规则阵列。在此模式下，版图被平铺为等大的场，第一个字段从左上角或左下角开始，取决于曝光工具。

Floating Fields：浮动场功能是一种智能策略，将场放置在数据存在的位置。此外，场会经过排序以优化台台移动。主场从左侧开始，以数据为中心，然后在最大限度减少台台移动的同时映射场顺序。此选项适用于稀疏布局。启用浮动场后，场会以避免字段拼缝的方式放置。如果可能，场会放置在使数据处于字段中心的位置  。

Fields Follow Geometry：Fracture引入的Fields Follow Geometry字段遍历允许场的放置和排序跟随长的连续结构，例如波导、微流体……

Write Sequence

有时需要使用不同的遍历、Multipass模式、Overlap、Field和Feature Sorting类型来曝光层或图案。例如，当曝光包含X和Y方向光栅的图案时，最好分别在X和Y方向使用光栅曝光。这可以通过Write Sequence来实现。

Write Sequence面板包含定义写入选项的"pass"（遍次）。每个遍次有单独的"Pass"面板。可按需添加或删除遍次。这些面板的顺序可通过拖放来更改。

Multipass

.. image:: media/06/img_048.png
   :width: 11.08cm
   :align: center

Mode

遍次数量可以为Single（单次，默认）、Two（两次）、Four（四次））。

Multipath Field Arrangement

Shortest Path：按场曝光，最大限度减少台台移动。

Path By Path：按路径曝光，即版图的每个场先曝光一遍，再以场偏移开始第二次曝光。

Line By Line: 以逐行的"蛇形"方式依次暴露所有场。

Follow Geometry：用于固定场。在Follow Geometry中，场排列会尝试跟随底层的几何图形。这可用于大的波导结构，其中场排列不太重要但依次写入相邻场是重要的。

Mainfield Offset

默认的主字段偏移因子为0.5，表示实际主字段尺寸的一半。可以使用0到0.5之间的任何值来定义主字段偏移。偏移设置可以为Relative（相对，%）或Absolute（绝对，μm）。

Subfield Offset

默认的子字段偏移因子为0.5，表示实际子字段尺寸的一半。可以使用0到0.5之间的任何值来定义子字段偏移。偏移设置可以为Relative（相对，%）或Absolute（绝对，μm）。

Overlap

.. image:: media/06/img_049.png
   :width: 10.93cm
   :align: center

SortMethod

Fracture：对于Field Traversal类型为Fixed和Manual（区域定义）的情况，Overlap Method除上述方法外还包含：Interleaving（交错）和Interleaving + extra field（交错+额外场）。场重叠会减少Fixed Fields模式下主场边界处的断裂。若无重叠，所有跨越场边界的图形将在场边界处被切分。重叠参数定义了主场之间的公共区域，在此区域内断裂（即梯形被拆分到两个主场中）可以被避免——前提是该图形可以完全在其中一个场中曝光。最大重叠为场尺寸的一半。

Outline：Outline排序方法可用于Fixed Field Traversal。

Field Sorting

.. image:: media/06/img_050.png
   :width: 10.61cm
   :align: center

Traversal Type

MeanderX：曝光在±X方向进行，并以Y方向递增（S形曝光）

MeanderY：与MeanderX相反

RasterX ：在X方向上按行曝光，在Y方向上递增

RasterY：与RasterX相反

Python接口说明及示例：

eblField(dm_Import_1, 	#input dmlib pair

50,  			#field_size_x

50,  			#field_size_y

0,  			#subfield_size_x

0, 			 #subfield_size_y

0, 			 #traversal_direction

"", 			 #distortion_file

0,  			#interactive_reSorting_of_fields

'{"R1": [2000, 2000, 3000, 3000],"R2": [5000, 5000, 6000, 6000],"R3": [2500, 2800, 4900, 3300]}', 	 #region_definition_json

'''{

"WQ1":

{"FeatureSorting":{"controlLayers":"*","featureOrder":0,"fixedFieldTraversalType":0,"layersOrder":"*","regionSize":0,"regionTraversal":0,"startPosition":0,"subfieldSizeX":0,"subfieldSizeY":0,"tileAlignment":0},"FieldSorting":{"assistLayer":"*","fixedFieldTraversalType":0,"groupNeighboringGeometries":false,"groupingDistance":0,"integrateInPreviousPass":false,"maxGeometryWidth":2,"minGeometryLength":25,"searchFieldSize":1000,"tileAlignment":0},"FieldTraversal":0,"Multipass":{"layerForMultipass":"*","mainfieldAbsolute":0,"mainfieldOffsetX":0.5,"mainfieldOffsetY":0.5,"mode":1,"multipathFieldArrangement":0,"subfieldAbsolute":0,"subfieldOffsetX":0.5,"subfieldOffsetY":0.5},"Overlap":{"elementSizeInterleaving":0,"layerForInterlock":"*","overlapMethod":0,"sizeX":0,"sizeY":0,"sortMethod":0},"SelectedLayer":"*","SelectedRegion":"*"}

}''')  				#write_sequence_json

.. _sec-6-1-6:

6.1.6 Filter 模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

过滤模块（Filter module）由“规则（Rules）”选项卡驱动，该选项卡界面如上图所示，分为 上、下两个窗格（pane）。

下方窗格 包含选择过滤表（Selection Filter table） ，其中列出了一个或多个过滤条件（filtering criteria）。此外，用户可在此处导入（import）、导出（export）或删除（delete） 过滤表。

上方窗格 （标题为"When (...) KeepLayer"）用于定义用户设定的具体过滤规则 。

在上图示例中，部分过滤规则选项（如：特征（Features） 、属性（Attributes） 、运算符（Operators） 等）；

“Features”（要素）为“All”（全部），“Attributes”（属性）为“Area”（面积）和“CD”。

(备注：目前feature实现的功能是all和circle，all对应的筛选条件width，height，area;circle对应的筛选条件area,dimeter。)

在第一列中，可从下拉菜单中选择“Features”。若选择“All”，则所显示的可用属性如上图所示，其说明如下。在下图中，各属性以图形方式呈现。

在规则中，可使用上述红色框标出的“+”或“×”按钮，添加或删除筛选条件。同时，使用上述蓝色框标出的“AND”/“OR”选项，将多条规则进行逻辑组合

用户可在右侧窗格中自行定义筛选条件。本质上，“筛选”（Filter）模块通过下表所列的各特定元素属性，实现对布局内形状的选择。部分筛选属性依赖于布局中形状的外接矩形 （bounding box）属性。

其中，矩形的外接矩形尺寸与其自身完全一致；而多边形的外接矩形尺寸可能与实际设计存在差异。

.. image:: media/06/img_051.png
   :width: 14.65cm
   :align: center

.. image:: media/06/img_052.png
   :width: 14.65cm
   :align: center

.. list-table::
   :header-rows: 1
   :widths: 50 50

   * - 符号
     - 定义
   * - <
     - 小于
   * - >
     - 大于
   * - <=
     - 小于等于
   * - =>
     - 大于等于
   * - ==
     - 等于
   * - !=
     - 不等于

.. image:: media/06/img_053.png
   :width: 14.65cm
   :align: center

此处所选的属性之间以 AND（与） 逻辑运算符连接。这意味着：最终被筛选出的形状需同时满足 以下两个条件。

选用了 OR（或） 逻辑运算符，则筛选结果将改为满足任一条件即可

.. image:: media/06/img_054.png
   :width: 14.65cm
   :align: center

Keep Layer（保留图层）
当对形状进行筛选后，其当前所在的图层将被保留不变 。

Assign Layer（指定图层）
当对形状进行筛选后，其当前所在的图层将被修改为 此处所指定的目标图层。

Python接口参数说明：

存储filter对应的筛选参数，在Python中是使用11个参数的元祖作为一条晒选规则，一个list存储的多个元祖，对应一张版图通过多个元祖筛选规则后的结果。一个list是一个结果。

元祖每个参数含义说明：

#  int featureMode; 0 -all,1- circle, 2-ring,3-path,4-jobdecktitle

#  int attritube;0-width,1-height,2-area,3-height/width,4-width/height,

#               5-relativedose,6- angle ,7 -cd ,8-diameter,9-inner diameter,

#               10-outer diameter,11-ring width,12-title type;

#

#  int condtion1, 0- ＞;1- ＜;2 - ＞=;3- ＜=;4- ==;5- !=;

#  double firstValue,

#  int operation;0-and, 1- or ,2- 空值

#  int condition2,0- ＞;1- ＜;2 - ＞=;3- ＜=;4- ==;5- !=; if not set,value is -1

#  double secondValue; if not set ,value is -1

#  int  keepLayer; 0-false 1-true

#  string assignLayer;

#  int globalCondtion; 0- and ;1 -or;

#  double fraction;some attritube have,value range 0~1;if not have; value set 0;

示例：

filter2=[[(0,1,0,100,0,1,2000,1,"20(0)",1,0),(0,0,0,100,0,1,1000,1,"20(0)",1,0)]]

eblFilter(in_lib1,filter2)

.. _sec-6-1-7:

6.1.7 Fracture 模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

eblFracture 模块用于将复杂的布局几何图形破碎（Fracture）为电子束光刻机可识别的基本图形（如梯形、三角形、矩形）。该过程是 EBL 数据准备流程中的关键步骤，直接影响写入速度、精度和剂量均匀性。

.. image:: media/06/img_055.png
   :width: 10.74cm
   :align: center

.. image:: media/06/img_056.png
   :width: 10.42cm
   :align: center

主要功能包括：

几何破碎：将任意多边形分解为梯形，三角形，矩形。

套筒(Sleeve) 生成：为特定图层生成保护性边框（Sleeve），利用单线曝光特性在目标层上快速生成套筒结构，可以在不降低吞吐量的前提下提升图案质量。

in_lib：输入布局库，包含待碎裂的原始布局。

maintain_grid：是否保持网格，true使用输入库的原始网格精度(DBU)，false根据resolution参数动态计算新的网格精度。

resolution：碎裂分辨率(μm)，定义碎裂后图形的最小精度，值越小，精度越高，数据量越大，如0.001(1nm精度)。

beam_step_size：电子束步长，定义电子束写入时的步进单位，范围1到10。

beam_step_size_correction：是否开启步长校正，true/false。

fracturing_type：裂解类型，树状裂解和层次裂解两种，Hierarchical/Flat。

fracturing_mode：裂解模式，三种裂解模式，Conventional传统梯形裂解，传统算法主要在多边形顶点处执行水平断裂，以最大程度保留原设计意图。其结果通常为大量梯形片，以最优拟合原始布局。Large Rectangle Fine Trapezoid(LRFT) 裂解旨在最小化最终生成的图形数量。对大面积区域采用大型矩形覆盖，小特征处则采用细梯形填充。简言之，该模式以尽可能多的大型矩形填充，并以小型梯形补全剩余空间。Curved裂解通常适用于圆形与环形结构的断裂处理。该模式允许沿曲线对顶点进行平移，使断裂结果符合设定的分辨率与束步长要求。

tolerance_curved：此参数仅对曲线断裂模式有效，用于定义对环状与圆形结构进行检测时的逼近范围，范围[1,10]。

symmetric_fracturing：是否对称裂解，true/false。

trapezoids：设置裂解中的梯形偏好，有三种选择X/Y/XY，X表示裂解中的梯形仅X方向。

fracturing_angles：碎裂角度，限制裂解结果中绘制梯形角落的角度方式。Any Angle表示任意角度，45 Degree表示45度，Rectangular表示90度矩形。

generate sleeves：是否生成套筒，true/false。

number_of_sleeves：套筒数量。

sleeving_size：套筒尺寸[res]，用于控制套筒内轰击点的尺寸。

sleeve_bulk_overlap：控制套筒的重叠程度[μm]。

sleeving_layer：定义需要生成套筒的层，输入形式如1(0)，24(0)。

target_layer：定义保存套筒生成结果的层，输入形式如1(0)，24(0)。

.. image:: media/06/img_057.png
   :width: 5.23cm
   :align: center

.. image:: media/06/img_058.png
   :width: 5.21cm
   :align: center

.. image:: media/06/img_059.png
   :width: 5.3cm
   :align: center

.. image:: media/06/img_060.png
   :width: 5.21cm
   :align: center

.. image:: media/06/img_061.png
   :width: 7.21cm
   :align: center

.. image:: media/06/img_062.png
   :width: 7.33cm
   :align: center

.. image:: media/06/img_063.png
   :width: 5.23cm
   :align: center

.. image:: media/06/img_064.png
   :width: 5.21cm
   :align: center

.. image:: media/06/img_065.png
   :width: 5.63cm
   :align: center

.. image:: media/06/img_066.png
   :width: 5.21cm
   :align: center

.. image:: media/06/img_067.png
   :width: 6.3cm
   :align: center

.. image:: media/06/img_068.png
   :width: 5.21cm
   :align: center

Python接口说明：

eblFracture(dmLib* in_lib,

bool maintain_grid,  # 0: false, 1: true

double resolution,  # 输入大于0的值

int beam_step_size,   # [1, 10]

bool beam_step_size_correction,  #  0: false, 1: true

int fracturing_type,   #  0: Hierarchical, 1: Flat

int fracturing_mode, # 0: Conventional, 1: LRFT,2: Curved

int tolerance_curved,  # [1, 10]

bool symmetric_fracturing,  # 0: false, 1: true

int trapezoids,  # 0: X, 1: Y,2: XY

int fracturing_angles, # 0:Any angle, 1: 45 Degree, 2: Rectangular

int tolerance_angle,   # [1, 10]

bool generate_sleeves,  # 0: false, 1: true

int number_of_sleeves,

int sleeving_size,

double sleeve_bulk_overlap,

const char* sleeving_layer,  # 24(0)

const char* target_layer) # 1(0)

示例：

1. eblFracture(in_lib, True , 0.001, 1, False, 1, 2, 1, False, 0, 0, 1, False, 1, 10, 1, "", "")

2. eblFracture(in_lib, False , 0.1, 1, False, 1, 0, 1, False, 2, 0, 1, True, 1, 10, 0, "24(0)", "1(0)")

.. _sec-6-1-8:

6.1.8 Grid模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~

Grid(网格)模块用于修改布局的数据库单位(Database Unit, DBU)，并提供布局平滑功能以减少曲线结构的顶点数量。该模块在数据准备流程中至关重要，主要用于：

单位转换：将布局从一种精度(如1nm)转换到另一种精度(如0.5nm或2nm)。

数据优化：通过移除冗余顶点，显著减少数据量，从而缩短后续的碎裂(Fracture)时间和写入时间。

网格对齐：确保所有几何顶点都吸附到新的目标网格上，避免非整数坐标导致的写入错误。

该模块可以设置的参数有两个：

数据库网格[μm]：数据库网格是顶点对齐的设计单位。默认值是1nm。如果使用较粗的网格值，可能会导致布局的顶点无法对齐到该粗网格的整数倍位置上，从而发生吸附(Snapping)现象。

布局平滑容差：布局平滑功能用于减少顶点数量。平滑参数会消除那些与下一个顶点距离小于平滑值的顶点。换句话说，如果输入的布局平滑容差为0.005μm，所有对曲线形状贡献小于 0.005μm的现有顶点都将被移除，从而消除不必要的顶点。

Python接口说明：

eblGrid(dmLib* in_lib,

double database,  # 目标数据库网格单位[μm]，任意大于0的值

double smoothing_tolerance)   # 布局平滑容差[μm], 任意大于等于0的值

示例：

eblGrid(in_lib, 0.01, 0)

Heal模块

Heal模块现包含Healing和Overlap Remove两个模块。

.. image:: media/06/img_069.png
   :width: 10.82cm
   :align: center

Healing

Heal模块会移除布局中的重叠部分，并将相邻的多边形合并为一个。重叠会在写入时导致不良的双重曝光，从而造成形状保真度差。默认的Heal设置将移除重叠，并将剩余元素合并为单一层上的单一多边形。

Overlap Remove

Overlap Remove会移除重叠，但不会将相邻的多边形合并在一起。

Heal模块支持对图案进行逐层操作。

All Layers

默认情况下，所有层会一起愈合。结果是信息会丢失，且生成的数据会被放置在单一目标层上。

Keep Layer

重叠移除会尝试创建顶点数较少的几何图形；此标准用于决定在何处移除重叠。Keep Layer会移除重叠并保留顶层的层号。

Per Layer

如果文件已被导入并执行（Run按钮），则层列表可在Layer Selection（层选择）菜单中显示，并可按对面所示选择或清除所需的层。通常，单独的层会被提取并单独处理。当选择Per Layer时，可以显式选择要进行修改的层。通配符（*）可用于在此操作模式下表示所有层。

SoftFrame操作使用内存中的虚拟分块来快速执行此操作。整个图案被划分为虚拟分块，每个分块被传递给可用的处理核心来执行。根据图案的大小和可用内存，会生成或多或少的分块，并在分块上并行执行所需的操作。一旦所有分块都被处理完毕，它们会被重新组装为一个图案。Soft Frame参数即为这些虚拟分块之间的重叠部分。本质上，任何等于或小于Soft Frame（重叠）大小的特征都不会在虚拟分块操作中被切分。由于小于0.300μm的特征大小在此操作中可能因产生非最佳断裂而敏感于被切分，因此如果不确定该使用何值，可保留默认的Soft Frame值0.300μm

Python接口说明及示例：

eblHeal(

0,	  		#mode

dm_Import_1, 	#input_dmlib

0, 			#layer mode

"*",  			#in_layers

"*",				 #out_layer

0, 			 #hier

0.3)  			 #soft_frame

.. _sec-6-1-10:

6.1.10 Mapping模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

映射模块通过直接修改层名称映射表，将现有层重命名为新名称。例如，层 1(0) 将被重命名为别名2（0）；

若已运行导入模块 （Import module），则所有可用层将自动出现在下拉菜单中——用户只需点击对应行中的"层 （Layer）"字段，即可从下拉列表中选择目标层（如右图所示）。

别名列 （Alias Column）允许用户为某一层添加注释性名称 （即“别名”），该名称不影响底层数据，仅用于提升可读性与搜索便利性。在映射设置界面 （Mapping dialog）中，可以定义了对层 版图中已经有的层的重命名规则。

在设置界面的表格中layerOld是输入版本的层名，layerNew是重新定义的的层名，Alias自定义的层别名。当用户点击 OK 并执行该模块后，所有指定层将按设定完成重命名。

.. image:: media/06/img_070.png
   :width: 14.65cm
   :align: center

Python接口参数说明：

dmLib *eblMapping(dmLib *lib,

const layerMapping layerMap# 存储layerOld，layerNew，Alias参数

)

示例：

layermap={'24(0)':('20(0)','map')}

lib1 = eblMapping(in_lib1, layermap)

.. _sec-6-1-11:

6.1.11 Merge模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Merge（合并）模块接收多个模块的输出并将它们合并为单一布局。Merge会保留布局属性如层和数据类型，同时维护图案中的原始形状。

.. image:: media/06/img_071.png
   :width: 14.65cm
   :align: center

Coordinate Origin

将新的坐标原点(0,0)设为原始布局原点（维护当前坐标系）、新布局范围的中心、或Bottom Left（左下角）即布局范围的左下角。

Extent Control

布局的范围是指从原始设计数据的左下极限到右上极限的框。换言之，它是图案的最远边缘，被视为图案的可写入区域。这意味着范围边界之外不能存在任何形状。范围不应用于提取感兴趣区域进行曝光。它仅用于定义要曝光的区域。

Maintain

保持与原始布局相同的范围

Minimum

取尽可能小的尺寸，包围所有多边形。

User Defined

用户可以指定左下角和右上角坐标。定义范围时，只能将用户范围调整为大于数据的最远边缘。无法将其调得更小。

Python接口说明及示例：

eblMerge(dm_Import_1,		 #input dmlib pair

0,  				 #coordinate_origin

0, 				 #extent_control

0.0, 				 #region_x1

0.0, 				 #region_y1

0.0,  				 #region_x2

0.0) 				 #region_y2

.. _sec-6-1-12:

6.1.12 NOT 模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

NOT（非）模块接收一个版图作为输入，在转换中，数据变为非数据（空间），空间（非数据）变为数据。此操作可能导致顶点数极多的多边形。EBL 支持指定输出层与数据类型，默认为 6(0)。

.. image:: media/06/img_072.emf
   :width: 14.65cm
   :align: center

All Layer

默认情况下，所有层会一起处理。结果是层信息会丢失，且生成的数据会被放置在单一目标层上。

Per Layer

如果文件已导入并执行（Run按钮），则可在Layer Selection（层选择）菜单中显示层列表，选择或清除所需的层。

Python接口说明及示例：

eblBooleanNot(dm_Import_1, 	#input dmlib pair

0, 					#mode

"6(0)",				#out_layer

"", 					#layers

0.3,					#soft_frame

0) 					#hier 0 – false, 1 - true

.. _sec-6-1-13:

6.1.13 PXOR 模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

P-XOR（图案异或）是一种特殊的布尔操作，会移除偶数重叠并保留奇数重叠。

默认情况下，目标层和数据类型为4(0)。在下例中，可从同心重叠圆（红色）图案快速生成同心环（蓝色）图案。

.. image:: media/06/img_073.emf
   :width: 14.65cm
   :align: center

具有奇数（1、3、5、7……）个多边形叠加的区域会保留。具有偶数（2、4、6、8……）个多边形叠加的区域会被移除。此特殊功能非常适用于轻松生成如波带片之类的圆形光栅。

All Layer

默认情况下，所有层会一起处理。结果是层信息会丢失，且生成的数据会被放置在单一目标层上。

Per Layer

如果文件已导入并执行（Run按钮），则可在Layer Selection（层选择）菜单中显示层列表，选择或清除所需的层。

Python接口说明及示例

eblBooleanPXor(dm_Import_1, 	#input dmlib pair

0, 						#mode

"4(0)",					#target_layer

"",						#layers

0.3, 						#soft_frame

0) 						#hier 0 – false, 1 - true

.. _sec-6-1-14:

6.1.14 Replace模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

替换模块 （Replace module）可用于在版图中执行多种替换操作：既可将特定单元（cell）替换为另一版图层或边界框（bounding box, BBox），也可将某层上的几何图形替换为其对应的边界框。

该模块共支持以下 5 种替换模式 ，具体如下：

1.用第二个输入版图替换一个或多个单元 （cell），并提供 3 种定位对齐模式 ：

原点对原点（origin to origin）

中心对中心（center to center）

左下角对左下角（lower left to lower left）
典型应用场景：插入标准单元（standard cells）、工艺控制监测结构（PCMs）、标注（labels）、对准标记（alignment keys）等。

2.用矩形边界框 （BBox），该矩形大小等于该单元的原始 extents（即最小外接矩形）。
典型应用场景：SAM（Self-Aligned Multiple Patterning）模板设计、快速抽象化复杂单元以加速仿真。

3.将选定层上的所有几何图形替换为其各自的边界框 （BBox）。

层选择支持通配符 *，表示“所有层”。
典型应用场景：自动化生成用于手动场区放置（manual field placement）的区域划分块。

4. 将选定层上的所有几何图形替换另一版图（layout）

5.展平特定单元 （Flatten Certain Cells）

将指定单元及其子层级展开为顶层几何图形（即去除 hierarchy），常用于 DRC/LVS 前准备或兼容旧版工具链。

（备注：compaction功能暂未实现）

.. image:: media/06/img_074.png
   :width: 14.65cm
   :align: center

Cell Replaced by Layout模块

.. image:: media/06/img_075.png
   :width: 14.65cm
   :align: center

Cells参数：指定替换的cell名；

Posititon_mode:指定替换的位置对齐方式；orgin to orgin 是原点对原点对齐，center to center 是中心点对中心点对齐，lower  left to lower  left是左下角与左下角对齐。

Cell Replaced by Bounding Box模块

可以输入替换的cell以及定义输出的layer。

Cell to replace 指定替换的cell。

Layer是自定义输出的层；

.. image:: media/06/img_076.png
   :width: 14.65cm
   :align: center

Geometry of Layers Repalced by Bounding Box模块

输入指定层的图行被Bounding Box替换。

Layers是指定替换的层；

.. image:: media/06/img_077.png
   :width: 14.65cm
   :align: center

Geometry of Layers Repalced by Layout模块

Layers是指定替换的层参数；

.. image:: media/06/img_078.png
   :width: 14.65cm
   :align: center

Flatten Certain Cells模块

此操作会 移除当前层级上的所有层级结构**（即：将选定单元格内部的子层级完全展开，变成独立的平面单元格，不再保留层级嵌套关系）

.. image:: media/06/img_079.png
   :width: 14.65cm
   :align: center

Flatten_mode:指定展开的方式；select by name 是根据输入cells的name进行展开，select by size 根据输入size信息展开cell(该功能暂未实现)，select by level是根据输入的级数，展开对应级数的cell。

Python接口参数说明：

eblReplace(dmLib* in_lib1， dmLib* in_lib2,

int replacement_type, # 指定替换模块，0-5 依次表示上述模块；

const char* in_cells, # 指定的cell name；

const char* in_layers,#指定的 layer ；

int position_mode,  # Cell Replaced by Layout指定对齐方式；

bool apply_dose_to_replaced_geometries,# Geometry of layers Replaced by Layout 模块参数

#           /* Compaction 模块暂未实现/

#           bool remove_cell_duplicates, # Compaction模块参数

#           // Compaction only

#          bool form_compressed_arrays,

#          int keep_arrays_limit,

#           bool replace_repeated_geometries_by_cells,

// Flatten Certain Cells only

int flatten_mode, #指定展开方式

bool heal_flattened_cells, 指定是否做愈合

#           // Flatten Certain Cells select by name

const char* fccCells,#通过cell name展开,指定cell name

#           // Flatten Certain Cells select by size

const char* jsonStr, #指定size参数[size X, size Y, delta X, delata Y]

#         // Flatten Certain Cells select by size

int level_to_flatten # 指定展开cell的级数

)

示例：

eblReplace(in_lib1, in_lib2, 0, "TOP","",2,False,False,False,0,False,0,False,"","",0)

.. _sec-6-1-15:

6.1.15 Transform模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Transform模块用于对输入版图进行几何变换，可设置的参数如下所示：

1. coordinate_origin参数用于定义几何变换的参考原点（基准点）。所有的镜像、旋转和缩放操作都将围绕这个基准点进行。选择合适的原点对于确保变换后的布局位置正确至关重要。有5种模式可以选择：

.. image:: media/06/img_080.png
   :width: 10.48cm
   :align: center

Origin：使用全局坐标系的固定点(0, 0)作为参考原点；

Center-XY：使用输入版图的中心点作为参考原点；

Center-X：使用输入版图X轴方向的中心作为参考原点，Y=0；

Center-Y：使用输入版图Y轴方向的中心作为参考原点，X=0；

Left Bottom：使用输入版图的左下角作为参考原点；

2. reflect参数用来控制版图绕X或者Y轴翻转，有4种模式可以选择：

.. image:: media/06/img_081.png
   :width: 10.56cm
   :align: center

Mirror XY：将输入版图关于X轴，Y轴翻转；

Mirror X：将输入版图关于X轴翻转；

Mirror Y：将输入版图关于Y轴翻转；

No Mirror：不做任何翻转；

3. rotation参数控制版图围绕coordinate_origin设定的参考原点，相对于 X 轴旋转任意角度，输入值是角度制。

4. scale用来控制版图放大或者缩小指定值。

5.shift参数用来控制版图相对coordinate_origin设定的参考原点沿X轴平移shift_x，沿Y轴平移shift_y。

Python参数接口说明：

eblTransform(dmLib* in_lib,

int coordinate_origin,   # 参数值0到5，0对应Origin

int reflect,                      # 参数值0到4，0对应Mirror XY

double rotation,              # 大于等于0的值

double scale,                   # 大于0的值

double shift_x,                # X方向平移距离[μm]

double shift_y)                # Y方向平移距离[μm]

示例：

eblTransform(in_lib, 0, 3, 0, 1, 0, 0)

.. _sec-6-2:

6.2 Boolean 分组
-------------------------------

.. _sec-6-2-1:

6.2.1 AND模块
~~~~~~~~~~~~~~~~~~~~~~~~~

AND模块接收两个布局作为输入，并返回布局A和布局B数据重叠的部分。AND操作会保留布局A（绿色）和B（深蓝色）之间共有的区域。

.. image:: media/06/img_082.emf
   :width: 14.65cm
   :align: center

布局逻辑：

.. list-table::
   :header-rows: 1
   :widths: 33 33 33

   * - AND
     - AND
     - AND
   * - A
     - B
     - Result
   * - 0
     - 0
     - 0
   * - 0
     - 1
     - 0
   * - 1
     - 0
     - 0
   * - 1
     - 1
     - 1

0表示布局元素不存在。1表示布局元素存在。

eblBooleanAnd(dm_Import_1,None,	 #input dmlib pair

"6(0)", 					#out_layer

0.3, 					#softFrame

0) 						#hier 0 -false ,1 – true

.. _sec-6-2-2:

6.2.2 MINUS模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

MINUS 模块接收两个版图（layout）作为输入，执行“从版图 A 中减去版图 B"的布尔差集运算（Boolean subtraction），并返回剩余数据。

该模块始终遵循"左输入减右输入 "的规则（即：结果 = 左输入 − 右输入）。版图 A 显示为绿色 ，版图 B 显示为蓝色 ，输出结果是黄色区域。

.. image:: media/06/img_083.png
   :width: 14.65cm
   :align: center

.. list-table::
   :header-rows: 1
   :widths: 33 33 33

   * - MINUS
     - MINUS
     - MINUS
   * - A
     - B
     - Result
   * - 0
     - 0
     - 0
   * - 0
     - 1
     - 0
   * - 1
     - 0
     - 1
   * - 1
     - 1
     - 1

MINUS 模块在运算过程中保留原始层信息 （layer information）以及重叠区域的几何关系 ；但不保留剂量信息 （dose information，如曝光剂量、写入强度等元数据）。

.. _sec-6-2-3:

6.2.3 OR模块
~~~~~~~~~~~~~~~~~~~~~~~

两个版图（layout）作为输入，凡是在版图A或版图B中存在图形的位置，都会保留图形输出。

.. image:: media/06/img_084.png
   :width: 14.65cm
   :align: center

.. list-table::
   :header-rows: 1
   :widths: 33 33 33

   * - OR
     - OR
     - OR
   * - A
     - B
     - Result
   * - 0
     - 0
     - 0
   * - 0
     - 1
     - 1
   * - 1
     - 0
     - 1
   * - 1
     - 1
     - 1

EBL支持指定输出结果的目标层（target layer）和数据类型（datatype），例如，输出目标层和数据类型为：层号3、类型号0，记作 3(0)。为避免对原始版图造成不必要的图形碎片化（fracturing） ，可在参数设置窗口中定义一个软帧（soft frame） （即一个非图形性的虚拟矩形边界框），用以约束操作区域。

OR操作将完整保留图案A与图案B中的所有图形（shapes），并在输出中将其合并（heal） 为连续、无重叠/无间隙的整体图形。

.. _sec-6-2-4:

6.2.4 XOR模块
~~~~~~~~~~~~~~~~~~~~~~~~~

XOR（异或）模块接收两个布局作为输入，并返回布局A数据存在而布局B数据不存在、以及布局B数据存在而布局A数据不存在的部分。可以通过双击打开参数窗口来指定结果的目标层和数据类型。XOR操作仅保留各图案独有的形状，并在输出中移除A和B之间的所有重叠：

.. image:: media/06/img_085.emf
   :width: 14.65cm
   :align: center

布局逻辑：

.. list-table::
   :header-rows: 1
   :widths: 33 33 33

   * - XOR
     - XOR
     - XOR
   * - A
     - B
     - Result
   * - 0
     - 0
     - 0
   * - 0
     - 1
     - 1
   * - 1
     - 0
     - 1
   * - 1
     - 1
     - 0

0表示布局元素不存在。1表示布局元素存在。

Python接口说明及示例：

eblBooleanXor(dm_Import_1,None, 	#input dmlib pair

0,						#mode area

"6(0)",					 #out_layer

0.0, 						 #accuracy

0.3)						 #soft_frame

.. _sec-6-3:

6.3 PEC 分组
-----------------------

介绍PEC类的模块设置等， 可以参考 Beamer；

介绍Python接口的参数和效果等；

.. _sec-6-3-1:

6.3.1 PEC模块
~~~~~~~~~~~~~~~~~~~~~~~~~

PEC模块可以对长程、中程、短程效应进行工艺效应校正。长程效应包括电子背散射；短程效应包括电子前散射；中程效应包括伪电子效应（如二次电子），以及工艺伪影（如负载效应和显影效应）电子散射行为和附加的工艺参数通过点扩散函数（PSF）来指定，该函数由高斯函数之和数值查找表形成。

Python接口及参数介绍如下：

.. list-table::
   :header-rows: 1
   :widths: 33 33 33

   * - dosePECRunCorrection
     - dosePECRunCorrection
     - dosePECRunCorrection
   * - 序号
     - 名称
     - 释义
   * - 1
     - In_lib
     - 载入的lib，其他的模块的输出Lib
   * - 2
     - In_layer
     - 需要进行PEC校正的layer,字符串数组[“1(0)”,”2(0)”]
   * - 3
     - Alpha（um）
     - 电子的前散射（短程）范围
   * - 4
     - Beta（um）
     - 电子的背散射（长程）范围
   * - 5
     - Eta
     - Beta高斯函数中的能量与Alpha高斯函数中的能量之比
   * - 6
     - Use Gamma 1
       
     - 是否开启中程校正
       0：不开启；1：开启
   * - 7
     - Gamma1（um）
     - 电子的中程散射范围
   * - 8
     - Nue1
     - 中程高斯函数中的能量与Alpha高斯函数中的能量之比
   * - 9
     - Effective Short Range Blur Fwhm（um）
     - 电子束有效短程模糊尺寸，正数
   * - 10
     - Include Short Range Correction
     - 是否开启短程校正
       0：不开启；1：开启
   * - 11
     - Accuracy Mode 
     - 是否开启用户自定义剂量精度
       0：不开启；1：开启
   * - 12
     - Accuracy
     - 剂量精度，正浮点数
   * - 13
     - maxDoseClasses
     - 剂量等级表的最大长度，正整数
   * - 14
     - minDoseFactor
     - 最小剂量限制，正数
   * - 15
     - maxDoseFactor
     - 最大剂量限制，正数
   * - 16
     - isoDoseGrid（um）
     - 裂解的网格尺寸，正数
   * - 17
     - minFigureSize
     - 裂解尺寸的模式
       0：自动模式；1：用户自定义
   * - 18
     - longRangeMinFigureSize（um）
     - 长程校正的最小图形尺寸，正数
   * - 19
     - shortRangeMinFigureSize（um）
     - 短程校正的最小图形尺寸，正数
   * - 20
     - Dose Assignment
     - 用户自定义剂量等级表，正浮点数数组[1.1,2,3,5]，只有开启用户自定义剂量精度后才生效
   * - 21
     - Hierachic_long_range_correction
     - 是否开启长程分层校正
       0：不开启；1：开启
   * - 22
     - Hierachic_short
       _range_correction
     - 是否开启短程分层校正
       0：不开启；1：开启
   * - 23
     - Short_range_separation
     - 是否开启短程分离值
       0：不开启；1：开启
   * - 24
     - Short_range_separation_value（um）
     - 短程分离值，正数
   * - 25
     - Mid_range_active_threshold（%）
     - 中程激活阈值，正数，0-100
   * - 26
     - Optimal_contrast（%）
     - 最佳对比度，正数，0-100
   * - 27
     - Single_line_beam_width（um）
     - 单线线宽，正浮点数
   * - 28
     - Layer List For LR
     - 需要长程校正的layer，字符串数组[“1(0)”,”2(0)”]
   * - 29
     - Layer List For SR Correction
     - 需要短程校正的layer，字符串数组[“1(0)”,”2(0)”]
   * - 30
     - Fogging_effect_correct
     - 是否开启雾化效应
       0：不开启；1：开启
   * - 31
     - Sigma（um）
     - 雾化效应分布的高斯线的宽度，正浮点数
   * - 32
     - Weight
     - 雾化效应对于常规PEC的剂量贡献比例，正浮点数，0-1
   * - 33
     - Neighborhood Density
     - 当前校正区域周围的图形密度，正浮点数，0-1
   * - 34
     - Process_loading_effect
     - 是否开启工艺负载效应
       0：不开启；1：开启
   * - 35
     - Effect Influence Range（um）
     - 计算局部图形密度的统计半径，正浮点数
   * - 36
     - Density
     - 局部图形密度列表，正浮点数数组[1.1,2,3,5]，0-1，只有开启用户工艺负载效应后才生效，需要与相对显影速率列表长度相同
   * - 37
     - Development Rate
     - 相对显影速率列表，正浮点数数组[1.1,2,3,5]，只有开启工艺负载效应后才生效，需要与局部图形密度列表长度相同
   * - 38
     - Cells_to_keep
     - 保持剂量的cell名称列表，字符串数组[“cell1”,”cell2”]
   * - 39
     - Layer With Fixed Dose
     - 保持剂量的layer列表，字符串数组[“1(0)”,”2(0)”]
   * - 40
     - Assume_periodic_repetition
     - 是否开启周期性循环校正
       0：不开启；1：开启
   * - 41
     - Pitch X（um）
     - 阵列在X方向上的周期间距，正浮点数，开启周期性循环校正后才生效
   * - 42
     - Pitch Y（um）
     - 阵列在Y方向上的周期间距，正浮点数，开启周期性循环校正后才生效
   * - 43
     - Repetition X
     - 阵列在X方向上的周期重复次数，正整数，开启周期性循环校正后才生效
   * - 44
     - Repetition Y
     - 阵列在Y方向上的周期重复次数，正整数，开启周期性循环校正后才生效
   * - 45
     - ldc
     - 是否开启横向显影校正
       0：不开启；1：开启
   * - 46
     - Ldc shift step size（um）
     - 机器允许使用的最小Bias步长，浮点数，开启横向显影校正后才生效
   * - 47
     - Density
     - 局域图形密度列表，正浮点数，0-1，开启横向显影校正后才生效，需要与偏移量列表长度相同
   * - 48
     - Bias（um）
     - 在该密度下图形边缘的偏移量列表，浮点数，开启横向显影校正后才生效，需要与局域图形密度列表长度相同

.. _sec-6-3-1-1:

6.3.1.1 通用设置
^^^^^^^^^^^^^^^^^^^^^^^^^^^

通用设置中主要包含了PEC模块的基础设置，主要内容如下。

（1）pec_type

常规选项卡为用户提供了三种表示PSF的方式，存档（Archive），高斯近似（Gaussian Approximation）和数值PSF（Numerical PSF）。该PSF为主PSF。

.. image:: media/06/img_086.png
   :width: 9.31cm
   :align: center

Archive模式

Archive模式允许用户通过保存的PSF2D文件直接导入PSF参数并存储。

.. image:: media/06/img_087.png
   :width: 9.31cm
   :align: center

用户选择Archive模式后，可点击Archive按钮输入存档的PSF文件，如下图，点击import选择导入的PSF文件，export可以导出PSF文件。

.. image:: media/06/img_088.png
   :width: 13.51cm
   :align: center

点击select即可将PSF文件的参数导入到界面参数中。如下图为选择了第一个PSF参数的结果。

.. image:: media/06/img_089.png
   :width: 8.8cm
   :align: center

Gaussian Approximation模式

Gaussian Approximation模式指直接通过输入PSF参数的模式。可以通过输入框设置PSF参数。

Numerical PSF模式

Numerical PSF模式指直接导入PSF2D文件并计算参数的模式。如图在PSF文件框中输入文件地址。

.. image:: media/06/img_090.png
   :width: 9.16cm
   :align: center

点击内容可查看PSF2D文件内容。

.. image:: media/06/img_091.png
   :width: 7.84cm
   :align: center

由于数值PSF为了保持较高的计算效率，alpha的值可能准确性欠佳，建议alpha可以由用户自己填入。

.. image:: media/06/img_092.png
   :width: 9.5cm
   :align: center

（2）in_layer

输入的需要校正的层，支持*表示所有层，格式如1(0)，24(0)。

（3）PSF参数

基础的PSF包含如下参数：

AlphaUm：指定电子的前散射（短程）范围

betUm：指定电子的背散射（长程）范围

eta：Beta高斯函数中的能量与Alpha高斯函数中的能量之比

Use Gamma1：使用中程校正参数

Gamma1：指定电子的中程散射范围/工艺相关的效应

Nue1：中程高斯函数中的能量与Alpha高斯函数中的能量之比

（4）PSF视图

本软件还提供了PSF视图的功能，用户能够通过设置PSF参数（三种模式均可）后，点击PSF视图后，观看当前PSF函数的曲线。并且，软件还提供了将x值与y值分别线性化/取对数的功能，点击左上方按钮即可随意切换。

.. image:: media/06/img_093.png
   :width: 12.29cm
   :align: center

（5）横向显影校正

横向显影校正（Lateral Development Correction）是一种基于图形密度来调整版图几何边缘位置（Bias）的补偿功能。PEC通过调整曝光剂量来补偿物理电子散射，而横向显影校正则直接对图形边缘进行微缩（负Bias）或外扩（正Bias），用于补偿显影阶段因局部显影液消耗不均导致的线宽偏差。软件通过计算每个图形边缘位置的局部图形目睹，并根据用户定于的映射表来调整几何尺寸。勾选ldc后，可以在弹出窗口中设置横向显影校正的相关参数，如下图：

.. image:: media/06/img_094.png
   :width: 5.91cm
   :align: center

Idc shift step size：校正允许使用的最小Bias步长。必须等于或为机器最小束斑尺寸的整数倍，以保证机器能精准执行几何偏移。

Density：指定局域图形密度，0代表完全空白区域，1代表完全被图形覆盖。

Bias：指定在该密度下图形边缘的偏移量。正值代表外扩，负值代表内缩。

如下图为上方横向显影校正设置，完成PEC校正后，图形收缩的结果。可以看到，图形根据局部的密度，进行了不同程度的收缩。

.. image:: media/06/img_095.png
   :width: 5.75cm
   :align: center

.. image:: media/06/img_096.png
   :width: 5.77cm
   :align: center

（6）有效短程模糊半高全宽

有效短程模糊半高全宽（Effect short range blur FWHM），指定电子束光刻机在曝光过程中的有效束斑模糊宽度，理论PSF模型基于无限细的点曝光，而实际机器存在有限的光斑尺寸和物理模糊，这会限制图形边缘的锐度。该参数用于向短程矫正模型中引入真实的硬件模糊限制。

.. image:: media/06/img_097.png
   :width: 9.9cm
   :align: center

以下两张图分别是有效短程模糊半高全宽为0和0.01的时候，PEC校正的结果，可见，0.01的结果短程矫正后，分裂的dose光斑尺寸更大。

.. image:: media/06/img_098.png
   :width: 10.22cm
   :align: center

.. image:: media/06/img_099.png
   :width: 10.22cm
   :align: center

（7）短程校正启动项

该参数启动了短程校正，但具体对哪些层进行校正需要在高级设置中输入。

.. image:: media/06/img_100.png
   :width: 9.74cm
   :align: center

.. _sec-6-3-1-2:

6.3.1.2 精度设置
^^^^^^^^^^^^^^^^^^^^^^^^^^^

精度控制选项卡包含剂量精度以及裂解精度。

剂量精度

在PEC中，软件计算的剂量值是连续变化的。然而，电子束光刻机在实际曝光时，其可用的剂量等级是有限的。因此，软件需要将连续的PEC结果转换为离散的剂量等级分配给版图中的图形。

软件提供了两种定义剂量等级的方式：精度模式（Accuracy Mode）和用户自定义模式（User Defined Mode）。用户需根据实际工艺的稳定性及几台硬件限制进行选择。

.. image:: media/06/img_101.png
   :width: 9.98cm
   :align: center

精度模式

该模式为软件默认模式。在实际工艺中，剂量精度存在限制，因此软件通过设定相对剂量精度自动决定所需的剂量等级数量。只有当图形内部的剂量因此差异超过设定的精度阈值时，软件才会对该图形进行裂解，并分配新的剂量等级，从而避免不必要的图形裂解。具体的参数说明如下：

.. image:: media/06/img_102.png
   :width: 9.79cm
   :align: center

Accuracy：指定要使用的相对剂量精度，默认为1%

MaxDoseClasses：允许使用的最大剂量等级数量

minDoseFactor：控制PEC允许分配给图形的最低剂量值

maxDoseFactor：控制PEC允许分配给图形的最高剂量值

用户自定义模式

该模式允许用户直接指定剂量分类表。通常适用于工艺流程已标准化、且始终使用相同参数的场景。与精度模式不同，用户自定义模式下没有最大剂量值的限制。该模式下，用户指定计量表中的最高值即为系统可用的最大剂量值。

.. image:: media/06/img_103.png
   :width: 10.4cm
   :align: center

裂解精度

在完成PEC计算出理想的连续剂量分布后，为了适配电子束光刻机的硬件限制，并精确分配不同的剂量因子，软件需要对版图中的几何图形进行切割（裂解）。裂解的策略直接决定了校正的计算量与最终曝光的精度，系统提供了等剂量网格（Isodose Grid）以及最小图形尺寸（Minimum Figure Size）设定来帮助用户平衡这两者。具体的参数说明如下：

.. image:: media/06/img_104.png
   :width: 9.9cm
   :align: center

isoDoseGrid：裂解的网格尺寸

minFigureSize：是否启用自定义的最小图形尺寸，在自定义下才可设置长程短程的最小图形尺寸。

.. image:: media/06/img_105.png
   :width: 9.87cm
   :align: center

longRangeMinFigureSize：长程校正的最小图形尺寸

shortRangeMinFigureSize：短程矫正的最小图形尺寸

.. _sec-6-3-1-3:

6.3.1.3 高级设置
^^^^^^^^^^^^^^^^^^^^^^^^^^^

（1）短程校正高级设置

hierarchic short range correction：是否启用短程分层校正，激活后，PEC的短程矫正会对层次结构中的每一层分别做校正，这会加快校正的速度。

.. image:: media/06/img_106.png
   :width: 5.58cm
   :align: center

short range separation value：短程分离值，确定将PSF在径向上分为短程和长程能量区域的切割位置。位于该切割点左侧的任何能量计入短程能量，右侧的能量计入长程能量。

.. image:: media/06/img_107.png
   :width: 5.66cm
   :align: center

Layer list for SR correction：需要进行短程矫正的层，在短程校正中的层，默认需要进行长程校正。

.. image:: media/06/img_108.png
   :width: 9.13cm
   :align: center

（2）中程校正高级设置

确定触发中程校正功能所需的能量大小。如果PSF中程区域的能量超过长程能量的指定百分比，则执行中程校正。软件会考虑局部的能量比值以及全局的能量比值。当比值均小于设定的阈值时，中程能量被计入长程能量中一起考虑。

Mid range active threshold：中程激活阈值

.. image:: media/06/img_109.png
   :width: 9.31cm
   :align: center

（3）长程校正高级设置

Hierarchic long range correction：与短程校正类似，长程校正也有分层校正的功能，启用后，也能够加快校正的速度。

.. image:: media/06/img_110.png
   :width: 5.29cm
   :align: center

Layer list for LR：需要进行长程矫正的层。

.. image:: media/06/img_111.png
   :width: 9.16cm
   :align: center

Optimal constrast：最佳对比度，默认为100。用于调整剂量，使所有图形边缘处达到清底剂量（dose-to-clear）。

Unform clearing：均匀清除，默认为0。用于调整剂量，是所有图形内部获得均匀的吸收能量。只能设置最佳对比度，均匀清除的值会由最佳对比度计算得出。

.. image:: media/06/img_112.png
   :width: 9.13cm
   :align: center

（4）保留cell剂量

该功能能够在pec过程中保持某些cell的剂量不变。在使用FDA或PEC为某些cell或layer设定剂量后，可以通过该功能，在后续的PEC步骤中使得这些cell的剂量保持不变。

.. image:: media/06/img_113.png
   :width: 9.13cm
   :align: center

Cells to keep：可以通过直接填写或右侧的按钮获取cell列表选择需要保持剂量的cell名称。保持的剂量将会根据精度设置赋予最终剂量值。

.. image:: media/06/img_114.png
   :width: 3.74cm
   :align: center

如图为保留了左上角的cell后进行PEC的结果。

.. image:: media/06/img_115.png
   :width: 6.82cm
   :align: center

（5）保留layer剂量

Layer with fixed dose：需要保持剂量的layer。选择后，即使该layer出现在LR或SR的列表中，也不会进行任何校正。保持的剂量将会根据精度设置赋予最终剂量值。

.. image:: media/06/img_116.png
   :width: 9.24cm
   :align: center

（6）单线线宽设置

Single line beam width：为无宽度的线条赋予宽度。设置后，在输出的lib中会为无宽度的线条赋予相应的宽度，并且作用于PEC中。

.. image:: media/06/img_117.png
   :width: 9.24cm
   :align: center

如图为设置线宽0.01后，输入lib和输出lib的对比。

.. image:: media/06/img_118.png
   :width: 5.86cm
   :align: center

.. image:: media/06/img_119.png
   :width: 5.88cm
   :align: center

（7）雾化效应设置

雾化效应（Fogging Effect）是指在电子束中产生的一团再散射电子云，他会对基板造成额外的、极长程的曝光贡献。该功能允许用户用被校正设计之外的图形纳入考量，因为这些极长程的效应会影响到当前区域的雾化校正剂量。通常适用于可变矩形束曝光设备。

.. image:: media/06/img_120.png
   :width: 9.16cm
   :align: center

勾选该选项后，可以点击设置对雾化效应的参数进行设置。

.. image:: media/06/img_121.png
   :width: 7.81cm
   :align: center

Sigma：雾化效应分布的高斯线的宽度。由于雾化效应是极长程效应，该值通常很大。

Weight：雾化效应对于常规PEC的剂量贡献比例，代表雾化效应在整个曝光能量中所占的相对比重。

Neighborhood density：描述当前校正区域周围的图形密度，雾化效应的作用范围极广，被校正的区域可能只是更大设计版图中的一部分，或者在晶圆上被重复排列，该参数用于评估外部大环境对当前区域雾化剂量计算的影响。

下图中，上方的图为未开启雾化效应的结果，下方为开启后的结果，可见开启雾化效应后，每个图形的剂量相对会降低一些，这就是雾化效应的剂量贡献导致的。

.. image:: media/06/img_122.png
   :width: 9.16cm
   :align: center

.. image:: media/06/img_123.png
   :width: 9.16cm
   :align: center

（8）工艺负载效应设置

工艺负载效应（Process Loading Effects），是指在显影过程中，由于局部密度的差异导致显影液消耗速率不均，从而引发的化学显影偏差。在独行密集区域，显影液中的活性成分被快速消耗且反应产物难以扩散，导致局部显影速率显著下降，光刻胶溶解不充分，最终造成线条偏粗活残留；而在图形稀疏区域，显影液充足，显影速率正常。为了补偿这种效应，软件通过提高密集区域的电子书曝光剂量，使得该区域的光刻胶更容易被显影液溶解，从而保证芯片上线宽均匀。

.. image:: media/06/img_124.png
   :width: 9.24cm
   :align: center

勾选process_loading_effects后，可以进行工艺负载效应的设置。点击设置后，弹出下图窗口。

.. image:: media/06/img_125.png
   :width: 5.1cm
   :align: center

Effect influence range：计算局部图形密度的统计半径，需要根据实际工艺实验中显影液消耗的作用范围进行设定。

Density：局部图形密度，0为完全空白区域，1为完全被图形铺满。

Development rate：相对显影速率，该值可根据观察到的工艺行为进行调整。

如下图中，上方的图为未开启工艺负载效应的结果，下方为开启的结果。可见，开启后，在密度较高的中心区域，剂量有所提升，密度较低的边缘区域，剂量降低了。

.. image:: media/06/img_126.png
   :width: 9.94cm
   :align: center

.. image:: media/06/img_127.png
   :width: 9.94cm
   :align: center

（9）周期性循环校正

对于大型重复结构阵列，当仅对单个基础单元进行校正，然后将校正结果重复应用到整个阵列时，邻近效应校正的计算速度会大幅提升。启用该功能后，软件将期望版图中仅包含一个基础单元，并根据用户输入的X、Y方向周期性信息进行校正计算。校正过程中会将这些周期性边界条件纳入考量。

.. image:: media/06/img_128.png
   :width: 9.26cm
   :align: center

勾选assume_periodic_repetition后，可以进行周期性循环校正的设置。点击设置后，弹出下图窗口。

.. image:: media/06/img_129.png
   :width: 5.97cm
   :align: center

Pitch X：阵列在X方向上的周期间距

Pitch Y：阵列在Y方向上的周期间距

Repetition X：阵列在X方向上的周期重复次数

Repetition Y：阵列在Y方向上的周期重复次数

下图为使用周期性重复校正在X与Y方向分别重复3次，并且间距略大于基础单元规模的结果。

.. image:: media/06/img_130.png
   :width: 14.65cm
   :align: center

.. _sec-6-3-2:

6.3.2 ShapePec
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Shape PEC 接收带剂量信息的版图图形，根据 PSF 曝光强度计算需要的边界位移，并输出修正后的图形。如图18所示，ShapePec模块放置在流程中。中长程影响作为预计算背景处理，短程影响在迭代中动态计算；原有 dose 属性会保留。

按 Layer 和 Datatype 选择需要处理的图形。

支持短程、中程和长程 PSF 影响，其中中程是否单独启用由阈值决定。

支持最小线段长度、单步位移、最大内缩与外扩等几何约束。

支持对满足条件的长条矩形 shot 做短程 fracture，切分后 dose 不变。

.. figure:: media/06/img_131.png
   :name: fig-ch06-img131
   :width: 12.12cm
   :align: center

   ShapePec在流程中

（1）Python接口参数如下：

spec(dm_Import_1, # dmlib输入

"*", #输入层

0.007428, #alpha参数

1.8232, #beta参数

0.6329, #eta参数

"0", #使用gamma1开关

"0.0", #gamma1参数

"0.0", #nue1参数

0, #半波全宽参数（um）

0, #精度设置模式

1, #精度设置

256, #最大剂量分级数量

0.5, #最小剂量因子

3.0, #最大剂量因子

0.01, #单剂量网格um

0, #最小裂解尺寸

0.1, #长程校正的最小图形尺寸um

0.1, #短程校正的最小图形尺寸um

{}, #用户自定义剂量等级表

0, #使用短程修正开关

0.0, #短程分离值

5, #中程激活阈值

100, #最佳对比度

0, #单线线宽

"*", #长程修正的层

"*", #短程修正的层

0, #雾效应修正开关

0.0, #雾化效应分布的高斯线的宽度

0.0, #雾化效应的贡献比例

0.0, #当前校正区域周围的图形密度

0, #工艺负载模式开关

{}, #局部图形密度

{}, #相对显影速率列表

0.0, #负载矫正半径

"", #保留不参与修正的Cell

0, #使用周期性修正

30, #阵列在X方向上的周期间距

30, #阵列在Y方向上的周期间距

8, #阵列在X方向上的重复次数

3, #阵列在Y方向上的重复次数

0, #是否开启横向显影校正

0.0, #横向显影校正步长

{}, #横向显影校正密度表

{}, #相对显影速率列表

0, #边界分割模式

0.3, #最小分割尺寸

0.0001, #移动步幅

0.003, #最大向内修正幅度

0.003, #最大向外修正幅度

1, #输入形状支持模式

0, #使用过剂量欠矫正

0.0），#过剂量欠矫正因子

（2）使用前准备

运行前请确认以下内容：

已确认输入 Layer 和 Datatype，以及短程修正所使用的 Layer List。

PSF 的 Alpha、Beta、Eta 以及可选 Gamma、Nue 已由工艺或仿真确认。

界面长度参数以 μm 为主；不要把 nm 数值直接填入 μm 输入框。

首次使用新参数时，先用小版图试跑并对比 EPE，再运行大版图。

（3）选择修正图层

1.  加载输入版图并进入 Shape PEC节点参数配置。如图 19所示，配置好必要的参数。

2.  在 Layer(s) 或 Correction Layer Selection 中填写需要处理的图层。如表1所示，需要按照格式填写图层。

3.  如界面提供 Layer List modified in SR Correction，再单独指定需要进行短程修正的图层。名单外图层仍可保留中长程背景，但不应执行动态短程修正。

表1 图层配置格式

.. list-table::
   :header-rows: 1
   :widths: 50 50

   * - 写法
     - 含义
   * - 1(0)
     - 仅选择 Layer 1、Datatype 0
   * - 5(*)
     - 选择 Layer 5 的全部 Datatype，不等于选择所有图层
   * - *
     - 选择全部 Layer 和 Datatype
   * - 1(0),*
     - 列表中含独立的 *，因此选择全部图层
   * - *,1(0)
     - 列表中含独立的 *，因此选择全部图层
   * - 1(0),*,2(0)
     - 列表中含独立的 *，因此选择全部图层

.. figure:: media/06/img_132.png
   :name: fig-ch06-img132
   :width: 10.54cm
   :align: center

   Shape PEC 主界面

（4）设置 PSF

常用 Gaussian PSF 参数如表2所示。数值应来自经过确认的 PSF 文件或工艺参数。其他Archive和Numerical的PSF设置方式为直接导入相应格式文件，具体操作如图20所示。

表2 常用 Gaussian PSF 参数

.. list-table::
   :header-rows: 1
   :widths: 33 33 33

   * - 参数
     - 作用
     - 使用提示
   * - Alpha
     - 短程作用宽度
     - 必须大于 0；短程解析计算的内部搜索范围通常为 3 倍解析后的短程宽度。
   * - Beta
     - 长程背散射宽度
     - 必须大于 0；长程作为固定背景预计算。
   * - Eta
     - 长程能量权重
     - 必须为非负数。
   * - Gamma 和 Nue
     - 可选中程宽度与权重
     - 只有启用 Gamma 且参数有效时，才存在可单独判定的中程分量。
   * - FWHM
     - 额外短程模糊
     - 增大后有效短程宽度会增大，边界位移可能明显增加。 

.. image:: media/06/img_133.png
   :width: 4.28cm
   :align: center

.. image:: media/06/img_134.png
   :width: 4.33cm
   :align: center

.. figure:: media/06/img_135.png
   :name: fig-ch06-img135
   :width: 4.31cm
   :align: center

   Shape PEC 主界面

（5）设置精度和图形参数

在Shape PEC修正过程中，形状的矫正设置参数如表3所示，表格中包含每个参数的作用及其使用建议。

表3 Shape PEC矫正设置参数

.. list-table::
   :header-rows: 1
   :widths: 25 25 25 25

   * - 参数
     - 作用
     - 建议
     - 建议
   * - Minimum Segment Length
     - 控制外边界离散线段长度
     - 越小越精细，但 segment 数量和修正时间会增加。
     -  
   * - Shift Step Size
     - 限制单次迭代的位移步长
     - 过大会使结果跳动，过小会增加迭代时间。
     -  
   * - Maximum Shift Inside
     - 限制最大向内移动量
     - 用于避免过度收缩。
     -  
   * - Maximum Shift Outside
     - 限制最大向外移动量
     - 用于避免过度外扩。
     -  
   * - Bias Type
     - 限制允许修正的边方向
     - auto 或 all angle 允许任意方向；manhattan 仅允许水平和垂直边。
     -  

短程和中程的参数设置及其对应的功能说明如表4所示。中程关闭时仍可能打印 MR/LR 百分比。该百分比是诊断信息，不代表中程已启用；应同时查看 mid_range=BACKGROUND 或 mid_range=OFF。

表4 短程和中程效应参数

.. list-table::
   :header-rows: 1
   :widths: 50 50

   * - 参数
     - 功能说明
   * - Include Short Range Correction
     - 控制是否执行动态短程修正。关闭后，不应再使用短程 PSF 移动边界。
   * - Short Range Separation Value
     - 以 polygon 的 bounding box 短边进行判定；短边小于该值时，该 polygon 不做短程修正。该值不是内部 3σ 搜索半径。
   * - Mid Range Active Threshold
     - 比较中程与长程权重百分比。中程分量存在且 MR/LR 大于阈值时，中程进入 background；否则显示 OFF。
   * - Short Range Min Figure Size
     - 用于长条矩形 shot 的短程 fracture。当前规则下，轴对齐矩形同时满足长宽比大于 10、长边大于该值的 5 倍时，只切成两块；子块继承原 dose。

（6）运行并检查结果

1.确认参数后启动 Shape PEC。大版图会按 tile 处理，看到 Processing tile 表示该 tile 已开始处理，不代表整个修正已经完成。

2.等待日志出现 Finished processing layer，再确认每个图层均已完成。

3.日志出现 Finished processing all layers 后，检查输出图形、dose 属性以及 EPE。

4.对比输入输出时，重点检查外边界位移、窄图形、长条 shot、斜边和内凹角。

（7）运行日志说明

在程序运行过程中，终端界面包含程序的运行信息，具体输出字段及其含义如表5所示。一个完整ShapePEC修正流程的输出包含的常见字段如图21所示。

表5 运行日志字段及其含义

.. list-table::
   :header-rows: 1
   :widths: 50 50

   * - 日志字段
     - 含义
   * - threads
     - 本次求解实际使用的线程数。
   * - short_cutoff
     - 动态短程解析计算的搜索半径，当前通常为解析后短程宽度的 3 倍。
   * - short_range=ON 或 OFF
     - 当前图层是否执行动态短程修正。
   * - mid_range=BACKGROUND 或 OFF
     - 中程是否作为固定 background 启用。
   * - mid/long
     - 中程与长程的权重百分比，用于和 threshold 比较。
   * - background_components
     - 固定 background 中包含的 Gaussian 分量数量；通常 1 表示只有 long，2 或更多表示还包含 mid。
   * - background_nodes
     - 粗网格 background 实际计算的节点数量。
   * - background_time
     - 该 tile 的中长程 background 预计算耗时。

.. figure:: media/06/img_136.png
   :name: fig-ch06-img136
   :width: 15.11cm
   :align: center

   运行日志与完整提示

（8）常见问题

在运行过程中，如出现修正效果不达预期，可以参照表6，基于修正现象处理建议排查参数设置合理性。

表6 常见问题和现象汇总表

.. list-table::
   :header-rows: 1
   :widths: 50 50

   * - 现象
     - 处理建议
   * - 提示 Invalid Shape PEC numeric parameter
     - 检查 Alpha、Beta、Shift Step 是否大于 0，Eta 和最大内外移动量是否为非负值，并确认单位。
   * - 修正效果不明显
     - 确认目标层确实被选中、short_range 状态为 ON、最大位移不为 0，并检查 PSF、dose 和目标阈值是否匹配。
   * - 图形向外偏移过多
     - 优先检查 FWHM、Alpha、最大外扩量和 μm/nm 单位；先恢复已验证参数再逐项调整。
   * - 名单外图层仍被短程修正
     - 检查 Short Range Layer List 的通配符。只要列表中包含独立的 *，就表示所有图层。
   * - 中程显示 OFF 但仍有百分比
     - 百分比只是权重诊断。以 mid_range=BACKGROUND 或 OFF 作为是否启用的判断。
   * - 出现 Non-orientable polygon
     - 通常与极小线段、过细图形或修正后退化几何有关。提高最小线段长度、减小位移或恢复更保守的 separation 后重新测试。
   * - 分离长短程后变慢
     - 先比较 background_time 与 tile 总耗时；若 background 很快，缩小短程修正图层范围或适当增大 Minimum Segment Length。

.. _sec-6-3-3:

6.3.3 EDGEPEC模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

EDGE PEC适用任务为依据阈值或显影模型进行边缘相关剂量修正，主要输入为修正图层、PSF、胶层与剂量设置。

Python 接口

本模块使用 egpec_ui 接收上游版图并返回处理结果。本节先说明接口调用与参数，后续章节介绍 Edge PEC 的功能、界面设置和操作步骤。

调用方式

dm_result = egpec_ui(dm_Import_1, ...)

上式仅说明调用结构，省略号不能直接作为完整调用使用。第一个参数是上游节点产生的 dmLib pair；返回值可传给后续处理或 Export 节点。请从“查看 Python”或完整 Flow 导出实际脚本。

调用采用位置参数：逗号前是实际参数值，# 后是说明注释。修改数值时必须保留参数位置；注释中的名称并不表示绑定支持同名关键字参数。不要把另一版本的完整调用直接套到当前接口上，也不要删掉关闭功能所占的参数位置。

【1.2】单位与数组

长度以参数后缀为准：_nm 为纳米，_um 为微米，1 μm = 1000 nm。_percent 是百分数，输入 5 表示 5%；density、factor 和 weight 等比例参数通常采用无量纲数值，不能因界面显示百分比而自行乘除 100。布尔开关通常使用 0 或 1；模式编号是枚举，不应统一当作开关。

配对数组应等长，图层、材料与曲线应保持对应顺序。截图中的数值是配置示例，不是推荐工艺配方。以下参数按功能分组解释，不代替导出脚本的位置参数顺序。

【1.3】调用前检查

若第一个参数显示 None，先检查节点是否连接到有效输入，再重新导出完整 Flow。若开头出现 raise ValueError(...)，该脚本执行到这里会停止：应返回界面补齐配置，重新应用并导出，不要简单删除报错行强行运行。

Selected PSF needs at least two points 表示所选 PSF 的有效采样点不足。应补齐所选 PSF 的有效数据后重新导出。

运行环境须能访问使用的 PSF 文件及输出路径。修改曲线或图层行时，同步修改相关数组；保留关闭功能对应的参数位置。

【1.4】参数说明

输入和 PSF

.. list-table::
   :header-rows: 1
   :widths: 50 50

   * - 参数名称
     - 中文说明与使用要求
   * - 输入 dmLib pair
       in_layers
     - 上游版图及候选图层。in_layers 是图层选择字符串。
   * - pec_type
     - PSF 类型选择；保留当前界面导出的枚举值。数值 PSF 使用对应采样表。
   * - alpha_nm / beta_nm / eta
     - 短程、长程高斯尺度（nm）及相对权重。
   * - enable_gammal / gammal / nuel
     - 附加高斯项的开关、尺度与权重；gammal 的解释随 PSF 模式而定，应保留界面转换后的值。
   * - fwhm_nm
     - 有效模糊半高全宽，nm。不是几何线宽。
   * - numeric_psf_density_radii_um
       numeric_psf_density_values
     - 数值能量密度 PSF 的半径（μm）与数值数组，逐点对应。
   * - numeric_psf_cumulative_radii_um
       numeric_psf_cumulative_values
     - 累积能量 PSF 的半径（μm）与累积值数组，逐点对应。

剂量与离散

.. list-table::
   :header-rows: 1
   :widths: 50 50

   * - 参数名称
     - 中文说明与使用要求
   * - minimum_dose_factor
       maximum_dose_factor
     - 相对剂量的下限与上限；均为无量纲，最大值不小于最小值。
   * - dose_grid_nm / pec_accuracy_percent
       max_dose_classes
     - 剂量网格（nm）、相对精度（%）、最大剂量档数。
   * - dose_class_mode / dose_levels_tab
     - 剂量分档模式及自定义档位表；自定义模式下提供有效正值列表。
   * - fracture_mode / fracture_overlap_nm
     - 图形分割模式及重叠长度（nm）。
   * - automatic_minimum_figure_size
       short_range_min_figure_size_nm
       long_range_min_figure_size_nm
     - 自动最小尺寸开关，以及手动短程和长程最小图形尺寸（nm）。

【1.5】 工艺与胶层参数

显影与工艺目标

.. list-table::
   :header-rows: 1
   :widths: 50 50

   * - 参数名称
     - 中文说明与使用要求
   * - process_model
     - 工艺模型：1 为 Threshold，2 为 Development Rate。
   * - threshold_include_short_range
     - Threshold 模式是否纳入短程贡献。
   * - base_dose_uc_cm2
       critical_resist_index
     - 基准剂量（μC/cm²）与关键胶层索引；索引从 0 开始。
   * - enable_lateral_development
       ldc_shift_step_nm
     - 横向显影开关与边界位移步长（nm）。
   * - ldc_density_tab / ldc_bias_nm_tab
     - 局部密度与横向偏移量（nm）的配对表。
   * - lateral_density_radius_nm
       lateral_density_threshold
       lateral_fallback_dev_nm
     - 密度统计半径（nm）、判定阈值与回退显影偏移量（nm）。
   * - coupled_edge_solver
     - 选择耦合边缘求解路径。常规使用保留导出的设置。

多胶层数据

.. list-table::
   :header-rows: 1
   :widths: 50 50

   * - 参数名称
     - 中文说明与使用要求
   * - resist_layer_lists
       resist_no_lateral_layer_lists
     - 各胶层参与处理的图层组，以及不做横向处理的图层组；保持导出器生成的字符串分组。
   * - resist_dose_factors
       resist_no_lateral_dose_factors
     - 各胶层正常区域和免横向处理区域的剂量因子，按胶层顺序对应。
   * - resist_thickness_um
       resist_original_thickness_um
     - 各胶层厚度与曲线标定初始胶厚（μm）。
   * - resist_contrast_point_counts
     - 各胶层对比度曲线的采样点数，用于拆分后面的拼接数组。
   * - resist_contrast_doses_uc_cm2
       resist_contrast_remaining_um
     - 依次拼接各胶层的剂量（μC/cm²）与剩余厚度（μm）数组；长度应等于采样点数之和。
   * - resist_diffusion_um
     - 各胶层扩散长度（μm），顺序与胶层一致。

【1.6】高级参数

.. list-table::
   :header-rows: 1
   :widths: 50 50

   * - 参数名称
     - 中文说明与使用要求
   * - enable_short_range
       short_range_separation_nm
       short_range_alpha / short_range_layer_list
     - 短程开关、分界距离（nm）、求解系数与作用图层。
   * - enable_mid_range
       mid_range_activation_threshold_nm
       mid_range_separation_nm
       mid_range_alpha / mid_range_layer_list
     - 中程开关、旧式长度阈值（nm）、分界距离（nm）、求解系数与作用图层。不要与百分比阈值混用。
   * - mid_range_activation_threshold_percent
     - 中程贡献激活阈值（%），例如 5 表示 5%。
   * - enable_long_range / long_range_alpha
       long_range_sigma_nm
       long_range_sigma_factor
       long_range_layer_list
     - 长程开关、求解系数、sigma（nm）、尺度系数与作用图层。
   * - enable_fogging / fog_sigma_nm
       fog_weight / fog_density / fog_layer_list
     - Fogging 开关、sigma（nm）、权重、邻域密度与作用图层。sigma 不是 FWHM。
   * - enable_loading
       le_density_tab / le_rate_tab
       le_dose_scale_tab
       loading_influence_radius_nm
     - Loading 开关、密度与速率表、剂量缩放表及作用半径（nm）；配对表按同一密度采样组织。
   * - enable_blur_dependency
       blur_size_um / blur_factors
     - 尺寸相关模糊开关；尺寸（μm）与模糊因子逐项对应。
   * - cells_to_keep
     - 需要保留处理的 Cell 名称字符串；不是图层选择。
   * - single_line_beam_width_um
     - 零宽 PATH 的有效全宽，μm。100 nm 对应 0.1 μm。
   * - comment
     - 备注字符串，用于记录当前配置说明。

多胶层曲线示例：若 resist_contrast_point_counts 为 [2, 3]，拼接数组的前 2 点属于第一胶层，后 3 点属于第二胶层。只调整曲线点而不修改点数，会使后续胶层的数据对应错误。

（2）模块用途与功能

Edge PEC 关注图形边缘附近的剂量与显影响应。Threshold 模式按阈值判断曝光条件；Development Rate 模式利用剂量与剩余胶厚的关系描述显影响应。多胶层设置用于为不同区域指定材料参数及剂量因子，Critical Resist 指定用于关键工艺判断的胶层。

【2.1】PSF与工艺输入

PSF 描述一次曝光的能量如何向周围扩散。Gaussian 用短程、长程及可选附加高斯项描述分布；Numeric 或 Archive 使用采样数据。能量密度曲线和累积能量曲线是同一分布的不同表达，导出时应保持半径与数值一一对应。附加 Gamma 项用于补充原有模型未充分描述的尺度，不应仅为了让预览更平滑而启用。

对比度曲线描述曝光剂量与显影后剩余胶厚的关系。横坐标是剂量，纵坐标是剩余胶厚；它不是 PSF，也不是 Dose Factor 表。多胶层曲线应与对应的初始胶厚、材料和显影条件一致。改变曲线会改变工艺目标所需的剂量，不能仅通过调整网格抵消。

【2.2】剂量与离散精度

Base Dose 是物理曝光剂量基准，Dose Factor 是相对于基准的无量纲比例。Minimum 和 Maximum Dose Factor 限定允许的剂量范围；Accuracy 模式按精度和最大档数组织输出剂量，User Defined 模式使用指定剂量表。档数增加会提高表达细节的能力，也可能增加输出复杂度；应结合设备可接受的剂量档位设置。

Fracture Grid 和 Isodose Grid 描述离散或输出划分尺度，Minimum Figure Size 限制小图形的处理尺度。较细设置通常会增加计算量及输出数据量。Automatic 模式由模块选择最小尺寸，手动模式才需要逐项指定短程、长程最小尺寸。不要将这些数值当作实际线宽。

【2.3】短程与长程

短程校正处理近距离散射对细节的影响，长程校正处理更大范围的背景剂量耦合。Short Range Separation 是分界位置；自动或手动分界开关与是否启用短程校正是不同设置。Mid Range Activation Threshold 按中程贡献决定是否启用相应处理，其百分比字段与 nm 长度字段不能互换。

【2.4】高级功能与输入处理

Lateral Development 考虑横向显影引起的边界变化，可使用密度与偏移量表，并通过位移步长和影响半径控制处理。胶层扩散长度、PSF 模糊宽度与横向偏移量表达不同作用。

背景与工艺密度效应：Fogging 表示额外的广域背景曝光贡献，通常同时需要分布宽度、权重或剂量贡献以及邻域密度。Process Loading 用局部图形密度与相对工艺速率表描述密度依赖效应。两者物理含义不同；只开开关而不填写有效表格，不能得到可靠校正。

尺寸相关模糊：Blur Dependency 用尺寸与模糊因子的对应表描述图形尺寸变化引起的模糊变化。尺寸表应递增，两个数组等长，因子应为有效正值。该功能是在基础模糊模型上加入尺寸依赖，不能替代 PSF 数据。

保留Cell：Cells to Keep 指定需要保留处理的 Cell 名称，不代替输入图层选择，也不表示无条件透传整个输入库。运行后应核对保留内容的图层、几何及剂量属性。

零宽PATH：Single Line Beam Width 为零宽 PATH 指定参与计算的有效全宽，接口单位为 μm。它不是半宽，也不是 PSF 的 FWHM；原本已有宽度的 PATH 应使用自身宽度。零值的具体处理应以所用版本为准。

（3）界面设置

Edge PEC 用于按所选 PSF 和胶层模型修正电子束邻近效应。General 页中的 Layer(s) 指定需要校正的图层，PSF Representation 选择 Gaussian、Archive 或 Numeric；下图示出 General 页的主要字段。

.. image:: media/06/img_137.png
   :width: 15.3cm
   :align: center

Edge PEC 的 General 页与 PSF 预览示意

在 3D PEC 页选择 Threshold 或 Development Rate 模式。Threshold 侧重阈值剂量设置；Development Rate 还需为胶层填写厚度与有效的对比度曲线。设置项及检查重点见下表。

表1  Edge PEC 主要设置

.. list-table::
   :header-rows: 1
   :widths: 33 33 33

   * - 位置
     - 填写内容
     - 检查重点
   * - General
     - 修正图层、PSF、FWHM
     - 确认图层存在，导入曲线非空
   * - 3D PEC
     - Base Dose、胶层、工艺模型
     - Development Rate 模式需胶厚和曲线
   * - Accuracy/Advanced
     - 剂量档位、网格、可选效应
     - 只检查已启用选项的参数

（4）操作步骤与参数检查

先在 General 页确认修正图层和 PSF。Gaussian 由 Alpha、Beta、Eta 表示；Archive 和 Numeric 使用导入的曲线。右侧 PSF 预览用于检查径向分布；切换 Energy Density 或 Cumulative 只改变显示方式。导入后应核对曲线、横轴单位以及短长程分界。

工艺模型可选择 Threshold 或 Development Rate。Threshold 侧重剂量阈值；Development Rate 需要有效胶厚和剂量—剩余胶厚曲线。使用材料库时，应选定 Resist 和 Developer；使用 Numeric 曲线时，应录入有序采样点。

Accuracy 页的 Fracture Mode、Dose Class Definition、Isodose Grid 和 Minimum Figure Size 决定剂量档位与图形离散方式，位置见下图；字段规则见下表。

.. image:: media/06/img_138.png
   :width: 14.0cm
   :align: center

Edge PEC 精度与剂量档位设置示意

Edge PEC 精度与高级参数填写规则

.. list-table::
   :header-rows: 1
   :widths: 33 33 33

   * - 设置
     - 如何填写
     - 错误时先检查
   * - Accuracy
     - 填写精度百分比及最大剂量档数
     - 数值是否为有效正数
   * - User Defined
     - 按升序填写剂量因子表
     - 空表、重复项或越界值
   * - Minimum Figure Size
     - Automatic 或分别填写短长程最小尺寸
     - 手动模式的尺寸及单位
   * - Advanced
     - 仅启用需要的分离、Fogging、Loading
     - 启用后的弹窗和表格是否完整

应用后若提示 PSF 或 Contrast Curve 无效，应先回到当前选中的模式补齐数据。运行前再次核对输入版图中确实存在所选 Layer/Datatype。

（5）结果检查与常见提示

先在界面应用配置并处理提示，再运行模块。应用通过表示参数已通过校验；是否完成计算，应结合运行日志和实际输出判断。

【5.1】结果检查

先看日志是否明确报告完成，再检查输出图层数量、Layer/Datatype 与输入选择是否一致。仅有 READY 状态或 PSF 预览，并不代表数值计算已经结束。

抽查窄线、密集区、孤立图形及不同剂量区域，对比输出形状和 dose 属性。空输出应区分“按配置忽略后无待处理图形”和运行失败；若预期有图形而输出为空，检查图层选择及输入内容。

保存实际使用的 PSF、剂量、材料或地形配置。新参数先在小版图上验证，再用于完整版图。

【5.2】常见提示

NOT READY：检查当前选中的模式是否填写完整，例如 PSF、图层或曲线。READY 后没有结果：检查运行日志、输入连接和输出节点，不能只凭预览判断计算完成。

显影响应异常：核对 Threshold 或 Development Rate 模式，并检查胶层顺序、厚度、对比度曲线及横向显影配置。

.. _sec-6-3-4:

6.3.4 TGATEPEC模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

T Gate PEC适用任务为分别处理 Wing、Undercut、Foot 的 T 栅结构，主要输入为三个结构区域的图层、胶厚和对比度曲线。

（1）Python接口

本模块使用 tgatepec_ui 接收上游版图并返回处理结果。本节先说明接口调用与参数，后续章节介绍 TGate PEC 的功能、界面设置和操作步骤。

调用方式

dm_result = tgatepec_ui(dm_Import_1, ...)

上式仅说明调用结构，省略号不能直接作为完整调用使用。第一个参数是上游节点产生的 dmLib pair；返回值可传给后续处理或 Export 节点。请从“查看 Python”或完整 Flow 导出实际脚本。

调用采用位置参数：逗号前是实际参数值，# 后是说明注释。修改数值时必须保留参数位置；注释中的名称并不表示绑定支持同名关键字参数。不要把另一版本的完整调用直接套到当前接口上，也不要删掉关闭功能所占的参数位置。

单位与数组

长度以参数后缀为准：_nm 为纳米，_um 为微米，1 μm = 1000 nm。_percent 是百分数，输入 5 表示 5%；density、factor 和 weight 等比例参数通常采用无量纲数值，不能因界面显示百分比而自行乘除 100。布尔开关通常使用 0 或 1；模式编号是枚举，不应统一当作开关。

配对数组应等长，图层、材料与曲线应保持对应顺序。截图中的数值是配置示例，不是推荐工艺配方。以下参数按功能分组解释，不代替导出脚本的位置参数顺序。

调用前检查

若第一个参数显示 None，先检查节点是否连接到有效输入，再重新导出完整 Flow。若开头出现 raise ValueError(...)，该脚本执行到这里会停止：应返回界面补齐配置，重新应用并导出，不要简单删除报错行强行运行。

Selected PSF needs at least two points 表示所选 PSF 的有效采样点不足。Wing 需要一个精确 Layer/Datatype，例如 20/0，不能用“*”替代结构角色层。

运行环境须能访问使用的 PSF 文件及输出路径。修改曲线或图层行时，同步修改相关数组；保留关闭功能对应的参数位置。

参数说明

输入与公共设置

.. list-table::
   :header-rows: 1
   :widths: 50 50

   * - 参数名称
     - 中文说明与使用要求
   * - 输入 dmLib pair / in_layers
     - 上游输入与候选图层；结构角色由后面的 top、middle、bottom 和 contact 定义。
   * - alpha_nm / beta_nm / eta
       add_gamma / gamma_nm / nue
     - 高斯 PSF 的短长程尺度（nm）、相对权重，以及附加项开关、尺度和权重。
   * - effective_short_range_blur_nm
     - 有效短程模糊宽度（nm），由界面输出。
   * - accuracy_mode
       relative_accuracy_percent
       maximum_dose_classes
     - 0 使用相对精度，1 使用自定义剂量表；精度单位为 %，档数为整数。
   * - minimum_dose_factor
       maximum_dose_factor / dose_table
     - 相对剂量上下限与自定义剂量因子表。
   * - fracture_grid_nm
       automatic_minimum_figure_size
       short_range_minimum_figure_size_nm
       long_range_minimum_figure_size_nm
     - 输出分割网格（nm）、自动最小尺寸开关，以及手动短长程最小尺寸（nm）。
   * - short_range_layer_list
       short_range_separation_nm
       mid_range_activation_threshold_percent
       long_range_layer_list
     - 短程图层、短长程分界（nm）、中程贡献阈值（%）与长程图层。
   * - process_loading_correction
       loading_influence_range_nm
       local_density_table
       relative_etch_rate_table
     - Loading 开关、影响范围（nm）、密度与相对速率配对表。
   * - reserved_cell_list
       zero_width_path_width_nm
     - 保留 Cell 名称及零宽 PATH 的有效全宽（nm）。
   * - fogging_correction
       fogging_gaussian_fwhm_nm
       fogging_dose_contribution
       adjacent_pattern_density
     - Fogging 开关、高斯 FWHM（nm）、剂量贡献与邻域密度。

结构角色与曲线

角色层与工艺参数

.. list-table::
   :header-rows: 1
   :widths: 50 50

   * - 参数名称
     - 中文说明与使用要求
   * - top_layer / top_resist_thickness_nm
     - Wing 图层与顶部胶厚（nm）；图层使用一个精确 Layer/Datatype，如 22/0。
   * - top_contrast_dose_table
       top_remaining_thickness_nm_table
     - 顶部胶层剂量与剩余厚度（nm）的配对曲线。
   * - middle_layer / middle_resist_thickness_nm
     - Undercut 图层与中间胶厚（nm）；未使用该区域时保留导出的空配置。
   * - middle_contrast_dose_table
       middle_remaining_thickness_nm_table
     - 中间胶层剂量与剩余厚度（nm）的配对曲线。
   * - bottom_layer
       bottom_resist_thickness_nm
     - Foot 图层与底部胶厚（nm）。
   * - bottom_contrast_dose_table
       bottom_remaining_thickness_nm_table
     - 底部胶层剂量与剩余厚度（nm）的配对曲线。
   * - base_dose_uc_cm2
     - 物理基准剂量（μC/cm²）；对比度剂量表应采用同一标定单位。
   * - contact_layer
       bottom_dose_factor / contact_dose_factor
     - 可选 Contact 图层及 Foot、Contact 相对剂量因子。
   * - experimental_multiscale_step_nm
     - 实验多尺度步长（nm）；常规保留导出值 -1，不因它带有长度单位就改成图形线宽。
   * - blur_element_size_nm / blur_factors
     - 图形尺寸（nm）与模糊因子的配对表。

例如 top_layer 为 22/0、bottom_layer 为 24/0，表示这两个图层分别承担 Wing 和 Foot 角色。输入 in_layers 为“*”仅扩展候选输入范围，不会把其他层自动指定为 Wing 或 Foot。

每条对比度曲线的剂量表与剩余厚度表必须等长，剂量按递增顺序排列。剩余厚度采用 nm；不要把 以 μm 表示的厚度数组未经换算直接复制进来。

（2）模块用途与功能

TGate PEC 用不同图层描述 Wing、Undercut 和 Foot，并为各区域指定胶厚与对比度曲线。Wing 对应顶部区域，Undercut 对应中间区域，Foot 对应底部区域；Contact 是可选接触区。输入层选择只确定候选范围，实际结构角色仍由这些专用图层决定，不能用输入“*”代替 Wing 或 Foot 的精确层定义。

【2.1】PSF与工艺输入

PSF 描述一次曝光的能量如何向周围扩散。Gaussian 用短程、长程及可选附加高斯项描述分布；Numeric 或 Archive 使用采样数据。能量密度曲线和累积能量曲线是同一分布的不同表达，导出时应保持半径与数值一一对应。附加 Gamma 项用于补充原有模型未充分描述的尺度，不应仅为了让预览更平滑而启用。

对比度曲线描述曝光剂量与显影后剩余胶厚的关系。横坐标是剂量，纵坐标是剩余胶厚；它不是 PSF，也不是 Dose Factor 表。多胶层曲线应与对应的初始胶厚、材料和显影条件一致。改变曲线会改变工艺目标所需的剂量，不能仅通过调整网格抵消。

【2.2】剂量与离散精度

Base Dose 是物理曝光剂量基准，Dose Factor 是相对于基准的无量纲比例。Minimum 和 Maximum Dose Factor 限定允许的剂量范围；Accuracy 模式按精度和最大档数组织输出剂量，User Defined 模式使用指定剂量表。档数增加会提高表达细节的能力，也可能增加输出复杂度；应结合设备可接受的剂量档位设置。

Fracture Grid 和 Isodose Grid 描述离散或输出划分尺度，Minimum Figure Size 限制小图形的处理尺度。较细设置通常会增加计算量及输出数据量。Automatic 模式由模块选择最小尺寸，手动模式才需要逐项指定短程、长程最小尺寸。不要将这些数值当作实际线宽。

【2.3】短程与长程

短程校正处理近距离散射对细节的影响，长程校正处理更大范围的背景剂量耦合。Short Range Separation 是分界位置；自动或手动分界开关与是否启用短程校正是不同设置。Mid Range Activation Threshold 按中程贡献决定是否启用相应处理，其百分比字段与 nm 长度字段不能互换。

【2.4】高级功能与输入处理

背景与工艺密度效应：Fogging 表示额外的广域背景曝光贡献，通常同时需要分布宽度、权重或剂量贡献以及邻域密度。Process Loading 用局部图形密度与相对工艺速率表描述密度依赖效应。两者物理含义不同；只开开关而不填写有效表格，不能得到可靠校正。

尺寸相关模糊：Blur Dependency 用尺寸与模糊因子的对应表描述图形尺寸变化引起的模糊变化。尺寸表应递增，两个数组等长，因子应为有效正值。该功能是在基础模糊模型上加入尺寸依赖，不能替代 PSF 数据。

保留Cell：Cells to Keep 指定需要保留处理的 Cell 名称，不代替输入图层选择，也不表示无条件透传整个输入库。保留内容仍应经过 Wing、Undercut、Foot 和 Contact 角色层选择；接后续节点时应核对输出的图层与剂量属性。

零宽PATH：Single Line Beam Width 为零宽 PATH 指定参与计算的有效全宽，接口单位为 nm。它不是半宽，也不是 PSF 的 FWHM；原本已有宽度的 PATH 应使用自身宽度。零值的具体处理应以所用版本为准。

（3）界面设置

TGate PEC 将 T 栅结构分为 Wing、Undercut 和 Foot。先设置 Wing 与 Foot 的图层、厚度和对比度曲线；Undercut 仅在实际工艺需要时填写。Foot 和 Contact 可分别设置 Dose Factor。下图显示 3D PEC 页的区域划分。

.. image:: media/06/img_139.png
   :width: 11.7cm
   :align: center

TGate PEC 的 Wing Undercut 和 Foot 设置示意

Contrast Curve Mode 可选材料库或 Numeric。Numeric 模式下，分别输入剂量与剩余胶厚的曲线点，并核对 Original Thickness。下表列出需要优先核对的项目；Accuracy 页还能选择按精度生成剂量档位或使用自定义剂量表。

TGate PEC 区域参数

.. list-table::
   :header-rows: 1
   :widths: 33 33 33

   * - 区域
     - 主要字段
     - 使用提示
   * - Wing
     - 图层、胶厚、对比度曲线
     - 必须与实际 Wing 图层一致
   * - Undercut
     - 图层、胶厚、对比度曲线
     - 没有该区域时留空
   * - Foot/Contact
     - 图层、胶厚、Dose Factor
     - Foot 为主要结构；Contact 按需填写

（4）操作步骤与参数检查

TGate 的 3D PEC 页按 Wing、Undercut、Foot 顺序设置。Wing 与 Foot 是必需的：分别填 Layer List、Thickness 和 Contrast Curve；只有工艺中存在下切区域时才填写 Undercut。Foot Dose Factor 调整 Foot 剂量；有独立接触区时再设置 Contact Layer List 和对应因子。建议顺序见下表。

TGate PEC 建议填写顺序

.. list-table::
   :header-rows: 1
   :widths: 33 33 33

   * - 步骤
     - 操作
     - 完成后检查
   * - 1
     - 选择 PSF、修正图层并设置 Base Dose
     - PSF 预览、图层与单位
   * - 2
     - 设置 Wing，再设置 Foot
     - 各自图层、胶厚、对比度曲线
   * - 3
     - 按需要设置 Undercut 和 Contact
     - 不用时留空；启用时参数完整
   * - 4
     - 设置剂量档位及高级选项
     - 表格有序，已启用选项有效

在 Numeric Contrast Curve 弹窗中，Original Thickness 是初始胶厚；表格每行是 Dose 与该剂量下的 Resist Thickness。曲线点按剂量升序填写，剩余胶厚应处于合理范围。材料库模式则需先选 Resist 和 Developer，再核对曲线与本次胶厚。

Accuracy 页可按 Accuracy 自动生成档位，或在 User Defined 中手动维护剂量表。手动表支持 Import、Export、Insert Row、Delete Row，界面见下图。Minimum Figure Size 为 Automatic 时不必填写手动尺寸；选 Userdefined 后，再检查长短程最小尺寸。

.. image:: media/06/img_140.png
   :width: 9.0cm
   :align: center

TGate PEC 自定义剂量表和最小尺寸设置示意

Advanced 页按需启用 Fogging、Process Loading 或 Blur Dependency。Blur Variability 表以 ElementSize [μm] 和 Blur Factor 描述尺寸相关模糊；启用后按尺寸升序录入正的因子。

（5）结果检查与常见提示

先在界面应用配置并处理提示，再运行模块。应用通过表示参数已通过校验；是否完成计算，应结合运行日志和实际输出判断。

【5.1】结果检查

先看日志是否明确报告完成，再检查输出图层数量、Layer/Datatype 与输入选择是否一致。仅有 READY 状态或 PSF 预览，并不代表数值计算已经结束。

抽查窄线、密集区、孤立图形及不同剂量区域，对比输出形状和 dose 属性。空输出应区分“按配置忽略后无待处理图形”和运行失败；若预期有图形而输出为空，检查图层选择及输入内容。

保存实际使用的 PSF、剂量、材料或地形配置。新参数先在小版图上验证，再用于完整版图。

【5.2】常见提示

NOT READY：检查当前选中的模式是否填写完整，例如 PSF、图层或曲线。READY 后没有结果：检查运行日志、输入连接和输出节点，不能只凭预览判断计算完成。

角色层未匹配：检查输入候选层与 Wing、Undercut、Foot、Contact 的交集。“*”只扩大候选范围，不会自动生成角色映射。保留 Cell 也应采用同样的角色层筛选。

.. _sec-6-3-5:

6.3.5 TOPOLOGYPEC模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Topology PEC适用任务是为不同图层指定 PSF，并考虑地形与边缘影响，主要输入为逐层 PSF、相对基准剂量、可选边缘表。

（1）Python接口

本模块使用 toppec_ui 接收上游版图并返回处理结果。本节先说明接口调用与参数，后续章节介绍 Topology PEC 的功能、界面设置和操作步骤。

【1.1】调用方式

dm_result = toppec_ui(dm_Import_1, ...)

上式仅说明调用结构，省略号不能直接作为完整调用使用。第一个参数是上游节点产生的 dmLib pair；返回值可传给后续处理或 Export 节点。请从“查看 Python”或完整 Flow 导出实际脚本。

调用采用位置参数：逗号前是实际参数值，# 后是说明注释。修改数值时必须保留参数位置；注释中的名称并不表示绑定支持同名关键字参数。不要把另一版本的完整调用直接套到当前接口上，也不要删掉关闭功能所占的参数位置。

【1.2】单位与数组

长度以参数后缀为准：_nm 为纳米，_um 为微米，1 μm = 1000 nm。_percent 是百分数，输入 5 表示 5%；density、factor 和 weight 等比例参数通常采用无量纲数值，不能因界面显示百分比而自行乘除 100。布尔开关通常使用 0 或 1；模式编号是枚举，不应统一当作开关。

配对数组应等长，图层、材料与曲线应保持对应顺序。截图中的数值是配置示例，不是推荐工艺配方。以下参数按功能分组解释，不代替导出脚本的位置参数顺序。

【1.3】调用前检查

若第一个参数显示 None，先检查节点是否连接到有效输入，再重新导出完整 Flow。若开头出现 raise ValueError(...)，该脚本执行到这里会停止：应返回界面补齐配置，重新应用并导出，不要简单删除报错行强行运行。

Selected PSF needs at least two points 表示所选 PSF 的有效采样点不足。应补齐所选 PSF 的有效数据后重新导出。

运行环境须能访问使用的 PSF 文件及输出路径。修改曲线或图层行时，同步修改相关数组；保留关闭功能对应的参数位置。

【1.4】参数说明

输入与精度

.. list-table::
   :header-rows: 1
   :widths: 50 50

   * - 参数名称
     - 中文说明与使用要求
   * - 输入 dmLib pair / in_layers
     - 上游输入版图及候选图层。
   * - alpha_nm / beta_nm / eta
       add_gamma / gamma_nm / nue
     - 高斯 PSF 的尺度（nm）、权重及附加高斯项设置。
   * - effective_short_range_blur_nm
     - 有效短程模糊宽度，nm。
   * - accuracy_mode
       relative_accuracy_percent
       maximum_dose_classes
     - 0 按相对精度分档，1 使用自定义剂量表；精度为 %。
   * - minimum_dose_factor
       maximum_dose_factor / dose_table
     - 相对剂量上下限与自定义剂量因子表。
   * - fracture_grid_nm
       automatic_minimum_figure_size
       long_range_minimum_figure_size_nm
     - 分割网格（nm）、自动最小尺寸开关与手动长程最小尺寸（nm）。
   * - short_range_correction
       short_range_layer_list
       long_range_layer_list
     - 短程校正开关，以及短程、长程作用图层。
   * - short_range_separation_nm
       use_short_range_separation
     - 分界距离（nm）与界面分界选择标志。它与 short_range_correction 是不同设置，应保留界面导出的自动或手动配置。
   * - mid_range_activation_threshold_percent
     - 中程贡献激活阈值，%。
   * - reserved_cell_list
       zero_width_path_width_nm
     - 保留 Cell 名称及零宽 PATH 的有效全宽（nm）。

Topology 的 Single Line Beam Width 在接口中以 nm 传递。零束宽跳过版本中，该值为 0 时忽略零宽 PATH；已有宽度的 PATH 不应因此被丢弃。需要保留零宽线参与计算时，设置有效正宽度并检查换算后的输出尺寸。

【1.5】地形与高级参数

.. list-table::
   :header-rows: 1
   :widths: 50 50

   * - 参数名称
     - 中文说明与使用要求
   * - edge_effect_correction
     - 地形边缘效应开关。启用时补齐边缘表。
   * - edge_distance_nm_table
       edge_width_nm_table
       edge_dose_factor_table
     - 边缘距离（nm）、作用宽度（nm）及剂量因子；三个数组按同一行对应。
   * - topography_layer_list
     - 地形图层列表字符串，顺序与相对基准剂量和 PSF 列表对应。
   * - topography_relative_base_dose_table
       topography_psf_file_list
     - 各地形图层的相对基准剂量数组与 PSF 文件列表字符串。文件路径需在执行环境中可访问。
   * - optimal_contrast_percent
     - 最佳对比度设置，0～100%。这是模块参数，不是材料曲线数组。
   * - create_new_topography_layer
     - 是否新建地形相关输出图层。
   * - process_loading_correction
       loading_influence_range_nm
       local_density_table
       relative_etch_rate_table
     - Loading 开关、影响范围（nm）、局部密度与相对速率表。
   * - fogging_correction
       fogging_gaussian_fwhm_nm
       fogging_dose_contribution
       adjacent_pattern_density
     - Fogging 开关、FWHM（nm）、背景剂量贡献与邻域密度。
   * - enable_blur_dependency
       blur_size_nm / blur_factors
     - 尺寸相关模糊开关、尺寸（nm）与因子数组。

如果 Topography 表有两行，必须保证两项图层、两项相对剂量和两份 PSF 在同一顺序上对应。仅将图层列表排序而不同时调整其余两项，会把某一区域的 PSF 应用到另一图层。

（2）模块用途与功能

Topology PEC 用于不同版图区域具有不同散射条件的情况。Topography 表将图层、相对基准剂量和 PSF 逐行关联；Edge Effects 描述地形边界附近的附加影响。逐层 PSF 与边缘表承担不同作用，不能只填写边缘表就省略各层所需的 PSF。

【2.1】PSF与工艺输入

PSF 描述一次曝光的能量如何向周围扩散。Gaussian 用短程、长程及可选附加高斯项描述分布；Numeric 或 Archive 使用采样数据。能量密度曲线和累积能量曲线是同一分布的不同表达，导出时应保持半径与数值一一对应。附加 Gamma 项用于补充原有模型未充分描述的尺度，不应仅为了让预览更平滑而启用。

Topography 表为不同区域指定 PSF 和相对基准剂量。每一行的图层、PSF 与相对剂量必须配套；边缘效应表仅补充边界附近的影响，不能代替逐层 PSF。

【2.2】剂量与离散精度

Relative Base Dose 是各地形区域的相对基准剂量。Minimum 和 Maximum Dose Factor 限制剂量范围；Accuracy 模式按精度与最大档数分档，User Defined 使用指定剂量表。增加档数可能增加输出复杂度。

Fracture Grid 和 Isodose Grid 描述离散或输出划分尺度，Minimum Figure Size 限制小图形的处理尺度。较细设置通常会增加计算量及输出数据量。Automatic 模式由模块选择最小尺寸，手动模式才需要逐项指定短程、长程最小尺寸。不要将这些数值当作实际线宽。

【2.3】短程与长程

短程校正处理近距离散射对细节的影响，长程校正处理更大范围的背景剂量耦合。Short Range Separation 是分界位置；自动或手动分界开关与是否启用短程校正是不同设置。Mid Range Activation Threshold 按中程贡献决定是否启用相应处理，其百分比字段与 nm 长度字段不能互换。

【2.4】高级功能与输入处理

Optimal Contrast 对应 optimal_contrast_percent，用于调整模块的最佳对比度设置。它不是材料对比度曲线，也不能直接解释为 Base Dose 的乘数。Create new Layer 控制地形相关输出图层的组织方式，不改变 PSF。

背景与工艺密度效应：Fogging 表示额外的广域背景曝光贡献，通常同时需要分布宽度、权重或剂量贡献以及邻域密度。Process Loading 用局部图形密度与相对工艺速率表描述密度依赖效应。两者物理含义不同；只开开关而不填写有效表格，不能得到可靠校正。

尺寸相关模糊：Blur Dependency 用尺寸与模糊因子的对应表描述图形尺寸变化引起的模糊变化。尺寸表应递增，两个数组等长，因子应为有效正值。该功能是在基础模糊模型上加入尺寸依赖，不能替代 PSF 数据。

保留Cell：Cells to Keep 指定需要保留处理的 Cell 名称，不代替输入图层选择，也不表示无条件透传整个输入库。运行后应核对保留内容的图层、几何及剂量属性。

零宽PATH：Single Line Beam Width 为零宽 PATH 指定参与计算的有效全宽，接口单位为 nm。它不是半宽，也不是 PSF 的 FWHM；原本已有宽度的 PATH 应使用自身宽度。零束宽跳过版本中，设置为 0 时忽略零宽 PATH；全部忽略时产生空输出并继续 Flow。（3）界面设置

Topology PEC 可为多个图层分别指定 Topography PSF。每一行填写 Layer、Rel. Base Dose 和 PSF；需要更多图层时使用“+”增加。下图给出逐层 PSF 与 Edge Effects 的界面位置。

.. image:: media/06/img_141.png
   :width: 15.3cm
   :align: center

Topology PEC 的逐层 PSF 和 Edge Effects 示意

Edge Effects 可保持 None；选择 crossover 后，再按下表填写距离、作用宽度和剂量因子。Include Short Range Correction 仅在需要短程修正时启用。每个非空图层行都应有有效 PSF 和正的相对基准剂量。

Topology PEC 逐层与边缘设置

.. list-table::
   :header-rows: 1
   :widths: 33 33 33

   * - 字段
     - 含义
     - 检查重点
   * - Layer / Rel. Base Dose
     - 对应图层和相对剂量
     - 图层格式有效；剂量大于 0
   * - PSF
     - 该图层的径向能量分布
     - 选择文件或有效的内嵌曲线
   * - Distance / Width / Dose Factor
     - crossover 边缘表
     - 启用该模式时填写；宽度和因子大于 0

（4）操作步骤与参数检查

先确定哪些图层使用不同的 Topography PSF，再为每个非空图层增加一行。Layer 与 Rel. Base Dose 应指向同一图层；PSF 可由文件或有效的内嵌曲线提供。逐行检查图层是否重复、相对剂量是否为正、曲线是否具有有效能量。

Edge Effects 为 None 时无需填写边缘表；选 crossover 后才填写 Distance、Width、Dose Factor。距离单位为 μm，应按顺序排列；宽度和因子应为正。下图显示边缘表及 Create new Layer 开关，设置规则见下表。

.. image:: media/06/img_142.png
   :width: 14.1cm
   :align: center

Topology PEC 的 crossover 边缘表设置示意

Topology PEC 边缘与输出选项

.. list-table::
   :header-rows: 1
   :widths: 33 33 33

   * - 项目
     - 作用
     - 操作提示
   * - Include Short Range Correction
     - 决定是否启用短程修正
     - 按工艺需要选中
   * - Edge Effects Mode
     - None 或 crossover
     - 选 crossover 后再编辑边缘表
   * - Distance / Width / Dose Factor
     - 边缘影响的距离、宽度和剂量因子
     - 核对单位、顺序及正数约束
   * - Create new Layer
     - 在新图层放置受地形影响的数据
     - 运行后核对实际输出图层

应用后先用小版图验证，重点核对各输入图层是否都产生预期输出。PSF 预览只显示当前选中的分布；多图层场景应逐行核对，避免图层和 PSF 对错。

（5）结果检查与常见提示

先在界面应用配置并处理提示，再运行模块。应用通过表示参数已通过校验；是否完成计算，应结合运行日志和实际输出判断。

【5.1】结果检查

先看日志是否明确报告完成，再检查输出图层数量、Layer/Datatype 与输入选择是否一致。仅有 READY 状态或 PSF 预览，并不代表数值计算已经结束。

抽查窄线、密集区、孤立图形及不同剂量区域，对比输出形状和 dose 属性。空输出应区分“按配置忽略后无待处理图形”和运行失败；若预期有图形而输出为空，检查图层选择及输入内容。

保存实际使用的 PSF、剂量、材料或地形配置。新参数先在小版图上验证，再用于完整版图。

【5.2】常见提示

NOT READY：检查当前选中的模式是否填写完整，例如 PSF、图层或曲线。READY 后没有结果：检查运行日志、输入连接和输出节点，不能只凭预览判断计算完成。

逐层结果异常：逐行检查 Topography 图层、相对基准剂量与 PSF 是否对应；开启 Edge Effects 后检查距离、宽度和因子表。

.. _sec-6-3-6:

6.3.6 SURFACEPEC模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Surface PEC适用任务是依据目标剩余胶厚或相对剂量生成表面形貌，主要输入为目标高度表、对比度曲线和 Work Range。

（1）Python接口

本模块使用 surfacepec_ui 接收上游版图并返回处理结果。本节先说明接口调用与参数，后续章节介绍 Surface PEC 的功能、界面设置和操作步骤。

【1.1】调用方式

dm_result = surfacepec_ui(dm_Import_1, ...)

上式仅说明调用结构，省略号不能直接作为完整调用使用。第一个参数是上游节点产生的 dmLib pair；返回值可传给后续处理或 Export 节点。请从“查看 Python”或完整 Flow 导出实际脚本。

调用采用位置参数：逗号前是实际参数值，# 后是说明注释。修改数值时必须保留参数位置；注释中的名称并不表示绑定支持同名关键字参数。不要把另一版本的完整调用直接套到当前接口上，也不要删掉关闭功能所占的参数位置。

【1.2】单位与数组

长度以参数后缀为准：_nm 为纳米，_um 为微米，1 μm = 1000 nm。_percent 是百分数，输入 5 表示 5%；density、factor 和 weight 等比例参数通常采用无量纲数值，不能因界面显示百分比而自行乘除 100。布尔开关通常使用 0 或 1；模式编号是枚举，不应统一当作开关。

配对数组应等长，图层、材料与曲线应保持对应顺序。截图中的数值是配置示例，不是推荐工艺配方。以下参数按功能分组解释，不代替导出脚本的位置参数顺序。

【1.3】调用前检查

若第一个参数显示 None，先检查节点是否连接到有效输入，再重新导出完整 Flow。若开头出现 raise ValueError(...)，该脚本执行到这里会停止：应返回界面补齐配置，重新应用并导出，不要简单删除报错行强行运行。

Selected PSF needs at least two points 表示所选 PSF 的有效采样点不足。应补齐所选 PSF 的有效数据后重新导出。

运行环境须能访问使用的 PSF 文件及输出路径。修改曲线或图层行时，同步修改相关数组；保留关闭功能对应的参数位置。

【1.4】参数说明

输入与PSF

.. list-table::
   :header-rows: 1
   :widths: 50 50

   * - 参数名称
     - 中文说明与使用要求
   * - 输入 dmLib pair / layers
     - 上游输入版图及候选图层。
   * - alpha_um / beta_um / eta
       add_gamma / gamma_um / nue
     - 高斯 PSF 短长程尺度（μm）、相对权重与附加项开关、尺度、权重。
   * - effective_short_range_blur_fwhm_um
     - 有效短程模糊 FWHM，μm。
   * - psf_samples_x / psf_samples_y
     - 数值 PSF 的半径（μm）与能量密度数组，按点对应。
   * - archive3d_data / z_dependence
     - 三维归档 PSF 数据字符串与深度依赖设置。该数据应由界面生成，不手工拼接。

材料与对比度曲线

.. list-table::
   :header-rows: 1
   :widths: 50 50

   * - 参数名称
     - 中文说明与使用要求
   * - contrast_curve_mode
     - 对比度曲线模式：0 为材料库，1 为 Numeric。
   * - material_resists / material_developers
     - 多材料名称与显影液名称的分组字符串。
   * - material_original_thickness_um
     - 材料库各条曲线对应的初始胶厚（μm）。
   * - material_point_offsets
     - 多材料拼接曲线的分段偏移索引。保持导出格式，不当作曲线点数。
   * - material_doses
       material_thicknesses_um
     - 各材料拼接的剂量与剩余厚度（μm）数组，分段由 offsets 指定。
   * - resist / developer
     - 当前材料与显影液名称。
   * - contrast_curve_original_thickness_um
     - 当前曲线的初始胶厚，μm。
   * - contrast_curve_doses
       contrast_curve_thicknesses_um
     - 当前曲线的剂量与剩余厚度（μm）数组，逐点对应。

【1.5】目标与离散参数

目标表面

.. list-table::
   :header-rows: 1
   :widths: 50 50

   * - 参数名称
     - 中文说明与使用要求
   * - base_dose_uc_cm2
     - 物理基准剂量，μC/cm²。
   * - work_range_min / work_range_max
     - 允许剩余胶厚相对于初始胶厚的比例范围，满足 0 ≤ Min < Max ≤ 1。
   * - include_lateral_development
     - 是否包含横向显影作用。
   * - pixel_size_um
     - 计算像素尺寸，μm；减小会提高采样密度，也增加计算量。
   * - surface_definition_type
     - 0 相对高度；1 绝对高度；2 从图层获得绝对高度；3 相对剂量。
   * - surface_layers / surface_values
     - 目标图层字符串与数值数组。Relative Height 为比例，Absolute Height 为 μm，Dose 为相对剂量；From Layer 按对应图层高度数据解释。

精度与剂量分档

.. list-table::
   :header-rows: 1
   :widths: 50 50

   * - 参数名称
     - 中文说明与使用要求
   * - fracture_mode / dose_class_definition
     - 图形分割模式与剂量分档模式；保留界面导出枚举。
   * - accuracy_percent
       maximum_number_of_dose_classes
     - 精度百分数与最大剂量档数。
   * - minimum_dose_factor
       maximum_dose_factor / dose_assignment
     - 相对剂量上下限与用户指定剂量表。
   * - isodose_grid_um
       automatic_minimum_figure_size
     - 等剂量网格（μm）与自动最小尺寸开关。
   * - long_range_min_figure_size_um
       short_range_min_figure_size_um
     - 手动长程、短程最小图形尺寸，μm。
   * - tolerance_percent
     - 容差百分数，保留所选配方及界面校验通过的值。

例如初始胶厚为 0.3 μm，Relative Height 输入 0.7 表示目标剩余胶厚为 0.21 μm；如果改为 Absolute Height，则应输入 0.21，而不是 0.7。切换定义模式后要同步检查 surface_values。

高级参数

作用范围与可选效应

.. list-table::
   :header-rows: 1
   :widths: 50 50

   * - 参数名称
     - 中文说明与使用要求
   * - short_range_separation_enabled
       short_range_separation_um
     - 短长程分界设置开关及距离（μm）；不等同于短程校正总开关。
   * - mid_range_active_threshold_percent
       sr_correction_layer_list
       lr_fracture_layer_list
     - 中程激活阈值（%）、短程校正层和长程分割层。
   * - cells_to_keep
       single_line_beam_width_um
     - 保留 Cell 名称与零宽 PATH 的有效全宽（μm）。
   * - fogging_effect_correction
       fogging_sigma_um / fogging_weight
       neighborhood_density
     - Fogging 开关、sigma（μm）、权重及邻域密度。
   * - process_loading_effect
       effect_influence_range_um
       loading_table_x / loading_table_y
     - Loading 开关、影响范围（μm），以及密度与工艺响应配对表。
   * - blur_dependency
       blur_variability_x / blur_variability_y
     - 尺寸相关模糊开关、尺寸与模糊因子配对表；尺寸沿用界面导出的 μm 数据。
   * - assume_periodic
       pitch_x_um / pitch_y_um
       repetition_x / repetition_y
     - 周期假设开关、X/Y 间距（μm）、X/Y 重复次数。

（2）模块用途与功能

Surface PEC 以目标表面形貌为输入，通过对比度曲线将目标剩余胶厚转换为剂量需求，再进行邻近效应修正。Relative Height 和 Absolute Height 都描述剩余胶厚；Dose 模式则直接指定相对剂量。Work Range 限制允许使用的胶厚区间，帮助避免在未标定的曲线范围外求剂量。

【2.1】PSF与工艺输入

PSF 描述一次曝光的能量如何向周围扩散。Gaussian 用短程、长程及可选附加高斯项描述分布；Numeric 或 Archive 使用采样数据。能量密度曲线和累积能量曲线是同一分布的不同表达，导出时应保持半径与数值一一对应。附加 Gamma 项用于补充原有模型未充分描述的尺度，不应仅为了让预览更平滑而启用。

对比度曲线描述曝光剂量与显影后剩余胶厚的关系。横坐标是剂量，纵坐标是剩余胶厚；它不是 PSF，也不是 Dose Factor 表。多胶层曲线应与对应的初始胶厚、材料和显影条件一致。改变曲线会改变工艺目标所需的剂量，不能仅通过调整网格抵消。

【2.2】剂量与离散精度

Base Dose 是物理曝光剂量基准，Dose Factor 是相对于基准的无量纲比例。Minimum 和 Maximum Dose Factor 限定允许的剂量范围；Accuracy 模式按精度和最大档数组织输出剂量，User Defined 模式使用指定剂量表。档数增加会提高表达细节的能力，也可能增加输出复杂度；应结合设备可接受的剂量档位设置。

Fracture Grid 和 Isodose Grid 描述离散或输出划分尺度，Minimum Figure Size 限制小图形的处理尺度。较细设置通常会增加计算量及输出数据量。Automatic 模式由模块选择最小尺寸，手动模式才需要逐项指定短程、长程最小尺寸。不要将这些数值当作实际线宽。

【2.3】短程与长程

短程校正处理近距离散射对细节的影响，长程校正处理更大范围的背景剂量耦合。Short Range Separation 是分界位置；自动或手动分界开关与是否启用短程校正是不同设置。Mid Range Activation Threshold 按中程贡献决定是否启用相应处理，其百分比字段与 nm 长度字段不能互换。

【2.4】高级功能与输入处理

Include Lateral Development 控制是否考虑横向显影作用，并结合材料响应进行处理。它不等同于改变 PSF 模糊宽度。

背景与工艺密度效应：Fogging 表示额外的广域背景曝光贡献，通常同时需要分布宽度、权重或剂量贡献以及邻域密度。Process Loading 用局部图形密度与相对工艺速率表描述密度依赖效应。两者物理含义不同；只开开关而不填写有效表格，不能得到可靠校正。

尺寸相关模糊：Blur Dependency 用尺寸与模糊因子的对应表描述图形尺寸变化引起的模糊变化。尺寸表应递增，两个数组等长，因子应为有效正值。该功能是在基础模糊模型上加入尺寸依赖，不能替代 PSF 数据。

保留Cell：Cells to Keep 指定需要保留处理的 Cell 名称，不代替输入图层选择，也不表示无条件透传整个输入库。运行后应核对保留内容的图层、几何及剂量属性。

零宽PATH：Single Line Beam Width 为零宽 PATH 指定参与计算的有效全宽，接口单位为 μm。它不是半宽，也不是 PSF 的 FWHM；原本已有宽度的 PATH 应使用自身宽度。零值的具体处理应以所用版本为准。

周期邻域：Periodic 用 X、Y 方向的间距与重复次数描述周期邻域。仅在版图和边界条件符合周期假设时启用；Pitch 是排列间距，不是像素尺寸。

（3）界面设置

Surface PEC 以目标剩余胶厚或相对剂量定义表面形貌。先设置 Base Dose、胶层对比度曲线和 Work Range，再选择 Surface Definition Type 并逐行填写目标图层。下图显示 Numeric 对比度模式下的高度表及提示。

.. image:: media/06/img_143.png
   :width: 11.7cm
   :align: center

Surface PEC 的高度与 Work Range 校验示意

Work Range Min/Max 是相对于 Original Thickness 的比例。Relative Height 要先乘原始胶厚，Absolute Height 则直接采用 μm 数值；两者都须落在 Work Range 对应的胶厚范围内。超出时，上图中的剂量预览显示“--”，并提示对应行。下表汇总常用定义方式。

Surface PEC 定义方式

.. list-table::
   :header-rows: 1
   :widths: 33 33 33

   * - 类型
     - 表格输入
     - 核对方法
   * - Relative Height
     - 相对高度，无量纲
     - 目标高度＝输入值×原始胶厚
   * - Absolute Height
     - 目标高度，μm
     - 直接与 Work Range 换算后的胶厚比较
   * - Height from Layer
     - 按图层取得目标高度
     - 确认来源图层及其高度数据
   * - Dose
     - 相对基准剂量
     - 剂量模式不使用高度 Work Range

（4）操作步骤与参数检查

3D PEC 页先选 Contrast Curve Mode：Material Archive 使用所选材料与显影液；Numeric 录入剂量—剩余胶厚曲线。再填写 Base Dose、Work Range 与 Surface Definition Type。若 Numeric 模式下曲线缺失或目标高度越界，剂量预览会显示“--”。

Relative Height 是初始胶厚的比例；Absolute Height 直接输入 μm；Absolute Height From Layer 根据图层的高度信息赋值；Dose 输入相对剂量。下图为 From Layer 示例。切换类型后先看表头，再录入数值，避免把相对高度当成 μm。高度与剂量的核对方法见下表。

.. image:: media/06/img_144.png
   :width: 13.5cm
   :align: center

Surface PEC 按图层提供高度的界面示意

Surface PEC 高度与剂量检查

.. list-table::
   :header-rows: 1
   :widths: 33 33 33

   * - 检查项
     - 判定方法
     - 处理方法
   * - Work Range
     - 0 ≤ Min < Max ≤ 1
     - 重新设定相对胶厚范围
   * - Relative Height
     - 输入值×Original Thickness 落在范围内
     - 调整高度或 Work Range
   * - Absolute Height
     - 输入的 μm 高度落在范围内
     - 核对 μm 和原始胶厚
   * - Dose 预览为 --
     - 曲线缺失、越界或剂量不唯一
     - 按行检查提示与 Contrast Curve

例：Original Thickness 为 0.632 μm、Work Range Max 为 0.8 时，最大允许 Height 为 0.5056 μm。若某行绝对高度为 0.55 μm，应修改该行或范围后再应用。Lateral Development、周期排列及 Fogging、Loading、Blur 等选项仅在工艺需要时启用。

（5）结果检查与常见提示

先在界面应用配置并处理提示，再运行模块。应用通过表示参数已通过校验；是否完成计算，应结合运行日志和实际输出判断。

【5.1】结果检查

先看日志是否明确报告完成，再检查输出图层数量、Layer/Datatype 与输入选择是否一致。仅有 READY 状态或 PSF 预览，并不代表数值计算已经结束。

抽查窄线、密集区、孤立图形及不同剂量区域，对比输出形状和 dose 属性。空输出应区分“按配置忽略后无待处理图形”和运行失败；若预期有图形而输出为空，检查图层选择及输入内容。

保存实际使用的 PSF、剂量、材料或地形配置。新参数先在小版图上验证，再用于完整版图。

【5.2】常见提示

NOT READY：检查当前选中的模式是否填写完整，例如 PSF、图层或曲线。READY 后没有结果：检查运行日志、输入连接和输出节点，不能只凭预览判断计算完成。

目标高度越界：核对 Relative Height 或 Absolute Height 的单位，并将目标与 Original Thickness、Work Range 一起检查。切换定义方式后同步修改目标值。

6.3.7特征剂量分配

特征剂量分配（Feature Dose Assignment, FDA），允许用户为版图中的特征分配剂量。剂量值可以按照图层（By Layer）、区域（By region）、版图（By Layout）、位置（By Positions）四种模式进行分配。还支持直接赋值（Assign）、对现有剂量做乘法（multiply）或加法（Add）三种方式。

fdaMode：By Layer, By region, By Layout, By Positions

fdatype：Assign, Multiply, Add

Python接口及参数介绍如下：

.. list-table::
   :header-rows: 1
   :widths: 33 33 33

   * - featureDoseAssignment
     - featureDoseAssignment
     - featureDoseAssignment
   * - 序号
     - 名称
     - 释义
   * - 1
     - In_lib
     - 载入的lib,其他的模块的输出Lib
   * - 2
     - Layer
     - 作用层,字符串数组[“1(0)”,”2(0)”]
   * - 3
     - FDA mode
     - 0：By Layer
   * - 3
     - FDA mode
     - 1：By Region
   * - 3
     - FDA mode
     - 2：By Layout
   * - 3
     - FDA mode
     - 3：By Position
   * - 4
     - FDA type 
     - 0：Aisign
   * - 4
     - FDA type 
     - 1：Multiply
   * - 4
     - FDA type 
     - 2：Add
   * - 5
     - matToLoAlm
     - By position剂量矩阵与版图的对齐方式
       0：矩阵A1的位置对准时版图的绝对位置
       1：矩阵中心对准版图的中心
   * - 6
     - outMatBhvr
     - 矩阵未覆盖区域的处理方式
       0：将边缘单元格的剂量值向外扩展
       1：若矩阵未覆盖整个版图则报错
   * - 7
     - xStart（um）
     - 矩阵原点A1在版图中的x坐标
   * - 8
     - yStart（um）
     - 矩阵原点A1在版图中的y坐标
   * - 9
     - xGrid（um）
     - 矩阵每一列在x方向的物理宽度
   * - 10
     - yGrid（um）
     - 矩阵每一行在y方向的物理高度
   * - 11
     - CellA1Pos 
     - 定义A1单元格在矩阵中的位置
       0：A1为矩阵的左下角
       1：A1为矩阵的左上角
   * - 12
     - Dose table rows
     - 剂量矩阵行数，整型，仅在By Position作用
   * - 13
     - Dose table cols
     - 剂量矩阵列数，整型，仅在By Position作用
   * - 14
     - User Define Fracture Settings 
     - 是否开启用户自定义裂解参数
       0：不开启
       1：开启
   * - 15
     - Fracture Grid（um）
     - 图形裂解的最小尺寸
   * - 16
     - Minimum Fracture Size（um）
     - FDA模块的最小作用尺寸
   * - 17
     - Dose table
     - 浮点数数组[1.1,2,3,5]，By Layer、By Region、By Layout模式下，数目必须等于layer的数目；By position模式下必须指定行数与列数
   * - 18
     - Sigma table 
     - 高斯函数的Sigma列表，浮点数数组[1.1,2,3,5] ，数目必须等于layer的数目
   * - 19
     - Distance table
     - By layout中图形向外延伸的Distance列表，浮点数数组[1.1,2,3,5] ，数目必须等于layer的数目

featureDoseAssignment(lib,["1(0)","2(0)"],0,0,0,0,0,0,0,0,0,0,0,0,0,0,[2.0,5.0],[],[])

介绍特征剂量分配模块设置等， 可以参考 Beamer；

介绍Python接口的参数和效果等；

（1）按层的剂量分配

.. image:: media/06/img_145.png
   :width: 10.56cm
   :align: center

按层的剂量分配（By Layer），根据设置的剂量值，直接给整个layer进行相同剂量值计算。下方的表格可以对不同的图层使用不同的剂量值。在单个By Layer的FDA模块中，每个layer只能选择一次。

Layer：选择设置的图层，每个图层在单个模块内只可选择设置一次

Dose：为该图层设置的相对剂量

下图为使用By Layer模式分别给1(0)、2(0)、3(0)层使用Assign模式赋剂量值1.0，2.0，3.0的结果。

.. image:: media/06/img_146.png
   :width: 14.65cm
   :align: center

（2）按区域的剂量分配

按区域的剂量分配（By Region）允许用户通过指定一些额外的层来定义一个需要应用剂量矫正的区域。该图层的图形轮廓即为剂量增强区域的边界。软件会将用户设定的相对剂量，根据设定的模式，应用于该区域内部，并在区域边界处进行高斯渐变过度，避免剂量突变导致的显影异常。

.. image:: media/06/img_147.png
   :width: 10.8cm
   :align: center

Layer：选择用来当做区域的图层，每个区域图层在单个模块内只可选择设置一次，对其他图层进行分配。

Dose：为该区域图层设置的相对剂量，对其他图层作用。该区域图层保留原始的剂量值不变。

Sigma (um)：高斯渐变的参数，值越大，则越平滑。

User define fracture settings：是否开启用户自定义裂解参数。

Fracture grid (um)：图形裂解的最小尺寸。

Minimum figure size (um)：FDA模块的最小作用尺寸。

如下图，对图层1(0)使用2(0)进行By Region模式的FDA， 赋值方式为multiply，dose为5，sigma为0.1um，fracture grid和minimum figure size都为0.1。结果可以看到，在1(0)与2(0)重叠的中心部分剂量近似等于5.0（原剂量为1.0，乘以5.0），由于sigma为0.1，所以不会完全等于5。另外可以看到，图形周围从中心向外渐变至1.0。

.. image:: media/06/img_148.png
   :width: 14.65cm
   :align: center

（3）按版图的剂量分配

按版图的剂量分配（By Layout）模式用于补偿跨越地形台阶的图形因光刻胶厚度不均匀导致的显影轮廓偏差，用户制定一个或多个台阶层，软件会自动检测被曝光图形跨过该地层边缘的位置，并在台阶边缘处施加剂量补偿。补偿剂量按照高斯函数向两侧平滑衰减，避免剂量突变。

.. image:: media/06/img_149.png
   :width: 11.7cm
   :align: center

Layer：选择用来当做台阶层的图层，每个台阶层在单个模块内只可选择设置一次，影响其他图层。

Dose：为该区域台阶边缘设置的相对剂量，作用于其他图层。该台阶层剂量值保持为1.0。

Sigma (um)：高斯渐变的参数，值越大，则越平滑。

User define fracture settings：是否开启用户自定义裂解参数。

Fracture grid (um)：图形裂解的最小尺寸。

Minimum figure size (um)：FDA模块的最小作用尺寸。

Distance (um)：从台阶顶部到增厚光脚区域的距离，用于确定补偿范围。设定后会对台阶层进行扩大/缩小。

如下图，对图层1(0)使用2(0)进行By Layout模式的FDA， 赋值方式为add，dose为5，sigma为0.1um，distance为0.1um，fracture grid和minimum figure size都为0.05。结果可以看到，漏斗状图形扩大了0.1um，在1(0)与2(0)重叠的中心部分剂量近似等于1.0（跟随1(0)层该区域的原始剂量1.0），sigma为0.1，可以看到，台阶层图形外的剂量由某个值向外渐变至版图原始剂量1.0。

.. image:: media/06/img_150.png
   :width: 14.65cm
   :align: center

（4）按位置的剂量分配

按位置的剂量分配（By Layout）模式允许用户通过一张二维剂量矩阵，按照芯片上的绝对物理坐标分配剂量。该模式不依赖任何图层图形，仅根据图形的物理位置决定其接收的剂量，主要用于补偿与版图图形无关、仅与全局位置相关的工艺偏差。并且，该模式在剂量边界处进行高斯渐变过度，避免剂量突变导致的显影异常。

.. image:: media/06/img_151.png
   :width: 10.72cm
   :align: center

Matrix to Layout Alignment：剂量矩阵与版图的对齐方式。

Start Coordinates To Layout Coordinates：矩阵A1的位置（由xStart和yStart定义）对准时版图的绝对位置。

Center Of Matrix To Center Of Layout：矩阵中心对准版图的中心。

Bottom Left Of Matrix To Bottom Left Of Layout：矩阵左下角对准版图的左下角。

Outside Matrix Behaviour：矩阵未覆盖区域的处理方式。

Expand Values Continuously To Outside：将边缘单元格的剂量值向外扩展。

Create Error If Matrix Is Smaller Than Layout Extent：若矩阵未覆盖整个版图则报错。

xStart：版图的剂量表起点A1在版图中的x坐标。

yStart：版图的剂量表起点A1在版图中的y坐标。

xGrid：矩阵每一列在x方向的物理宽度。

yGrid：矩阵每一行在y方向的物理高度。

Cell A1 Position：定义A1单元格在矩阵中的位置。

Bottom Left：版图的剂量表起点A1为矩阵的左下角。

Top Left：版图的剂量表起点A1为矩阵的左上角。

User define fracture settings：是否开启用户自定义裂解参数。

Fracture grid (um)：图形裂解的最小尺寸。

Minimum figure size (um)：FDA模块的最小作用尺寸。

示例如下图，该示例采用Start Coordinates To Layout Coordinates的模式xStart为1.5，xStart为1.5，该位置在版图图形区域内部。采用Bottom Left的A1位置，即(1.5, 1.5)，(2.0, 2.0)两点形成的矩形区域内的剂量为7。其他位置根据矩形内的剂量值与xGrid和yGrid进行赋值。

.. image:: media/06/img_152.png
   :width: 14.65cm
   :align: center

.. _sec-6-4:

6.4 Verify 分组
-----------------------------

.. _sec-6-4-1:

6.4.1 EBeam模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. _sec-6-5:

6.5 Control分组
-----------------------------

介绍流程控制类的模块设置等， 可以参考 Beamer；

介绍Python接口的参数和效果等；

.. _sec-6-5-1:

6.5.1 Exit模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~

Exit模块允许自动退出ebl流程。

.. _sec-6-5-2:

6.5.2 IF模块
~~~~~~~~~~~~~~~~~~~~~~~

If模块是用于条件判断。如果返回真，流程走右边的分支，否则，走左边的分支。

.. image:: media/06/img_153.png
   :width: 14.63cm
   :align: center

.. _sec-6-5-3:

6.5.3 loop模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~

Loop模块是循环执行模块。一般和变量组合使用。它提供灵活的变量定义功能。

Loop Count：指定循环次数。

Insert Var：插入新的变量。

Delete Var：删除指定的变量。

Gen List：为指定的变量生成等差数列形式的值列表。

.. image:: media/06/img_154.png
   :width: 14.65cm
   :align: center

.. _sec-6-5-4:

6.5.4 Python模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Python模块为用户提供简单的方式处理复杂问题。它允许多输入多输出。输入端口从左到右，分别是in1，in2，... 。输出端口从左到右，分别是out1，out2，... 。

.. image:: media/06/img_155.png
   :width: 10.71cm
   :align: center

.. _sec-6-5-5:

6.5.5 Select模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Select模块用于条件查询。多个输入端口，单个输出端口。 满足条件的输入，被送至输出端。只能有一个输入端口被送至输出端。如果有多个输入端满足条件，直接报错。

.. image:: media/06/img_156.png
   :width: 10.61cm
   :align: center

.. _sec-6-5-6:

6.5.6 Split模块
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Splitter模块允许一个模块的输出端连接多个后继模块。

