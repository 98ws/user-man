# EBL 严格构建与修复验证报告

日期：2026-11-02。依据用户授权修复 RST 与图片格式；附件中的历史报告作为参考资料，不作为额外操作指令。

## 构建结果

- Python 3.12.14，Sphinx 9.1.1，docutils 0.22.4；按要求执行升级，解析器选择相互兼容的版本。内置 sphinx.ext.autodoc 无需额外 API 库。
- 初次严格 HTML：退出码 1，Sphinx 汇总 66 条诊断；逐条保存于 validation/initial_diagnostics.csv。按日志级别：{'WARNING': 61, 'ERROR': 5}；按类别：{'标题下划线': 50, '标题层级/空行': 5, '行内标记': 8, '示例代码高亮': 3}。日志内 ERROR 也纳入 Sphinx 的 66 条汇总。
- 最终全量严格 HTML：`sphinx-build -E -a -b html -n -W --keep-going source build/html`，退出码 0，0 警告/错误。
- 最终全量严格 LaTeX：`sphinx-build -E -a -b latex -n -W --keep-going source build/latex`，退出码 0，0 警告/错误；产出 .tex 与依赖资源。未执行 PDF 排版，不声称 PDF 通过。
- sphinx_build.log 保留初次及所有后续构建的完整输出和退出码。

## 内容保护与修改

原始压缩包原样保留在 original_project.zip，SHA256：`438d389d5cfdc06f9eec480ec2796a09a8bebff5a513da1de7ac947bb395053f`。另有本机 /workspace/ebl_original 解压副本。全部原有文件保留；改动仅限 source/chapter_03.rst、chapter_06.rst、chapter_07.rst、chapter_09.rst 以及新增 8 张 PNG。第 10 章与输入逐字节相同。

build_fixes.csv 逐差异块记录原文件行号、修复后行号、修改前后全文和原因，另含生成图片和复现说明。修复包括标题显示宽度、Bias 子标题层级、PSF 子模式标题空行、通配符转义与行内标记边界。未修改技术参数、GUI 名称或 Python 签名。3 段有词法问题的示例代码原文保持，改用 text 展示，不宣称有效 Python。

## 检查证据

| 检查 | 结果与范围 |
|---|---|
| 10 章完整性 | 10 个 source 文件及 10 个 HTML 页面均存在；保留所有原有文件，不代表逐句验证原始 Word 的转换完整性 |
| 图片 | 十章共 274 个图片元素，Chromium 实际加载均成功；所有本地图片可解码；8 张 EMF 转为 180 DPI PNG 并保留原图，按原始页面边界导出，纵横比误差小于 0.2%（像素取整） |
| 自动图号 | 160 个 figure caption，逐章编号从 1 连续递增，无跳号；原有 image 指令继续作为无编号图片，不凭空补造图注 |
| 链接 | 全部生成 HTML 的本地文件和锚点扫描无断链；严格 nitpicky 构建无未解析交叉引用。检查实际目标存在，未逐条用鼠标点击所有链接 |
| GUI 表格 | 十章正文 75 张表格（第6章62、第7章5、第8章3、第9章5）；参数表行与输入逐行一致，仅允许 RST 字面转义差异；浏览器无空结构行，抽查 GUI 参数表截图布局正常。无法替代对软件实际参数完整性的确认 |
| Python API | 32 个 py:function 均生成 HTML 定义节点；所有声明的接口名及参数顺序与输入完全一致；API 截图可读。未执行 EBL 接口或验证研发签名 |
| 字符与缩进 | 全部 HTML 无 U+FFFD 替换符、problematic 或 system-message 节点；十章浏览器页面在 1440px 视口无页面级横向溢出。抽查截图未见乱码/表格错位；不宣称逐像素检查所有段落 |
| 第10章 | 原文件字节完全一致；浏览器页面可读，无结构重组或语言润色 |

浏览器证据：validation/browser_checks.json、browser_run.log、chapter_*_top.png、gui_table.png、python_api.png。静态结果：validation/static_checks.json。8 张转换图片已检查拼图 validation/emf_contact_sheet.png：img_040/041 的公式文本在右边缘截断，需核对原图，不补造内容。

## 仍需确认

remaining_issues.csv 包含本轮未确认的示例代码、API 真值、公式图片边界、标题自动/手写双重编号、未执行 PDF，以及历史技术问题。历史条目未逐项重新语义验收，不能当成本轮新发现或仍存在的编译警告；其中历史 SPHINX_NOT_AVAILABLE 已由本轮实测解决，不再列入。现有 reports/ 内旧报告保持原样，避免覆盖溯源记录。

可确定的编译错误已修复；严格构建通过不等于技术内容和 API 已获研发确认。
